type LogPayload = Record<string, unknown>;

function stringify(payload?: LogPayload): string {
  if (!payload) return "";
  return ` ${JSON.stringify(payload)}`;
}

export const logger = {
  info(message: string, payload?: LogPayload): void {
    console.log(`[INFO] ${message}${stringify(payload)}`);
  },
  warn(message: string, payload?: LogPayload): void {
    console.warn(`[WARN] ${message}${stringify(payload)}`);
  },
  error(message: string, payload?: LogPayload): void {
    console.error(`[ERROR] ${message}${stringify(payload)}`);
  }
};
