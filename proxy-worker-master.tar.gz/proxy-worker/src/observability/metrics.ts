import { logger } from "./logger";

export interface ProxyMetrics {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  totalResponseTime: number;
  avgResponseTime: number;
  requestsPerMinute: number;
  lastResetAt: Date;
}

export interface BackendMetrics {
  backendId: string;
  requests: number;
  successes: number;
  failures: number;
  totalResponseTime: number;
  avgResponseTime: number;
  lastUsedAt: Date | null;
  isHealthy: boolean;
}

export class MetricsCollector {
  private globalMetrics: ProxyMetrics = {
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    totalResponseTime: 0,
    avgResponseTime: 0,
    requestsPerMinute: 0,
    lastResetAt: new Date()
  };

  private backendMetrics = new Map<string, BackendMetrics>();
  private requestTimestamps: number[] = [];
  private readonly WINDOW_SIZE_MS = 60000; // 1 minute

  recordRequest(backendId: string, responseTimeMs: number, success: boolean): void {
    // Update global metrics
    this.globalMetrics.totalRequests++;
    this.globalMetrics.totalResponseTime += responseTimeMs;
    
    if (success) {
      this.globalMetrics.successfulRequests++;
    } else {
      this.globalMetrics.failedRequests++;
    }

    this.globalMetrics.avgResponseTime = 
      this.globalMetrics.totalResponseTime / this.globalMetrics.totalRequests;

    // Track request timestamps for RPM calculation
    const now = Date.now();
    this.requestTimestamps.push(now);
    this.requestTimestamps = this.requestTimestamps.filter(
      ts => now - ts < this.WINDOW_SIZE_MS
    );
    this.globalMetrics.requestsPerMinute = this.requestTimestamps.length;

    // Update backend-specific metrics
    let backendMetric = this.backendMetrics.get(backendId);
    if (!backendMetric) {
      backendMetric = {
        backendId,
        requests: 0,
        successes: 0,
        failures: 0,
        totalResponseTime: 0,
        avgResponseTime: 0,
        lastUsedAt: null,
        isHealthy: true
      };
      this.backendMetrics.set(backendId, backendMetric);
    }

    backendMetric.requests++;
    backendMetric.totalResponseTime += responseTimeMs;
    backendMetric.avgResponseTime = backendMetric.totalResponseTime / backendMetric.requests;
    backendMetric.lastUsedAt = new Date();

    if (success) {
      backendMetric.successes++;
    } else {
      backendMetric.failures++;
    }

    // Log slow requests
    if (responseTimeMs > 10000) {
      logger.warn("slow request detected", {
        backendId,
        responseTimeMs,
        success
      });
    }
  }

  updateBackendHealth(backendId: string, isHealthy: boolean): void {
    const metric = this.backendMetrics.get(backendId);
    if (metric) {
      metric.isHealthy = isHealthy;
    }
  }

  getGlobalMetrics(): ProxyMetrics {
    return { ...this.globalMetrics };
  }

  getBackendMetrics(backendId?: string): BackendMetrics[] {
    if (backendId) {
      const metric = this.backendMetrics.get(backendId);
      return metric ? [metric] : [];
    }
    return Array.from(this.backendMetrics.values());
  }

  getHealthyBackendsCount(): number {
    return Array.from(this.backendMetrics.values()).filter(m => m.isHealthy).length;
  }

  getSuccessRate(): number {
    if (this.globalMetrics.totalRequests === 0) return 100;
    return (this.globalMetrics.successfulRequests / this.globalMetrics.totalRequests) * 100;
  }

  reset(): void {
    this.globalMetrics = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      totalResponseTime: 0,
      avgResponseTime: 0,
      requestsPerMinute: 0,
      lastResetAt: new Date()
    };
    this.backendMetrics.clear();
    this.requestTimestamps = [];
    logger.info("metrics reset");
  }

  getSummary(): string {
    const global = this.globalMetrics;
    const successRate = this.getSuccessRate();
    const healthyBackends = this.getHealthyBackendsCount();
    const totalBackends = this.backendMetrics.size;

    return [
      `Total Requests: ${global.totalRequests}`,
      `Success Rate: ${successRate.toFixed(2)}%`,
      `Avg Response Time: ${global.avgResponseTime.toFixed(0)}ms`,
      `Requests/min: ${global.requestsPerMinute}`,
      `Healthy Backends: ${healthyBackends}/${totalBackends}`,
      `Uptime: ${this.getUptimeString()}`
    ].join(" | ");
  }

  private getUptimeString(): string {
    const uptimeMs = Date.now() - this.globalMetrics.lastResetAt.getTime();
    const hours = Math.floor(uptimeMs / 3600000);
    const minutes = Math.floor((uptimeMs % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  }
}

export const metricsCollector = new MetricsCollector();
