/**
 * Real-time metrics collection for proxy operations
 */

export interface RequestMetrics {
  /** Total requests processed */
  totalRequests: number;
  
  /** Successful requests */
  successfulRequests: number;
  
  /** Failed requests */
  failedRequests: number;
  
  /** Total bytes transferred (upload + download) */
  totalBytes: number;
  
  /** Total bytes uploaded */
  uploadBytes: number;
  
  /** Total bytes downloaded */
  downloadBytes: number;
  
  /** Latency percentiles (ms) */
  latency: {
    p50: number;
    p95: number;
    p99: number;
    avg: number;
    min: number;
    max: number;
  };
  
  /** Requests per backend */
  backendStats: Record<string, {
    requests: number;
    success: number;
    failed: number;
    avgLatency: number;
  }>;
  
  /** Requests per country */
  countryStats: Record<string, {
    requests: number;
    success: number;
  }>;
  
  /** Requests per user */
  userStats: Record<string, {
    requests: number;
    bytes: number;
    activeConnections: number;
  }>;
}

interface RequestRecord {
  timestamp: number;
  latency: number;
  success: boolean;
  backendId: string;
  country: string;
  username: string;
  uploadBytes: number;
  downloadBytes: number;
}

export class MetricsCollector {
  private requests: RequestRecord[] = [];
  private readonly maxRecords: number;
  private readonly windowMs: number;
  
  private totalRequests = 0;
  private successfulRequests = 0;
  private failedRequests = 0;
  private totalUploadBytes = 0;
  private totalDownloadBytes = 0;
  
  private backendStats = new Map<string, { requests: number; success: number; failed: number; totalLatency: number }>();
  private countryStats = new Map<string, { requests: number; success: number }>();
  private userStats = new Map<string, { requests: number; bytes: number; activeConnections: number }>();
  
  constructor(maxRecords = 10000, windowMs = 3600000) {
    this.maxRecords = maxRecords;
    this.windowMs = windowMs; // Default: 1 hour
    
    // Cleanup old records periodically
    setInterval(() => this.cleanup(), 60000);
  }

  /**
   * Record a request
   */
  recordRequest(record: {
    latency: number;
    success: boolean;
    backendId: string;
    country: string;
    username: string;
    uploadBytes: number;
    downloadBytes: number;
  }): void {
    const now = Date.now();
    
    this.requests.push({
      timestamp: now,
      ...record,
    });
    
    // Enforce max records
    if (this.requests.length > this.maxRecords) {
      this.requests.shift();
    }
    
    // Update counters
    this.totalRequests++;
    if (record.success) {
      this.successfulRequests++;
    } else {
      this.failedRequests++;
    }
    
    this.totalUploadBytes += record.uploadBytes;
    this.totalDownloadBytes += record.downloadBytes;
    
    // Backend stats
    const backendKey = record.backendId;
    const backendStat = this.backendStats.get(backendKey) || { requests: 0, success: 0, failed: 0, totalLatency: 0 };
    backendStat.requests++;
    if (record.success) {
      backendStat.success++;
    } else {
      backendStat.failed++;
    }
    backendStat.totalLatency += record.latency;
    this.backendStats.set(backendKey, backendStat);
    
    // Country stats
    const countryKey = record.country;
    const countryStat = this.countryStats.get(countryKey) || { requests: 0, success: 0 };
    countryStat.requests++;
    if (record.success) {
      countryStat.success++;
    }
    this.countryStats.set(countryKey, countryStat);
    
    // User stats
    const userKey = record.username;
    const userStat = this.userStats.get(userKey) || { requests: 0, bytes: 0, activeConnections: 0 };
    userStat.requests++;
    userStat.bytes += record.uploadBytes + record.downloadBytes;
    this.userStats.set(userKey, userStat);
  }

  /**
   * Update active connections for a user
   */
  updateActiveConnections(username: string, delta: number): void {
    const userStat = this.userStats.get(username) || { requests: 0, bytes: 0, activeConnections: 0 };
    userStat.activeConnections = Math.max(0, userStat.activeConnections + delta);
    this.userStats.set(username, userStat);
  }

  /**
   * Get current metrics snapshot
   */
  getMetrics(): RequestMetrics {
    const now = Date.now();
    const recentRequests = this.requests.filter(r => now - r.timestamp <= this.windowMs);
    
    // Calculate latency percentiles
    const latencies = recentRequests.map(r => r.latency).sort((a, b) => a - b);
    const latency = {
      p50: this.percentile(latencies, 50),
      p95: this.percentile(latencies, 95),
      p99: this.percentile(latencies, 99),
      avg: latencies.length > 0 ? latencies.reduce((sum, l) => sum + l, 0) / latencies.length : 0,
      min: latencies.length > 0 ? latencies[0] : 0,
      max: latencies.length > 0 ? latencies[latencies.length - 1] : 0,
    };
    
    // Backend stats
    const backendStats: Record<string, any> = {};
    for (const [backendId, stat] of this.backendStats.entries()) {
      backendStats[backendId] = {
        requests: stat.requests,
        success: stat.success,
        failed: stat.failed,
        avgLatency: stat.requests > 0 ? stat.totalLatency / stat.requests : 0,
      };
    }
    
    // Country stats
    const countryStats: Record<string, any> = {};
    for (const [country, stat] of this.countryStats.entries()) {
      countryStats[country] = {
        requests: stat.requests,
        success: stat.success,
      };
    }
    
    // User stats
    const userStats: Record<string, any> = {};
    for (const [username, stat] of this.userStats.entries()) {
      userStats[username] = {
        requests: stat.requests,
        bytes: stat.bytes,
        activeConnections: stat.activeConnections,
      };
    }
    
    return {
      totalRequests: this.totalRequests,
      successfulRequests: this.successfulRequests,
      failedRequests: this.failedRequests,
      totalBytes: this.totalUploadBytes + this.totalDownloadBytes,
      uploadBytes: this.totalUploadBytes,
      downloadBytes: this.totalDownloadBytes,
      latency,
      backendStats,
      countryStats,
      userStats,
    };
  }

  /**
   * Reset all metrics
   */
  reset(): void {
    this.requests = [];
    this.totalRequests = 0;
    this.successfulRequests = 0;
    this.failedRequests = 0;
    this.totalUploadBytes = 0;
    this.totalDownloadBytes = 0;
    this.backendStats.clear();
    this.countryStats.clear();
    this.userStats.clear();
  }

  /**
   * Calculate percentile
   */
  private percentile(sorted: number[], p: number): number {
    if (sorted.length === 0) return 0;
    const index = Math.ceil((p / 100) * sorted.length) - 1;
    return sorted[Math.max(0, index)];
  }

  /**
   * Cleanup old records
   */
  private cleanup(): void {
    const now = Date.now();
    const cutoff = now - this.windowMs;
    this.requests = this.requests.filter(r => r.timestamp > cutoff);
  }
}
