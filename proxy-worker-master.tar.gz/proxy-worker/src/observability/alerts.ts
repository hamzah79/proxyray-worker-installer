import { AppConfig } from "../config";
import { logger } from "../observability/logger";
import { metricsCollector } from "../observability/metrics";

export interface AlertRule {
  name: string;
  condition: () => boolean;
  message: string;
  cooldownMs: number;
  lastTriggeredAt: number | null;
}

export class AlertManager {
  private rules: AlertRule[] = [];
  private checkInterval: NodeJS.Timeout | null = null;

  constructor(private readonly config: AppConfig) {
    this.initializeRules();
  }

  private initializeRules(): void {
    // Rule 1: Low success rate
    this.rules.push({
      name: "low_success_rate",
      condition: () => {
        const successRate = metricsCollector.getSuccessRate();
        return successRate < 80 && metricsCollector.getGlobalMetrics().totalRequests > 10;
      },
      message: "Success rate dropped below 80%",
      cooldownMs: 300000, // 5 minutes
      lastTriggeredAt: null
    });

    // Rule 2: No healthy backends
    this.rules.push({
      name: "no_healthy_backends",
      condition: () => metricsCollector.getHealthyBackendsCount() === 0,
      message: "No healthy backends available",
      cooldownMs: 60000, // 1 minute
      lastTriggeredAt: null
    });

    // Rule 3: High average response time
    this.rules.push({
      name: "high_response_time",
      condition: () => {
        const metrics = metricsCollector.getGlobalMetrics();
        return metrics.avgResponseTime > 15000 && metrics.totalRequests > 5;
      },
      message: "Average response time exceeded 15 seconds",
      cooldownMs: 300000, // 5 minutes
      lastTriggeredAt: null
    });

    // Rule 4: Low healthy backend ratio
    this.rules.push({
      name: "low_healthy_ratio",
      condition: () => {
        const backends = metricsCollector.getBackendMetrics();
        if (backends.length === 0) return false;
        const healthyCount = metricsCollector.getHealthyBackendsCount();
        const ratio = healthyCount / backends.length;
        return ratio < 0.5 && backends.length > 2;
      },
      message: "Less than 50% of backends are healthy",
      cooldownMs: 180000, // 3 minutes
      lastTriggeredAt: null
    });
  }

  start(): void {
    if (this.checkInterval) return;

    this.checkInterval = setInterval(() => {
      this.checkRules();
    }, 30000); // Check every 30 seconds

    logger.info("alert manager started");
  }

  stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      logger.info("alert manager stopped");
    }
  }

  private checkRules(): void {
    const now = Date.now();

    for (const rule of this.rules) {
      // Check cooldown
      if (rule.lastTriggeredAt && now - rule.lastTriggeredAt < rule.cooldownMs) {
        continue;
      }

      // Check condition
      if (rule.condition()) {
        this.triggerAlert(rule);
        rule.lastTriggeredAt = now;
      }
    }
  }

  private triggerAlert(rule: AlertRule): void {
    const metrics = metricsCollector.getGlobalMetrics();
    const summary = metricsCollector.getSummary();

    logger.error("ALERT", {
      rule: rule.name,
      message: rule.message,
      metrics: {
        totalRequests: metrics.totalRequests,
        successRate: metricsCollector.getSuccessRate().toFixed(2) + "%",
        avgResponseTime: metrics.avgResponseTime.toFixed(0) + "ms",
        healthyBackends: metricsCollector.getHealthyBackendsCount()
      },
      summary
    });

    // Here you could add integrations with external alerting systems:
    // - Send email via SMTP
    // - Post to Slack/Discord webhook
    // - Send SMS via Twilio
    // - Push notification via Firebase
    // Example:
    // await this.sendToWebhook(rule, metrics);
  }

  // Optional: webhook integration for external alerting
  private async sendToWebhook(rule: AlertRule, metrics: any): Promise<void> {
    // Implementation for webhook notifications
    // This is a placeholder for future integration
  }

  getActiveAlerts(): Array<{ name: string; message: string; triggeredAt: number }> {
    const now = Date.now();
    return this.rules
      .filter(rule => rule.lastTriggeredAt && now - rule.lastTriggeredAt < rule.cooldownMs)
      .map(rule => ({
        name: rule.name,
        message: rule.message,
        triggeredAt: rule.lastTriggeredAt!
      }));
  }
}
