import fs from "node:fs/promises";
import net from "node:net";
import path from "node:path";
import { ChildProcessWithoutNullStreams, spawn } from "node:child_process";

import { AppConfig } from "../config";
import { logger } from "../observability/logger";
import { TorBackend } from "../types";

interface TorProcess {
  backend: TorBackend;
  process: ChildProcessWithoutNullStreams;
}

const RESPAWN_DELAY_MS = 5000;
const MAX_RESPAWN_ATTEMPTS = 10;

export class TorManager {
  private readonly config: AppConfig;
  private readonly processes = new Map<number, TorProcess>();
  private readonly backends: TorBackend[] = [];
  private readonly respawnAttempts = new Map<number, number>();
  private readonly reconfiguring = new Set<number>();
  private stopped = false;

  constructor(config: AppConfig) {
    this.config = config;
  }

  async start(): Promise<void> {
    await fs.mkdir(this.config.torDataDir, { recursive: true });

    for (let i = 0; i < this.config.torInstances; i += 1) {
      const backend: TorBackend = {
        id: i,
        socksPort: this.config.torBaseSocksPort + i,
        controlPort: this.config.torBaseControlPort + i,
        dnsPort: this.config.torBaseDnsPort + i,
        healthy: true, // WORKAROUND: Set to true by default, health monitor will update
        exitIp: null,
        countryCode: null,
        countryName: null,
        lastCheckedAt: null
      };

      await this.startInstance(backend);
      this.backends.push(backend);
    }
  }

  getBackends(): TorBackend[] {
    return this.backends;
  }

  markHealth(backendId: number, healthy: boolean): void {
    const backend = this.backends.find((item) => item.id === backendId);
    if (!backend) return;
    backend.healthy = healthy;
  }

  updateBackendTelemetry(
    backendId: number,
    telemetry: {
      exitIp?: string | null;
      countryCode?: string | null;
      countryName?: string | null;
      lastCheckedAt?: string | null;
    }
  ): void {
    const backend = this.backends.find((item) => item.id === backendId);
    if (!backend) return;

    if (telemetry.exitIp !== undefined) backend.exitIp = telemetry.exitIp;
    if (telemetry.countryCode !== undefined) backend.countryCode = telemetry.countryCode;
    if (telemetry.countryName !== undefined) backend.countryName = telemetry.countryName;
    if (telemetry.lastCheckedAt !== undefined) backend.lastCheckedAt = telemetry.lastCheckedAt;
  }

  async signalNewnym(backend: TorBackend): Promise<boolean> {
    return new Promise((resolve) => {
      const socket = net.createConnection({ host: "127.0.0.1", port: backend.controlPort });
      let resolved = false;

      socket.setTimeout(3000);

      socket.on("connect", () => {
        socket.write('AUTHENTICATE ""\r\n');
        socket.write("SIGNAL NEWNYM\r\n");
        socket.write("QUIT\r\n");
      });

      socket.on("data", (chunk: Buffer) => {
        const text = chunk.toString("utf8");
        if (text.includes("250 OK") && !resolved) {
          resolved = true;
          socket.end();
          resolve(true);
        }
      });

      socket.on("timeout", () => { socket.destroy(); });
      socket.on("error", () => { if (!resolved) { resolved = true; resolve(false); } });
      socket.on("close", () => { if (!resolved) { resolved = true; resolve(false); } });
    });
  }

  async stop(): Promise<void> {
    this.stopped = true;
    for (const { process } of this.processes.values()) {
      process.kill("SIGTERM");
    }
    this.processes.clear();
  }

  // --- Dynamic instance management ---

  async addInstance(exitNodes?: string | null, strictNodes?: boolean): Promise<TorBackend | null> {
    const maxId = this.backends.length > 0 ? Math.max(...this.backends.map(b => b.id)) : -1;
    const newId = maxId + 1;
    const backend: TorBackend = {
      id: newId,
      socksPort: this.config.torBaseSocksPort + newId,
      controlPort: this.config.torBaseControlPort + newId,
      dnsPort: this.config.torBaseDnsPort + newId,
      healthy: false,
      exitIp: null,
      countryCode: null,
      countryName: null,
      lastCheckedAt: null
    };
    try {
      await this.startInstanceWithOpts(backend, exitNodes, strictNodes);
      this.backends.push(backend);
      logger.info("tor instance added dynamically", { backendId: newId });
      return backend;
    } catch (error) {
      logger.error("failed to add tor instance", { backendId: newId, error: String(error) });
      return null;
    }
  }

  async removeInstance(backendId?: number): Promise<boolean> {
    const targetId = backendId !== undefined ? backendId : (this.backends.length > 0 ? this.backends[this.backends.length - 1].id : -1);
    if (targetId < 0) return false;
    const record = this.processes.get(targetId);
    if (record) {
      record.process.kill("SIGTERM");
      this.processes.delete(targetId);
    }
    const idx = this.backends.findIndex(b => b.id === targetId);
    if (idx !== -1) {
      this.backends.splice(idx, 1);
      logger.info("tor instance removed dynamically", { backendId: targetId });
      return true;
    }
    return false;
  }

  async reconfigureInstance(backendId: number, opts: { exitNodes?: string | null; strictNodes?: boolean }): Promise<boolean> {
    const backend = this.backends.find(b => b.id === backendId);
    if (!backend) return false;
    const record = this.processes.get(backendId);
    if (record) {
      // Mark as reconfiguring to prevent respawn from interfering
      this.reconfiguring.add(backendId);
      record.process.kill("SIGTERM");
      this.processes.delete(backendId);
      // Give the old process time to fully exit before starting new one
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    backend.healthy = false;
    try {
      await this.startInstanceWithOpts(backend, opts.exitNodes, opts.strictNodes);
      logger.info("tor instance reconfigured", { backendId, exitNodes: opts.exitNodes, strictNodes: opts.strictNodes });
      return true;
    } catch (error) {
      logger.error("tor instance reconfigure failed", { backendId, error: String(error) });
      return false;
    } finally {
      this.reconfiguring.delete(backendId);
    }
  }

  async reconfigureAll(opts: { exitNodes?: string | null; strictNodes?: boolean }): Promise<number> {
    let count = 0;
    for (const backend of [...this.backends]) {
      const ok = await this.reconfigureInstance(backend.id, opts);
      if (ok) count++;
    }
    return count;
  }

  async scaleInstances(targetCount: number, exitNodes?: string | null, strictNodes?: boolean): Promise<{ added: number; removed: number }> {
    logger.info("scaleInstances called", { targetCount, currentCount: this.backends.length, exitNodes, strictNodes });
    let added = 0;
    let removed = 0;
    while (this.backends.length < targetCount) {
      logger.info("adding tor instance", { currentCount: this.backends.length, targetCount });
      const result = await this.addInstance(exitNodes, strictNodes);
      if (result) { added++; logger.info("tor instance added", { backendId: result.id, socksPort: result.socksPort }); }
      else { logger.error("failed to add tor instance, stopping scale-up"); break; }
    }
    while (this.backends.length > targetCount && this.backends.length > 0) {
      const ok = await this.removeInstance();
      if (ok) removed++;
      else break;
    }
    return { added, removed };
  }

  // --- Private helpers ---

  private async startInstanceWithOpts(backend: TorBackend, exitNodes?: string | null, strictNodes?: boolean): Promise<void> {
    const useExitNodes = exitNodes !== undefined ? exitNodes : this.config.torExitNodes;
    const useStrictNodes = strictNodes !== undefined ? strictNodes : this.config.torStrictNodes;
    const instanceDir = path.join(this.config.torDataDir, `tor-${backend.id}`);
    await fs.mkdir(instanceDir, { recursive: true });

    const torrcPath = path.join(instanceDir, "torc");
    const torrc = [
      "Log notice stdout",
      `DataDirectory ${path.join(instanceDir, "data")}`,
      `SocksPort 127.0.0.1:${backend.socksPort} IsolateClientAddr IsolateSOCKSAuth`,
      `ControlPort 127.0.0.1:${backend.controlPort}`,
      `DNSPort 127.0.0.1:${backend.dnsPort}`,
      "CookieAuthentication 0",
      "MaxCircuitDirtiness 600",
      "NewCircuitPeriod 30",
      "MaxClientCircuitsPending 3",
      ...(useExitNodes ? [`ExitNodes ${useExitNodes}`] : []),
      ...(useExitNodes && useStrictNodes ? ["StrictNodes 1"] : [])
    ].join("\n");

    await fs.writeFile(torrcPath, torrc, "utf8");

    const child = spawn(this.config.torBinaryPath, ["-f", torrcPath], { stdio: "pipe" });

    child.stdout.on("data", (chunk: Buffer) => {
      logger.info("tor stdout", { backendId: backend.id, line: chunk.toString("utf8").trim() });
    });

    child.stderr.on("data", (chunk: Buffer) => {
      logger.warn("tor stderr", { backendId: backend.id, line: chunk.toString("utf8").trim() });
    });

    child.on("exit", (code: number | null) => {
      logger.error("tor instance exited", { backendId: backend.id, code });
      const rec = this.processes.get(backend.id);
      if (rec && rec.process.pid === child.pid) {
        this.processes.delete(backend.id);
        backend.healthy = false;
      }
      // Skip respawn if this instance is being reconfigured (reconfigureInstance handles restart)
      if (!this.stopped && !this.reconfiguring.has(backend.id)) {
        this.scheduleRespawn(backend);
      }
    });

    this.processes.set(backend.id, { backend, process: child });
  }

  private async startInstance(backend: TorBackend): Promise<void> {
    await this.startInstanceWithOpts(backend);
  }

  private scheduleRespawn(backend: TorBackend): void {
    const attempts = (this.respawnAttempts.get(backend.id) ?? 0) + 1;
    this.respawnAttempts.set(backend.id, attempts);

    if (attempts > MAX_RESPAWN_ATTEMPTS) {
      logger.error("tor instance exceeded max respawn attempts, giving up", {
        backendId: backend.id,
        attempts
      });
      return;
    }

    const delay = RESPAWN_DELAY_MS * Math.min(attempts, 6);
    logger.warn("tor instance will respawn", { backendId: backend.id, attempt: attempts, delayMs: delay });

    setTimeout(async () => {
      if (this.stopped) return;
      try {
        await this.startInstance(backend);
        logger.info("tor instance respawned", { backendId: backend.id, attempt: attempts });
        this.respawnAttempts.set(backend.id, 0);
      } catch (error) {
        logger.error("tor instance respawn failed", { backendId: backend.id, error: String(error) });
        this.scheduleRespawn(backend);
      }
    }, delay);
  }
}
