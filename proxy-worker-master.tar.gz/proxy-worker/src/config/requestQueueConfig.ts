/**
 * Request Queue Configuration
 */
export interface RequestQueueConfig {
  maxQueueSize: number;           // Max requests in queue
  maxWaitTime: number;            // Max wait time in queue (ms)
  concurrencyLimit: number;       // Max concurrent requests
  priorityLevels: number;         // Number of priority levels (1-5)
  enablePriority: boolean;        // Enable priority queuing
}

/**
 * Load request queue configuration from environment variables
 */
export function loadRequestQueueConfigFromEnv(): RequestQueueConfig {
  return {
    maxQueueSize: parseInt(process.env.QUEUE_MAX_SIZE || '1000', 10),
    maxWaitTime: parseInt(process.env.QUEUE_MAX_WAIT_TIME_MS || '30000', 10),
    concurrencyLimit: parseInt(process.env.QUEUE_CONCURRENCY_LIMIT || '100', 10),
    priorityLevels: Math.min(5, Math.max(1, parseInt(process.env.QUEUE_PRIORITY_LEVELS || '3', 10))),
    enablePriority: process.env.QUEUE_ENABLE_PRIORITY !== 'false',
  };
}
