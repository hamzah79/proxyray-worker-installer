import fs from "node:fs/promises";
import path from "node:path";
import Redis from "ioredis";

import { AppConfig } from "./index";
import { TorInstanceRoutingConfig, TorRoutingMode, TorUserRoutingPreference } from "../types";
import { RedisStateStore } from "./redisStateStore";
import { logger } from "../observability/logger";

export interface RuntimeState {
  users: Record<string, string>;
  userIpWhitelist: Record<string, string[]>;
  maxConcurrentPerUser: number;
  proxyIpHost: string;
  proxyDomains: string[];
  torRouting: Record<string, TorInstanceRoutingConfig>;
  userTorRouting: Record<string, TorUserRoutingPreference>;
  updatedAt: string;
}

export class RuntimeStateStore {
  private state: RuntimeState;
  private redisStore: RedisStateStore | null = null;

  constructor(private readonly config: AppConfig) {
    this.state = {
      users: Object.fromEntries(config.users.entries()),
      userIpWhitelist: {},
      maxConcurrentPerUser: config.maxConcurrentPerUser,
      proxyIpHost: this.resolveDefaultProxyIpHost(),
      proxyDomains: [],
      torRouting: {},
      userTorRouting: {},
      updatedAt: new Date().toISOString()
    };
  }

  /**
   * Attach a Redis-backed store. When attached, all writes go to both
   * local memory + Redis, and the in-memory state is synced from Redis
   * periodically or on init. This enables multi-server shared state.
   */
  attachRedis(redis: Redis, prefix: string): void {
    this.redisStore = new RedisStateStore(redis, prefix);
    logger.info("runtime state store: redis backend attached", { prefix });
  }

  /** Returns true if Redis backend is active */
  hasRedis(): boolean {
    return this.redisStore !== null;
  }

  /** Get the underlying RedisStateStore (for direct access if needed) */
  getRedisStore(): RedisStateStore | null {
    return this.redisStore;
  }

  async init(): Promise<void> {
    const dir = path.dirname(this.config.runtimeStateFile);
    await fs.mkdir(dir, { recursive: true });

    // Step 1: Load from local file first (baseline)
    try {
      const raw = await fs.readFile(this.config.runtimeStateFile, "utf8");
      const parsed = JSON.parse(raw) as Partial<RuntimeState>;
      if (parsed.users && typeof parsed.users === "object") {
        this.state.users = parsed.users as Record<string, string>;
      }
      if (parsed.userIpWhitelist && typeof parsed.userIpWhitelist === "object") {
        this.state.userIpWhitelist = parsed.userIpWhitelist as Record<string, string[]>;
      }
      if (typeof parsed.maxConcurrentPerUser === "number") {
        this.state.maxConcurrentPerUser = parsed.maxConcurrentPerUser;
      }
      if (typeof parsed.proxyIpHost === "string" && parsed.proxyIpHost.trim()) {
        this.state.proxyIpHost = parsed.proxyIpHost.trim();
      }
      if (Array.isArray(parsed.proxyDomains)) {
        const uniqueDomains = new Set(
          parsed.proxyDomains
            .map((item) => (typeof item === "string" ? item.trim().toLowerCase() : ""))
            .filter((item) => item.length > 0)
        );
        this.state.proxyDomains = [...uniqueDomains].sort();
      }
      if (parsed.torRouting && typeof parsed.torRouting === "object") {
        this.state.torRouting = normalizeTorRouting(parsed.torRouting as Record<string, unknown>);
      }
      if (parsed.userTorRouting && typeof parsed.userTorRouting === "object") {
        this.state.userTorRouting = normalizeUserTorRouting(parsed.userTorRouting as Record<string, unknown>);
      }
      this.state.updatedAt = new Date().toISOString();
    } catch {
      await this.saveLocal();
    }

    // Step 2: If Redis is attached, seed Redis from local state (if empty),
    // then load from Redis (Redis is the source of truth in multi-server mode)
    if (this.redisStore) {
      try {
        await this.redisStore.seedIfEmpty(this.state);
        const redisState = await this.redisStore.getSnapshot();
        this.state = redisState;
        logger.info("runtime state store: loaded state from redis");
        // Also persist Redis state back to local file as backup
        await this.saveLocal();
      } catch (error) {
        logger.warn("runtime state store: failed to sync with redis, using local state", {
          error: String(error)
        });
      }
    }
  }

  /**
   * Sync in-memory state from Redis. Call this periodically on workers
   * to pick up changes made by the master or other workers.
   */
  async syncFromRedis(): Promise<boolean> {
    if (!this.redisStore) {
      return false;
    }

    try {
      const redisState = await this.redisStore.getSnapshot();
      this.state = redisState;
      return true;
    } catch (error) {
      logger.warn("runtime state store: redis sync failed", { error: String(error) });
      return false;
    }
  }

  getSnapshot(): RuntimeState {
    return {
      users: { ...this.state.users },
      userIpWhitelist: { ...this.state.userIpWhitelist },
      maxConcurrentPerUser: this.state.maxConcurrentPerUser,
      proxyIpHost: this.state.proxyIpHost,
      proxyDomains: [...this.state.proxyDomains],
      torRouting: cloneTorRouting(this.state.torRouting),
      userTorRouting: cloneUserTorRouting(this.state.userTorRouting),
      updatedAt: this.state.updatedAt
    };
  }

  getUsersMap(): Map<string, string> {
    return new Map(Object.entries(this.state.users));
  }

  getMaxConcurrentPerUser(): number {
    return this.state.maxConcurrentPerUser;
  }

  getProxyIpHost(): string {
    return this.state.proxyIpHost;
  }

  getProxyDomains(): string[] {
    return [...this.state.proxyDomains];
  }

  getTorRoutingConfig(instanceId: number): TorInstanceRoutingConfig {
    return this.ensureTorRoutingConfig(instanceId);
  }

  getTorRoutingSnapshot(): Record<string, TorInstanceRoutingConfig> {
    return cloneTorRouting(this.state.torRouting);
  }

  getUserTorRoutingPreference(username: string): TorUserRoutingPreference {
    return this.ensureUserTorRoutingPreference(username);
  }

  getUserTorRoutingSnapshot(): Record<string, TorUserRoutingPreference> {
    return cloneUserTorRouting(this.state.userTorRouting);
  }

  async setUserTorRoutingPreference(
    username: string,
    updates: Partial<Pick<TorUserRoutingPreference, "mode" | "countryCode">>
  ): Promise<TorUserRoutingPreference> {
    const current = this.ensureUserTorRoutingPreference(username);
    const next: TorUserRoutingPreference = {
      mode: updates.mode === "sticky" ? "sticky" : "random",
      countryCode: normalizeCountryCode(updates.countryCode ?? current.countryCode),
      updatedAt: new Date().toISOString()
    };

    if (next.mode === "random") {
      next.countryCode = null;
    }

    this.state.userTorRouting[username] = next;
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return next;
  }

  async resetUserTorRoutingPreference(username: string): Promise<void> {
    delete this.state.userTorRouting[username];
    this.state.updatedAt = new Date().toISOString();
    await this.save();
  }

  private ensureTorRoutingConfig(instanceId: number): TorInstanceRoutingConfig {
    const key = String(instanceId);
    const existing = this.state.torRouting[key];
    if (existing) {
      return existing;
    }

    const created: TorInstanceRoutingConfig = {
      mode: "random",
      targetCountryCode: null,
      weightPercent: 70,
      strict: false,
      fallbackCountryCode: null,
      updatedAt: new Date().toISOString()
    };

    this.state.torRouting[key] = created;
    return created;
  }

  private ensureUserTorRoutingPreference(username: string): TorUserRoutingPreference {
    const existing = this.state.userTorRouting[username];
    if (existing) {
      return existing;
    }

    const created: TorUserRoutingPreference = {
      mode: "random",
      countryCode: null,
      updatedAt: new Date().toISOString()
    };

    this.state.userTorRouting[username] = created;
    return created;
  }

  async setTorRoutingConfig(
    instanceId: number,
    updates: Partial<Pick<TorInstanceRoutingConfig, "mode" | "targetCountryCode" | "weightPercent" | "strict" | "fallbackCountryCode">>
  ): Promise<TorInstanceRoutingConfig> {
    const current = this.ensureTorRoutingConfig(instanceId);
    const next: TorInstanceRoutingConfig = {
      mode: normalizeTorRoutingMode(updates.mode ?? current.mode),
      targetCountryCode: normalizeCountryCode(updates.targetCountryCode ?? current.targetCountryCode),
      weightPercent: normalizeWeightPercent(updates.weightPercent ?? current.weightPercent),
      strict: typeof updates.strict === "boolean" ? updates.strict : current.strict,
      fallbackCountryCode: normalizeCountryCode(updates.fallbackCountryCode ?? current.fallbackCountryCode),
      updatedAt: new Date().toISOString()
    };

    if (next.mode === "random") {
      next.targetCountryCode = null;
      next.fallbackCountryCode = null;
      next.strict = false;
    }

    this.state.torRouting[String(instanceId)] = next;
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return next;
  }

  async resetTorRoutingConfig(instanceId: number): Promise<void> {
    delete this.state.torRouting[String(instanceId)];
    this.state.updatedAt = new Date().toISOString();
    await this.save();
  }

  async upsertUser(username: string, password: string): Promise<void> {
    this.state.users[username] = password;
    if (!this.state.userIpWhitelist[username]) {
      this.state.userIpWhitelist[username] = [];
    }
    this.state.updatedAt = new Date().toISOString();
    await this.save();
  }

  async deleteUser(username: string): Promise<boolean> {
    if (!this.state.users[username]) {
      return false;
    }

    delete this.state.users[username];
    delete this.state.userIpWhitelist[username];
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return true;
  }

  getWhitelistedIps(username: string): string[] {
    return [...(this.state.userIpWhitelist[username] ?? [])];
  }

  /**
   * Check whether `rawIp` is whitelisted for `username`.
   *
   * When the whitelist is empty (user has not configured any IPs yet) the
   * first connecting IP is **automatically added** to the whitelist so the
   * user can start using the proxy immediately.  Subsequent connections
   * from other IPs will be rejected until the user explicitly adds them
   * via the dashboard.
   */
  isIpWhitelisted(username: string, rawIp: string | null | undefined): boolean {
    const whitelist = this.state.userIpWhitelist[username] ?? [];
    const ip = normalizeIp(rawIp);

    if (whitelist.length === 0) {
      if (!ip) return false;
      // Auto-whitelist the very first IP that connects
      this.autoWhitelistFirstIp(username, ip);
      return true;
    }

    if (!ip) return false;
    return whitelist.includes(ip);
  }

  /**
   * Automatically whitelist the first IP for a user (fire-and-forget).
   * Called only when the user's whitelist is completely empty.
   */
  private autoWhitelistFirstIp(username: string, ip: string): void {
    const current = new Set(this.state.userIpWhitelist[username] ?? []);
    current.add(ip);
    this.state.userIpWhitelist[username] = [...current].sort();
    this.state.updatedAt = new Date().toISOString();
    // Persist asynchronously — don't block the connection
    this.save().catch(() => { /* best-effort */ });
    logger.info("auto-whitelisted first IP for user", { username, ip });
  }

  async addWhitelistedIp(username: string, rawIp: string): Promise<string[]> {
    const ip = normalizeIp(rawIp);
    if (!ip) {
      throw new Error("invalid_ip");
    }

    const current = new Set(this.state.userIpWhitelist[username] ?? []);
    current.add(ip);
    this.state.userIpWhitelist[username] = [...current].sort();
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return [...this.state.userIpWhitelist[username]];
  }

  async removeWhitelistedIp(username: string, rawIp: string): Promise<string[]> {
    const ip = normalizeIp(rawIp);
    if (!ip) {
      throw new Error("invalid_ip");
    }

    const current = new Set(this.state.userIpWhitelist[username] ?? []);
    current.delete(ip);
    this.state.userIpWhitelist[username] = [...current].sort();
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return [...this.state.userIpWhitelist[username]];
  }

  async setMaxConcurrentPerUser(value: number): Promise<void> {
    this.state.maxConcurrentPerUser = value;
    this.state.updatedAt = new Date().toISOString();
    await this.save();
  }

  async setProxyIpHost(host: string): Promise<void> {
    const normalized = normalizeProxyHost(host);
    if (!normalized) {
      throw new Error("invalid_proxy_ip_host");
    }

    this.state.proxyIpHost = normalized;
    this.state.updatedAt = new Date().toISOString();
    await this.save();
  }

  async addProxyDomain(domain: string): Promise<string[]> {
    const normalized = normalizeDomain(domain);
    if (!normalized) {
      throw new Error("invalid_domain");
    }

    const current = new Set(this.state.proxyDomains);
    current.add(normalized);
    this.state.proxyDomains = [...current].sort();
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return [...this.state.proxyDomains];
  }

  async updateProxyDomain(oldDomain: string, newDomain: string): Promise<string[]> {
    const oldNormalized = normalizeDomain(oldDomain);
    const newNormalized = normalizeDomain(newDomain);

    if (!oldNormalized || !newNormalized) {
      throw new Error("invalid_domain");
    }

    const current = new Set(this.state.proxyDomains);
    if (!current.has(oldNormalized)) {
      throw new Error("domain_not_found");
    }

    current.delete(oldNormalized);
    current.add(newNormalized);
    this.state.proxyDomains = [...current].sort();
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return [...this.state.proxyDomains];
  }

  async removeProxyDomain(domain: string): Promise<string[]> {
    const normalized = normalizeDomain(domain);
    if (!normalized) {
      throw new Error("invalid_domain");
    }

    const current = new Set(this.state.proxyDomains);
    if (!current.has(normalized)) {
      throw new Error("domain_not_found");
    }

    current.delete(normalized);
    this.state.proxyDomains = [...current].sort();
    this.state.updatedAt = new Date().toISOString();
    await this.save();
    return [...this.state.proxyDomains];
  }

  private resolveDefaultProxyIpHost(): string {
    try {
      const base = new URL(this.config.appBaseUrl);
      const host = (base.hostname || "").trim();
      if (host) {
        return host;
      }
    } catch {
      // ignore malformed APP_BASE_URL and use fallback
    }

    return "127.0.0.1";
  }

  private async saveLocal(): Promise<void> {
    await fs.writeFile(this.config.runtimeStateFile, JSON.stringify(this.state, null, 2), "utf8");
  }

  private async save(): Promise<void> {
    // Always save to local file (backup / single-server mode)
    await this.saveLocal();

    // If Redis is attached, also push the full state to Redis
    if (this.redisStore) {
      try {
        await this.redisStore.setFullState(this.state);
      } catch (error) {
        logger.warn("runtime state store: failed to write to redis", { error: String(error) });
      }
    }
  }
}

function cloneTorRouting(source: Record<string, TorInstanceRoutingConfig>): Record<string, TorInstanceRoutingConfig> {
  return Object.fromEntries(
    Object.entries(source).map(([instanceId, config]) => [instanceId, { ...config }])
  );
}

function cloneUserTorRouting(source: Record<string, TorUserRoutingPreference>): Record<string, TorUserRoutingPreference> {
  return Object.fromEntries(
    Object.entries(source).map(([username, config]) => [username, { ...config }])
  );
}

function normalizeTorRouting(input: Record<string, unknown>): Record<string, TorInstanceRoutingConfig> {
  const output: Record<string, TorInstanceRoutingConfig> = {};

  for (const [instanceId, rawConfig] of Object.entries(input)) {
    if (!rawConfig || typeof rawConfig !== "object") {
      continue;
    }

    const config = rawConfig as Partial<TorInstanceRoutingConfig>;
    output[instanceId] = {
      mode: normalizeTorRoutingMode(config.mode ?? "random"),
      targetCountryCode: normalizeCountryCode(config.targetCountryCode),
      weightPercent: normalizeWeightPercent(config.weightPercent),
      strict: Boolean(config.strict),
      fallbackCountryCode: normalizeCountryCode(config.fallbackCountryCode),
      updatedAt: typeof config.updatedAt === "string" && config.updatedAt.trim() ? config.updatedAt : new Date().toISOString()
    };
  }

  return output;
}

function normalizeUserTorRouting(input: Record<string, unknown>): Record<string, TorUserRoutingPreference> {
  const output: Record<string, TorUserRoutingPreference> = {};

  for (const [username, rawConfig] of Object.entries(input)) {
    if (!rawConfig || typeof rawConfig !== "object") {
      continue;
    }

    const config = rawConfig as Partial<TorUserRoutingPreference>;
    output[username] = {
      mode: config.mode === "sticky" ? "sticky" : "random",
      countryCode: normalizeCountryCode(config.countryCode),
      updatedAt: typeof config.updatedAt === "string" && config.updatedAt.trim() ? config.updatedAt : new Date().toISOString()
    };
  }

  return output;
}

function normalizeTorRoutingMode(value: TorRoutingMode | string | null | undefined): TorRoutingMode {
  return value === "sticky" || value === "pinned-country" ? value : "random";
}

function normalizeCountryCode(value: string | null | undefined): string | null {
  if (!value || typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toUpperCase();
  if (!/^[A-Z]{2,3}$/.test(normalized)) {
    return null;
  }

  return normalized;
}

function normalizeWeightPercent(value: number | null | undefined): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return 70;
  }

  const rounded = Math.round(parsed);
  if (rounded < 1) {
    return 1;
  }

  if (rounded > 100) {
    return 100;
  }

  return rounded;
}

function normalizeIp(rawIp: string | null | undefined): string | null {
  if (!rawIp || typeof rawIp !== "string") {
    return null;
  }

  let value = rawIp.trim();
  if (!value) {
    return null;
  }

  if (value.startsWith("::ffff:")) {
    value = value.slice(7);
  }

  return value;
}

function normalizeProxyHost(rawHost: string | null | undefined): string | null {
  if (!rawHost || typeof rawHost !== "string") {
    return null;
  }

  const value = rawHost.trim().toLowerCase();
  if (!value) {
    return null;
  }

  if (/^[a-z0-9.-]+$/.test(value)) {
    return value;
  }

  return null;
}

function normalizeDomain(rawDomain: string | null | undefined): string | null {
  if (!rawDomain || typeof rawDomain !== "string") {
    return null;
  }

  const value = rawDomain.trim().toLowerCase();
  if (!value) {
    return null;
  }

  if (!/^[a-z0-9.-]+$/.test(value)) {
    return null;
  }

  if (!value.includes(".")) {
    return null;
  }

  if (value.startsWith(".") || value.endsWith(".")) {
    return null;
  }

  return value;
}
