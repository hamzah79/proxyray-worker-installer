/**
 * Retry configuration for automatic retry with exponential backoff
 */
export interface RetryConfig {
  /** Maximum number of retry attempts */
  maxAttempts: number;
  
  /** Initial delay in milliseconds before first retry */
  initialDelayMs: number;
  
  /** Maximum delay in milliseconds between retries */
  maxDelayMs: number;
  
  /** Multiplier for exponential backoff (e.g., 2 = double each time) */
  backoffMultiplier: number;
  
  /** Jitter factor to add randomness (0.0 - 1.0) */
  jitterFactor: number;
  
  /** HTTP status codes that should trigger a retry */
  retryableStatusCodes: number[];
  
  /** HTTP status codes that should NOT trigger a retry */
  nonRetryableStatusCodes: number[];
  
  /** Network error codes that should trigger a retry */
  retryableErrorCodes: string[];
}

/**
 * Default retry configuration
 */
export const defaultRetryConfig: RetryConfig = {
  maxAttempts: 3,
  initialDelayMs: 100,
  maxDelayMs: 5000,
  backoffMultiplier: 2,
  jitterFactor: 0.1,
  retryableStatusCodes: [408, 429, 500, 502, 503, 504],
  nonRetryableStatusCodes: [400, 401, 403, 404, 407],
  retryableErrorCodes: [
    'ECONNREFUSED',
    'ECONNRESET',
    'ETIMEDOUT',
    'ENOTFOUND',
    'ENETUNREACH',
    'EHOSTUNREACH'
  ]
};

/**
 * Load retry configuration from environment variables
 */
export function loadRetryConfigFromEnv(): RetryConfig {
  return {
    maxAttempts: parseInt(process.env.RETRY_MAX_ATTEMPTS || '3', 10),
    initialDelayMs: parseInt(process.env.RETRY_INITIAL_DELAY_MS || '100', 10),
    maxDelayMs: parseInt(process.env.RETRY_MAX_DELAY_MS || '5000', 10),
    backoffMultiplier: parseFloat(process.env.RETRY_BACKOFF_MULTIPLIER || '2'),
    jitterFactor: parseFloat(process.env.RETRY_JITTER_FACTOR || '0.1'),
    retryableStatusCodes: defaultRetryConfig.retryableStatusCodes,
    nonRetryableStatusCodes: defaultRetryConfig.nonRetryableStatusCodes,
    retryableErrorCodes: defaultRetryConfig.retryableErrorCodes
  };
}
