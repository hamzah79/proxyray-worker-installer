import Redis from "ioredis";

import { logger } from "../observability/logger";
import { TorInstanceRoutingConfig, TorRoutingMode, TorUserRoutingPreference } from "../types";
import { RuntimeState } from "./runtimeStateStore";

/**
 * Redis-backed state store that mirrors the RuntimeState interface.
 * All state is stored in Redis hash keys so multiple servers can share state.
 * Key layout (all prefixed with `{prefix}:`):
 *   state:users              → Hash  { username: password }
 *   state:whitelist:{user}   → Set   of IPs
 *   state:config             → Hash  { maxConcurrentPerUser, proxyIpHost, updatedAt }
 *   state:domains            → Set   of domain strings
 *   state:tor-routing:{id}   → Hash  { mode, targetCountryCode, ... }
 *   state:user-routing:{u}   → Hash  { mode, countryCode, updatedAt }
 */
export class RedisStateStore {
  private readonly prefix: string;

  constructor(
    private readonly redis: Redis,
    prefix: string
  ) {
    this.prefix = prefix ? `${prefix}:` : "proxy:";
  }

  private key(suffix: string): string {
    return `${this.prefix}${suffix}`;
  }

  // ── Initialization ────────────────────────────────

  /**
   * Seed Redis with the given state if keys don't exist yet.
   * This is called once at startup so that the first Master populates Redis
   * from its local file, and subsequent Workers just read from Redis.
   */
  async seedIfEmpty(state: RuntimeState): Promise<void> {
    const exists = await this.redis.exists(this.key("state:config"));
    if (exists) {
      logger.info("redis state already seded, skipping");
      return;
    }

    logger.info("seding redis state from local snapshot");
    await this.setFullState(state);
  }

  async setFullState(state: RuntimeState): Promise<void> {
    const pipeline = this.redis.pipeline();

    // Users
    const usersKey = this.key("state:users");
    pipeline.del(usersKey);
    if (Object.keys(state.users).length > 0) {
      pipeline.hset(usersKey, state.users);
    }

    // Whitelist IPs
    for (const [username, ips] of Object.entries(state.userIpWhitelist)) {
      const wlKey = this.key(`state:whitelist:${username}`);
      pipeline.del(wlKey);
      if (ips.length > 0) {
        pipeline.sadd(wlKey, ...ips);
      }
    }

    // Config
    pipeline.hset(this.key("state:config"), {
      maxConcurrentPerUser: String(state.maxConcurrentPerUser),
      proxyIpHost: state.proxyIpHost,
      updatedAt: state.updatedAt
    });

    // Domains
    const domainsKey = this.key("state:domains");
    pipeline.del(domainsKey);
    if (state.proxyDomains.length > 0) {
      pipeline.sadd(domainsKey, ...state.proxyDomains);
    }

    // Tor routing
    for (const [instanceId, config] of Object.entries(state.torRouting)) {
      pipeline.hset(this.key(`state:tor-routing:${instanceId}`), serializeTorRouting(config));
    }

    // User tor routing
    for (const [username, pref] of Object.entries(state.userTorRouting)) {
      pipeline.hset(this.key(`state:user-routing:${username}`), serializeUserRouting(pref));
    }

    await pipeline.exec();
    logger.info("redis state seeded successfully");
  }

  // ─── Full snapshot (for backward compat / admin API) ────────────

  async getSnapshot(): Promise<RuntimeState> {
    const users = await this.getUsers();
    const userIpWhitelist: Record<string, string[]> = {};
    for (const username of Object.keys(users)) {
      userIpWhitelist[username] = await this.getWhitelistedIps(username);
    }

    const configRaw = await this.redis.hgetall(this.key("state:config"));
    const maxConcurrentPerUser = configRaw.maxConcurrentPerUser ? Number(configRaw.maxConcurrentPerUser) : 200;
    const proxyIpHost = configRaw.proxyIpHost || "127.0.0.1";
    const updatedAt = configRaw.updatedAt || new Date().toISOString();

    const proxyDomains = await this.getProxyDomains();
    const torRouting = await this.getAllTorRouting();
    const userTorRouting = await this.getAllUserTorRouting();

    return {
      users,
      userIpWhitelist,
      maxConcurrentPerUser,
      proxyIpHost,
      proxyDomains,
      torRouting,
      userTorRouting,
      updatedAt
    };
  }

  // ─── Users ────────────────────────────────

  async getUsers(): Promise<Record<string, string>> {
    return await this.redis.hgetall(this.key("state:users"));
  }

  async getUserPassword(username: string): Promise<string | null> {
    return await this.redis.hget(this.key("state:users"), username);
  }

  async upsertUser(username: string, password: string): Promise<void> {
    await this.redis.hset(this.key("state:users"), username, password);
    await this.touchUpdatedAt();
  }

  async deleteUser(username: string): Promise<boolean> {
    const removed = await this.redis.hdel(this.key("state:users"), username);
    await this.redis.del(this.key(`state:whitelist:${username}`));
    await this.redis.del(this.key(`state:user-routing:${username}`));
    await this.touchUpdatedAt();
    return removed > 0;
  }

  // ─── IP Whitelist ────────────────────────────────

  async getWhitelistedIps(username: string): Promise<string[]> {
    const ips = await this.redis.smembers(this.key(`state:whitelist:${username}`));
    return ips.sort();
  }

  async isIpWhitelisted(username: string, ip: string): Promise<boolean> {
    return (await this.redis.sismember(this.key(`state:whitelist:${username}`), ip)) === 1;
  }

  async addWhitelistedIp(username: string, ip: string): Promise<string[]> {
    await this.redis.sadd(this.key(`state:whitelist:${username}`), ip);
    await this.touchUpdatedAt();
    return this.getWhitelistedIps(username);
  }

  async removeWhitelistedIp(username: string, ip: string): Promise<string[]> {
    await this.redis.srem(this.key(`state:whitelist:${username}`), ip);
    await this.touchUpdatedAt();
    return this.getWhitelistedIps(username);
  }

  // ─── Config ────────────────────────────────

  async getMaxConcurrentPerUser(): Promise<number> {
    const val = await this.redis.hget(this.key("state:config"), "maxConcurrentPerUser");
    return val ? Number(val) : 200;
  }

  async setMaxConcurrentPerUser(value: number): Promise<void> {
    await this.redis.hset(this.key("state:config"), "maxConcurrentPerUser", String(value));
    await this.touchUpdatedAt();
  }

  async getProxyIpHost(): Promise<string> {
    const val = await this.redis.hget(this.key("state:config"), "proxyIpHost");
    return val || "127.0.0.1";
  }

  async setProxyIpHost(host: string): Promise<void> {
    await this.redis.hset(this.key("state:config"), "proxyIpHost", host);
    await this.touchUpdatedAt();
  }

  // ─── Proxy Domains ────────────────────────────────

  async getProxyDomains(): Promise<string[]> {
    const domains = await this.redis.smembers(this.key("state:domains"));
    return domains.sort();
  }

  async addProxyDomain(domain: string): Promise<string[]> {
    await this.redis.sadd(this.key("state:domains"), domain);
    await this.touchUpdatedAt();
    return this.getProxyDomains();
  }

  async removeProxyDomain(domain: string): Promise<string[]> {
    await this.redis.srem(this.key("state:domains"), domain);
    await this.touchUpdatedAt();
    return this.getProxyDomains();
  }

  async updateProxyDomain(oldDomain: string, newDomain: string): Promise<string[]> {
    const pipeline = this.redis.pipeline();
    pipeline.srem(this.key("state:domains"), oldDomain);
    pipeline.sadd(this.key("state:domains"), newDomain);
    await pipeline.exec();
    await this.touchUpdatedAt();
    return this.getProxyDomains();
  }

  // ─── Tor Instance Routing ────────────────────────────────

  async getTorRoutingConfig(instanceId: number): Promise<TorInstanceRoutingConfig> {
    const raw = await this.redis.hgetall(this.key(`state:tor-routing:${instanceId}`));
    if (!raw || !raw.mode) {
      return defaultTorRoutingConfig();
    }
    return deserializeTorRouting(raw);
  }

  async setTorRoutingConfig(instanceId: number, config: TorInstanceRoutingConfig): Promise<void> {
    await this.redis.hset(this.key(`state:tor-routing:${instanceId}`), serializeTorRouting(config));
    await this.touchUpdatedAt();
  }

  async resetTorRoutingConfig(instanceId: number): Promise<void> {
    await this.redis.del(this.key(`state:tor-routing:${instanceId}`));
    await this.touchUpdatedAt();
  }

  async getAllTorRouting(): Promise<Record<string, TorInstanceRoutingConfig>> {
    const keys = await this.redis.keys(this.key("state:tor-routing:*"));
    const result: Record<string, TorInstanceRoutingConfig> = {};
    for (const key of keys) {
      const instanceId = key.replace(this.key("state:tor-routing:"), "");
      const raw = await this.redis.hgetall(key);
      if (raw && raw.mode) {
        result[instanceId] = deserializeTorRouting(raw);
      }
    }
    return result;
  }

  // ─── User Tor Routing ────────────────────────────────

  async getUserTorRoutingPreference(username: string): Promise<TorUserRoutingPreference> {
    const raw = await this.redis.hgetall(this.key(`state:user-routing:${username}`));
    if (!raw || !raw.mode) {
      return defaultUserRoutingPreference();
    }
    return deserializeUserRouting(raw);
  }

  async setUserTorRoutingPreference(username: string, pref: TorUserRoutingPreference): Promise<void> {
    await this.redis.hset(this.key(`state:user-routing:${username}`), serializeUserRouting(pref));
    await this.touchUpdatedAt();
  }

  async resetUserTorRoutingPreference(username: string): Promise<void> {
    await this.redis.del(this.key(`state:user-routing:${username}`));
    await this.touchUpdatedAt();
  }

  async getAllUserTorRouting(): Promise<Record<string, TorUserRoutingPreference>> {
    const keys = await this.redis.keys(this.key("state:user-routing:*"));
    const result: Record<string, TorUserRoutingPreference> = {};
    for (const key of keys) {
      const username = key.replace(this.key("state:user-routing:"), "");
      const raw = await this.redis.hgetall(key);
      if (raw && raw.mode) {
        result[username] = deserializeUserRouting(raw);
      }
    }
    return result;
  }

  // ─── Internal ────────────────────────────────

  private async touchUpdatedAt(): Promise<void> {
    await this.redis.hset(this.key("state:config"), "updatedAt", new Date().toISOString());
  }
}

// ─── Serialization helpers ────────────────────────────────

function serializeTorRouting(config: TorInstanceRoutingConfig): Record<string, string> {
  return {
    mode: config.mode,
    targetCountryCode: config.targetCountryCode ?? "",
    weightPercent: String(config.weightPercent),
    strict: config.strict ? "1" : "0",
    fallbackCountryCode: config.fallbackCountryCode ?? "",
    updatedAt: config.updatedAt
  };
}

function deserializeTorRouting(raw: Record<string, string>): TorInstanceRoutingConfig {
  return {
    mode: (raw.mode as TorRoutingMode) || "random",
    targetCountryCode: raw.targetCountryCode || null,
    weightPercent: raw.weightPercent ? Number(raw.weightPercent) : 70,
    strict: raw.strict === "1",
    fallbackCountryCode: raw.fallbackCountryCode || null,
    updatedAt: raw.updatedAt || new Date().toISOString()
  };
}

function serializeUserRouting(pref: TorUserRoutingPreference): Record<string, string> {
  return {
    mode: pref.mode,
    countryCode: pref.countryCode ?? "",
    updatedAt: pref.updatedAt
  };
}

function deserializeUserRouting(raw: Record<string, string>): TorUserRoutingPreference {
  return {
    mode: raw.mode === "sticky" ? "sticky" : "random",
    countryCode: raw.countryCode || null,
    updatedAt: raw.updatedAt || new Date().toISOString()
  };
}

function defaultTorRoutingConfig(): TorInstanceRoutingConfig {
  return {
    mode: "random",
    targetCountryCode: null,
    weightPercent: 70,
    strict: false,
    fallbackCountryCode: null,
    updatedAt: new Date().toISOString()
  };
}

function defaultUserRoutingPreference(): TorUserRoutingPreference {
  return {
    mode: "random",
    countryCode: null,
    updatedAt: new Date().toISOString()
  };
}