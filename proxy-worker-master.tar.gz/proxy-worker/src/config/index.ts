import os from "node:os";
import path from "node:path";
import { loadRetryConfigFromEnv, type RetryConfig } from "./retryConfig";
import { loadCircuitBreakerConfigFromEnv, type CircuitBreakerConfig } from "./circuitBreakerConfig";
import { loadConnectionPoolConfigFromEnv, type ConnectionPoolConfig } from "./connectionPoolConfig";
import { loadRequestQueueConfigFromEnv, type RequestQueueConfig } from "./requestQueueConfig";

export type ServerMode = "master" | "worker" | "standalone";

export interface AppConfig {
  serverMode: ServerMode;
  serverId: string;
  serverRegion: string;
  publicHost: string;
  masterDatabaseUrl: string;
  masterRedisUrl: string;
  host: string;
  httpProxyPort: number;
  socksProxyPort: number;
  adminPort: number;
  adminToken: string;
  appBaseUrl: string;
  databaseUrl: string;
  autoMigrate: boolean;
  authSessionTtlHours: number;
  authSessionSecret: string;
  turnstileEnabled: boolean;
  turnstileSiteKey: string;
  turnstileSecretKey: string;
  requireEmailVerification: boolean;
  emailVerificationTtlMinutes: number;
  trustProxyIpHeaders: boolean;
  trustedProxyIps: Set<string>;
  paypalWebhookToken: string;
  bankTransferBankName: string;
  bankTransferAccountName: string;
  bankTransferAccountNumber: string;
  emailFromAddress: string;
  emailFromName: string;
  smtpHost: string;
  smtpPort: number;
  smtpSecure: boolean;
  smtpUser: string;
  smtpPass: string;
  notificationWorkerIntervalMs: number;
  notificationWorkerBatchSize: number;
  apiRateLimitWindowMs: number;
  apiRateLimitPublicMax: number;
  apiRateLimitUserMax: number;
  apiRateLimitAdminMax: number;
  enforceStrongSecrets: boolean;
  redisUrl: string;
  redisKeyPrefix: string;
  enableRedisRateLimiter: boolean;
  workerLeaderLockKey: string;
  workerLeaderLockTtlMs: number;
  runtimeStateFile: string;
  torInstances: number;
  torBaseSocksPort: number;
  torBaseControlPort: number;
  torBaseDnsPort: number;
  torDataDir: string;
  torBinaryPath: string;
  torBootstrapTimeoutMs: number;
  torExitNodes: string;
  torStrictNodes: boolean;
  healthcheckUrl: string;
  healthcheckIntervalMs: number;
  users: Map<string, string>;
  maxConcurrentPerUser: number;
  pakasirEnabled: boolean;
  pakasirSlug: string;
  pakasirApikey: string;
  pakasirEnabledMethods: Set<string>;
  pakasirPollingIntervalMs: number;
  defaultTrialDays: number;
  enableTrialSelfService: boolean;
  affiliateCommissionPercent: number;
  retry: RetryConfig;
  circuitBreaker: CircuitBreakerConfig;
  connectionPool: ConnectionPoolConfig;
  requestQueue: RequestQueueConfig;
}

function toInt(value: string | undefined, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number.parseInt(value, 10);
  if (Number.isNaN(parsed)) return fallback;
  return parsed;
}

function parseUsers(raw: string | undefined): Map<string, string> {
  const value = raw ?? "demo:demo123";
  const map = new Map<string, string>();

  for (const pair of value.split(",")) {
    const [user, pass] = pair.split(":");
    if (!user || !pass) continue;
    map.set(user.trim(), pass.trim());
  }

  if (map.size === 0) {
    throw new Error("No valid USERS found. Use format USERS=user1:pass1,user2:pass2");
  }

  return map;
}

function toBoolean(value: string | undefined, fallback: boolean): boolean {
  if (!value) return fallback;
  const normalized = value.trim().toLowerCase();
  if (["1", "true", "yes", "on"].includes(normalized)) return true;
  if (["0", "false", "no", "off"].includes(normalized)) return false;
  return fallback;
}

function parseCsvSet(value: string | undefined, fallbackCsv: string): Set<string> {
  const source = (value ?? fallbackCsv).trim();
  if (!source) {
    return new Set<string>();
  }

  return new Set(
    source
      .split(",")
      .map((item) => item.trim().toLowerCase())
      .filter((item) => item.length > 0)
  );
}

function clampInt(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  if (value < min) return min;
  if (value > max) return max;
  return Math.floor(value);
}

function parseServerMode(value: string | undefined): ServerMode {
  if (!value) return "standalone";
  const normalized = value.trim().toLowerCase();
  if (normalized === "master" || normalized === "worker") return normalized;
  return "standalone";
}

export function loadConfig(): AppConfig {
  const torDataDir = process.env.TOR_DATA_DIR ?? ".tor-data";
  const runtimeStateFile = process.env.RUNTIME_STATE_FILE ?? "runtime-state.json";
  const serverMode = parseServerMode(process.env.SERVER_MODE);

  return {
    serverMode,
    serverId: process.env.SERVER_ID ?? `${serverMode}-${os.hostname()}`,
    serverRegion: process.env.SERVER_REGION ?? "",
    publicHost: process.env.PUBLIC_HOST ?? "",
    masterDatabaseUrl: process.env.MASTER_DATABASE_URL ?? "",
    masterRedisUrl: process.env.MASTER_REDIS_URL ?? "",
    host: process.env.HOST ?? "0.0.0.0",
    httpProxyPort: toInt(process.env.HTTP_PROXY_PORT, 8080),
    socksProxyPort: toInt(process.env.SOCKS_PROXY_PORT, 1080),
    adminPort: toInt(process.env.ADMIN_PORT, 9090),
    adminToken: process.env.ADMIN_TOKEN ?? "change-me-admin-token",
    appBaseUrl: process.env.APP_BASE_URL ?? "http://localhost:9090",
    databaseUrl: process.env.DATABASE_URL ?? "",
    autoMigrate: toBoolean(process.env.AUTO_MIGRATE, true),
    authSessionTtlHours: toInt(process.env.AUTH_SESSION_TTL_HOURS, 24),
    authSessionSecret: process.env.AUTH_SESSION_SECRET ?? process.env.ADMIN_TOKEN ?? "change-me-admin-token",
    turnstileEnabled: toBoolean(process.env.TURNSTILE_ENABLED, true),
    turnstileSiteKey: process.env.TURNSTILE_SITE_KEY ?? "",
    turnstileSecretKey: process.env.TURNSTILE_SECRET_KEY ?? "",
    requireEmailVerification: toBoolean(process.env.REQUIRE_EMAIL_VERIFICATION, true),
    emailVerificationTtlMinutes: clampInt(toInt(process.env.EMAIL_VERIFICATION_TTL_MINUTES, 1440), 10, 10080),
    trustProxyIpHeaders: toBoolean(process.env.TRUST_PROXY_IP_HEADERS, false),
    trustedProxyIps: parseCsvSet(process.env.TRUSTED_PROXY_IPS, "127.0.0.1,::1"),
    paypalWebhookToken: process.env.PAYPAL_WEBHOOK_TOKEN ?? "",
    bankTransferBankName: process.env.BANK_TRANSFER_BANK_NAME ?? "BCA",
    bankTransferAccountName: process.env.BANK_TRANSFER_ACCOUNT_NAME ?? "Proxy Service",
    bankTransferAccountNumber: process.env.BANK_TRANSFER_ACCOUNT_NUMBER ?? "0000000000",
    emailFromAddress: process.env.EMAIL_FROM_ADDRESS ?? "notifications@example.com",
    emailFromName: process.env.EMAIL_FROM_NAME ?? "Rotating Proxy",
    smtpHost: process.env.SMTP_HOST ?? "",
    smtpPort: toInt(process.env.SMTP_PORT, 587),
    smtpSecure: toBoolean(process.env.SMTP_SECURE, false),
    smtpUser: process.env.SMTP_USER ?? "",
    smtpPass: process.env.SMTP_PASS ?? "",
    notificationWorkerIntervalMs: toInt(process.env.NOTIFICATION_WORKER_INTERVAL_MS, 15000),
    notificationWorkerBatchSize: toInt(process.env.NOTIFICATION_WORKER_BATCH_SIZE, 20),
    apiRateLimitWindowMs: toInt(process.env.API_RATE_LIMIT_WINDOW_MS, 60000),
    apiRateLimitPublicMax: toInt(process.env.API_RATE_LIMIT_PUBLIC_MAX, 120),
    apiRateLimitUserMax: toInt(process.env.API_RATE_LIMIT_USER_MAX, 240),
    apiRateLimitAdminMax: toInt(process.env.API_RATE_LIMIT_ADMIN_MAX, 180),
    enforceStrongSecrets: toBoolean(process.env.ENFORCE_STRONG_SECRETS, false),
    redisUrl: process.env.REDIS_URL ?? "",
    redisKeyPrefix: process.env.REDIS_KEY_PREFIX ?? "rotating-proxy",
    enableRedisRateLimiter: toBoolean(process.env.ENABLE_REDIS_RATE_LIMITER, true),
    workerLeaderLockKey: process.env.WORKER_LEADER_LOCK_KEY ?? "rotating-proxy:notification-leader",
    workerLeaderLockTtlMs: toInt(process.env.WORKER_LEADER_LOCK_TTL_MS, 30000),
    runtimeStateFile: path.resolve(process.cwd(), runtimeStateFile),
    torInstances: toInt(process.env.TOR_INSTANCES, 10),
    torBaseSocksPort: toInt(process.env.TOR_BASE_SOCKS_PORT, 19050),
    torBaseControlPort: toInt(process.env.TOR_BASE_CONTROL_PORT, 29050),
    torBaseDnsPort: toInt(process.env.TOR_BASE_DNS_PORT, 39050),
    torDataDir: path.resolve(process.cwd(), torDataDir),
    torBinaryPath: process.env.TOR_BINARY_PATH ?? "tor",
    torBootstrapTimeoutMs: toInt(process.env.TOR_BOOTSTRAP_TIMEOUT_MS, 120000),
    torExitNodes: process.env.TOR_EXIT_NODES ?? "",
    torStrictNodes: toBoolean(process.env.TOR_STRICT_NODES, false),
    healthcheckUrl: process.env.HEALTHCHECK_URL ?? "https://check.torproject.org/api/ip",
    healthcheckIntervalMs: toInt(process.env.HEALTHCHECK_INTERVAL_MS, 30000),
    users: parseUsers(process.env.USERS),
    maxConcurrentPerUser: toInt(process.env.MAX_CONCURRENT_PER_USER, 200),
    pakasirEnabled: toBoolean(process.env.PAKASIR_ENABLED, false),
    pakasirSlug: process.env.PAKASIR_SLUG ?? "",
    pakasirApikey: process.env.PAKASIR_APIKEY ?? "",
    pakasirEnabledMethods: parseCsvSet(
      process.env.PAKASIR_ENABLED_METHODS,
      "pakasir_qris,pakasir_va_bni,pakasir_va_bri,pakasir_va_cimb,pakasir_va_permata"
    ),
    pakasirPollingIntervalMs: toInt(process.env.PAKASIR_POLLING_INTERVAL_MS, 5000),
    defaultTrialDays: clampInt(toInt(process.env.DEFAULT_TRIAL_DAYS, 3), 0, 30),
    enableTrialSelfService: toBoolean(process.env.ENABLE_TRIAL_SELF_SERVICE, true),
    affiliateCommissionPercent: clampInt(toInt(process.env.AFFILIATE_COMMISSION_PERCENT, 10), 0, 100),
    retry: loadRetryConfigFromEnv(),
    circuitBreaker: loadCircuitBreakerConfigFromEnv(),
    connectionPool: loadConnectionPoolConfigFromEnv(),
    requestQueue: loadRequestQueueConfigFromEnv(),
  };
}
