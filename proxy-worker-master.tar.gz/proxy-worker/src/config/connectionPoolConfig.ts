/**
 * Connection Pool Configuration
 */
export interface ConnectionPoolConfig {
  maxConnectionsPerBackend: number;  // Max connections per backend
  maxIdleTime: number;                // Max idle time before closing (ms)
  connectionTimeout: number;          // Connection establishment timeout (ms)
  keepAlive: boolean;                 // Enable TCP keep-alive
  keepAliveInitialDelay: number;      // Keep-alive initial delay (ms)
}

/**
 * Load connection pool configuration from environment variables
 */
export function loadConnectionPoolConfigFromEnv(): ConnectionPoolConfig {
  return {
    maxConnectionsPerBackend: parseInt(process.env.POOL_MAX_CONNECTIONS_PER_BACKEND || '10', 10),
    maxIdleTime: parseInt(process.env.POOL_MAX_IDLE_TIME_MS || '60000', 10),
    connectionTimeout: parseInt(process.env.POOL_CONNECTION_TIMEOUT_MS || '10000', 10),
    keepAlive: process.env.POOL_KEEP_ALIVE !== 'false',
    keepAliveInitialDelay: parseInt(process.env.POOL_KEEP_ALIVE_DELAY_MS || '60000', 10),
  };
}
