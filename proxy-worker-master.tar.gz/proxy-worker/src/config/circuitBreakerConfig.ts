/**
 * Circuit Breaker States
 */
export enum CircuitState {
  CLOSED = 'CLOSED',     // Normal operation, requests pass through
  OPEN = 'OPEN',         // Circuit is open, requests fail fast
  HALF_OPEN = 'HALF_OPEN' // Testing if service recovered
}

/**
 * Circuit Breaker Configuration
 */
export interface CircuitBreakerConfig {
  /** Failure threshold to open circuit (default: 5) */
  failureThreshold: number;
  
  /** Success threshold to close circuit from half-open (default: 2) */
  successThreshold: number;
  
  /** Time window for failure counting in ms (default: 60000 = 1 minute) */
  timeWindowMs: number;
  
  /** Timeout before attempting half-open in ms (default: 30000 = 30 seconds) */
  openTimeoutMs: number;
  
  /** Minimum requests before evaluating circuit (default: 10) */
  minimumRequests: number;
}

/**
 * Circuit Breaker Statistics
 */
export interface CircuitStats {
  state: CircuitState;
  failures: number;
  successes: number;
  consecutiveFailures: number;
  consecutiveSuccesses: number;
  lastFailureTime: number | null;
  lastSuccessTime: number | null;
  lastStateChange: number;
  totalRequests: number;
  rejectedRequests: number;
}

/**
 * Load configuration from environment variables
 */
export function loadCircuitBreakerConfigFromEnv(): CircuitBreakerConfig {
  return {
    failureThreshold: parseInt(process.env.CIRCUIT_BREAKER_FAILURE_THRESHOLD || '5', 10),
    successThreshold: parseInt(process.env.CIRCUIT_BREAKER_SUCCESS_THRESHOLD || '2', 10),
    timeWindowMs: parseInt(process.env.CIRCUIT_BREAKER_TIME_WINDOW_MS || '60000', 10),
    openTimeoutMs: parseInt(process.env.CIRCUIT_BREAKER_OPEN_TIMEOUT_MS || '30000', 10),
    minimumRequests: parseInt(process.env.CIRCUIT_BREAKER_MINIMUM_REQUESTS || '10', 10)
  };
}

/**
 * Default circuit breaker configuration
 */
export const DEFAULT_CIRCUIT_BREAKER_CONFIG: CircuitBreakerConfig = {
  failureThreshold: 5,
  successThreshold: 2,
  timeWindowMs: 60000,
  openTimeoutMs: 30000,
  minimumRequests: 10
};
