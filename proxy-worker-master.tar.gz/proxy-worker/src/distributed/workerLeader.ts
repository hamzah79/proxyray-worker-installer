import { randomUUID } from "node:crypto";

import Redis from "ioredis";

export interface WorkerLeader {
  canRun(): Promise<boolean>;
}

export class SingleNodeWorkerLeader implements WorkerLeader {
  async canRun(): Promise<boolean> {
    return true;
  }
}

export class RedisWorkerLeader implements WorkerLeader {
  private readonly instanceId = randomUUID();

  constructor(
    private readonly redis: Redis,
    private readonly lockKey: string,
    private readonly lockTtlMs: number
  ) {}

  async canRun(): Promise<boolean> {
    const result = await this.redis.set(this.lockKey, this.instanceId, "PX", this.lockTtlMs, "NX");
    return result === "OK";
  }
}
