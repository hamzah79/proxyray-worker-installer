import { TorBackend } from '../types';

/**
 * Session info for sticky routing
 */
interface SessionInfo {
  sessionId: string;
  backendId: string;
  createdAt: number;
  lastUsedAt: number;
  requestCount: number;
}

/**
 * Manages sticky sessions for consistent IP routing
 */
export class SessionManager {
  private sessions = new Map<string, SessionInfo>();
  private readonly sessionTtlMs: number;
  private readonly maxSessions: number;
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor(sessionTtlMs = 3600000, maxSessions = 10000) {
    this.sessionTtlMs = sessionTtlMs; // Default: 1 hour
    this.maxSessions = maxSessions;
    this.startCleanup();
  }

  /**
   * Get backend for a session, or null if session doesn't exist/expired
   */
  getBackend(sessionId: string, backends: TorBackend[]): TorBackend | null {
    const session = this.sessions.get(sessionId);
    if (!session) return null;

    const now = Date.now();
    if (now - session.lastUsedAt > this.sessionTtlMs) {
      this.sessions.delete(sessionId);
      return null;
    }

    // Find the backend
    const backend = backends.find(b => String(b.id) === session.backendId);
    if (!backend || !backend.healthy) {
      // Backend no longer available or unhealthy
      this.sessions.delete(sessionId);
      return null;
    }

    // Update last used
    session.lastUsedAt = now;
    session.requestCount++;
    return backend;
  }

  /**
   * Create or update a session with a specific backend
   */
  setBackend(sessionId: string, backendId: string): void {
    const now = Date.now();
    const existing = this.sessions.get(sessionId);

    if (existing) {
      existing.backendId = backendId;
      existing.lastUsedAt = now;
      existing.requestCount++;
    } else {
      // Enforce max sessions limit
      if (this.sessions.size >= this.maxSessions) {
        this.evictOldestSession();
      }

      this.sessions.set(sessionId, {
        sessionId,
        backendId,
        createdAt: now,
        lastUsedAt: now,
        requestCount: 1,
      });
    }
  }

  /**
   * Remove a session
   */
  removeSession(sessionId: string): void {
    this.sessions.delete(sessionId);
  }

  /**
   * Get session stats
   */
  getStats(): { total: number; active: number; avgRequestsPerSession: number } {
    const now = Date.now();
    let active = 0;
    let totalRequests = 0;

    for (const session of this.sessions.values()) {
      if (now - session.lastUsedAt <= this.sessionTtlMs) {
        active++;
      }
      totalRequests += session.requestCount;
    }

    return {
      total: this.sessions.size,
      active,
      avgRequestsPerSession: this.sessions.size > 0 ? totalRequests / this.sessions.size : 0,
    };
  }

  /**
   * Evict oldest session when limit is reached
   */
  private evictOldestSession(): void {
    let oldest: SessionInfo | null = null;

    for (const session of this.sessions.values()) {
      if (!oldest || session.lastUsedAt < oldest.lastUsedAt) {
        oldest = session;
      }
    }

    if (oldest) {
      this.sessions.delete(oldest.sessionId);
    }
  }

  /**
   * Start periodic cleanup of expired sessions
   */
  private startCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      const toDelete: string[] = [];

      for (const [sessionId, session] of this.sessions.entries()) {
        if (now - session.lastUsedAt > this.sessionTtlMs) {
          toDelete.push(sessionId);
        }
      }

      for (const sessionId of toDelete) {
        this.sessions.delete(sessionId);
      }
    }, 60000); // Cleanup every minute
  }

  /**
   * Stop cleanup interval
   */
  destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    this.sessions.clear();
  }
}
