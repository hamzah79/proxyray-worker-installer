import http, { IncomingMessage, ServerResponse } from "node:http";
import https from "node:https";
import net from "node:net";
import { Socket } from "node:net";
import { Duplex } from "node:stream";

import { SocksClient } from "socks";
import { SocksProxyAgent } from "socks-proxy-agent";

import { CredentialStore } from "../auth/credentialStore";
import { ProxyAccessService } from "../billing/proxyAccessService";
import { AppConfig } from "../config";
import { logger } from "../observability/logger";
import { RotatingBalancer } from "./balancer";
import { TorUserRoutingPreference } from "../types";
import { parseProxyHeaders, buildProxyResponseHeaders, ProxyRequestMetadata } from "./proxyHeaders";
import { MetricsCollector } from "../observability/metricsCollector";
import { metricsCollector } from "../observability/metrics";
import { UsageTracker } from "../billing/usageTracker";
import { RetryHelper } from "../utils/retryHelper";
import { CircuitBreakerManager } from "../utils/circuitBreakerManager";
import { ConnectionPool } from "../utils/connectionPool";
import { RequestQueue } from "../utils/requestQueue";

export interface RemoteWorkerTarget {
  publicHost: string;
  httpProxyPort: number;
  socksProxyPort: number;
}

export interface ProxyTrafficSample {
  username: string;
  requestsCountDelta: number;
  bytesInDelta: number;
  bytesOutDelta: number;
  peakConcurrent: number;
}

function writeProxyAuthRequired(response: ServerResponse): void {
  response.writeHead(407, {
    "Proxy-Authenticate": 'Basic realm="rotating-proxy"',
    "Content-Type": "text/plain"
  });
  response.end("Proxy authentication required\n");
}

function normalizeIp(rawIp: string | null | undefined): string | undefined {
  if (!rawIp || typeof rawIp !== "string") {
    return undefined;
  }

  const trimmed = rawIp.trim();
  if (!trimmed) {
    return undefined;
  }

  return trimmed.startsWith("::ffff:") ? trimmed.slice(7) : trimmed;
}

function extractRawCredentials(req: IncomingMessage): { username: string; password: string } | null {
  const header = getProxyAuthHeader(req);
  if (!header) return null;
  const parts = header.split(" ");
  if (!parts[1]) return null;
  try {
    const decoded = Buffer.from(parts[1], "base64").toString("utf-8");
    const colonIdx = decoded.indexOf(":");
    if (colonIdx < 0) return null;
    return { username: decoded.substring(0, colonIdx), password: decoded.substring(colonIdx + 1) };
  } catch { return null; }
}


function resolveClientIp(req: IncomingMessage, config: AppConfig): string | undefined {
  const socketIp = normalizeIp(req.socket.remoteAddress ?? undefined);
  const trustProxyIpHeaders = (config as { trustProxyIpHeaders?: boolean }).trustProxyIpHeaders === true;
  const trustedProxyIps = (config as { trustedProxyIps?: Set<string> }).trustedProxyIps ?? new Set<string>();
  if (!trustProxyIpHeaders || !socketIp || !trustedProxyIps.has(socketIp)) {
    return socketIp;
  }

  const candidates = [req.headers["cf-connecting-ip"], req.headers["x-real-ip"], req.headers["x-forwarded-for"]];
  for (const value of candidates) {
    if (typeof value !== "string" || !value.trim()) {
      continue;
    }

    const first = value.split(",")[0]?.trim();
    const normalized = normalizeIp(first);
    if (normalized) {
      return normalized;
    }
  }

  return socketIp;
}

function getProxyAuthHeader(req: IncomingMessage): string | undefined {
  // Try lowercase first (Node.js default)
  const lowercase = req.headers["proxy-authorization"];
  if (lowercase) {
    return Array.isArray(lowercase) ? lowercase[0] : lowercase;
  }

  // Try case-insensitive search as fallback
  for (const [key, value] of Object.entries(req.headers)) {
    if (key.toLowerCase() === "proxy-authorization") {
      return Array.isArray(value) ? value[0] : value;
    }
  }

  return undefined;
}

async function authenticate(credentials: CredentialStore, req: IncomingMessage, config: AppConfig): Promise<string | null> {
  const clientIp = resolveClientIp(req, config);
  const proxyAuthHeader = getProxyAuthHeader(req);
  
  const result = await credentials.authenticateProxyAuthorizationDetailed(proxyAuthHeader, clientIp);
  if (!result.session) {
    logger.warn("http proxy auth failed", {
      username: result.username,
      reason: result.reason,
      clientIp,
      hasProxyAuthHeader: !!proxyAuthHeader,
      headerKeys: Object.keys(req.headers).join(", ")
    });
    return null;
  }

  return result.session.username;
}

export class HttpGateway {
  private readonly server: http.Server;
  private readonly retryHelper: RetryHelper;
  private readonly circuitBreaker: CircuitBreakerManager;
  private readonly connectionPool: ConnectionPool;
  private readonly requestQueue: RequestQueue;

  private readonly resolveWorker?: (username: string) => Promise<RemoteWorkerTarget | null>;

  constructor(
    private readonly config: AppConfig,
    private readonly credentials: CredentialStore,
    private readonly balancer: RotatingBalancer,
    private readonly proxyAccess: ProxyAccessService | null,
    private readonly resolveUserRoutingPreference?: (username: string) => TorUserRoutingPreference,
    private readonly onTrafficSample?: (sample: ProxyTrafficSample) => Promise<void> | void,
    resolveWorker?: (username: string) => Promise<RemoteWorkerTarget | null>,
    private readonly metricsCollector?: MetricsCollector | null,
    private readonly usageTracker?: UsageTracker | null,
  ) {
    this.retryHelper = new RetryHelper(config.retry);
    this.circuitBreaker = new CircuitBreakerManager(config.circuitBreaker);
    this.connectionPool = new ConnectionPool(config.connectionPool);
    this.requestQueue = new RequestQueue(config.requestQueue);
    this.resolveWorker = resolveWorker;
    this.server = http.createServer((req, res) => {
      this.handleHttpRequest(req, res).catch((error: unknown) => {
        logger.error("http request failed", { error: String(error) });
        if (!res.headersSent) {
          res.writeHead(502, { "Content-Type": "text/plain" });
        }
        res.end("Bad gateway\n");
      });
    });

    this.server.on("connect", (req, clientSocket, head) => {
      this.handleConnectRequest(req, clientSocket, head).catch((error: unknown) => {
        logger.error("connect request failed", { error: String(error) });
        clientSocket.destroy();
      });
    });
  }

  listen(): Promise<void> {
    return new Promise((resolve) => {
      this.server.listen(this.config.httpProxyPort, this.config.host, () => {
        logger.info("http proxy started", {
          host: this.config.host,
          port: this.config.httpProxyPort
        });
        resolve();
      });
    });
  }

  close(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server.close((error) => {
        if (error) {
          reject(error);
          return;
        }
        resolve();
      });
    });
  }

  /**
   * Get circuit breaker manager instance
   */
  getCircuitBreaker(): CircuitBreakerManager {
    return this.circuitBreaker;
  }

  /**
   * Get connection pool instance
   */
  getConnectionPool(): ConnectionPool {
    return this.connectionPool;
  }

  /**
   * Get request queue instance
   */
  getRequestQueue(): RequestQueue {
    return this.requestQueue;
  }

  private async handleHttpRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const username = await authenticate(this.credentials, req, this.config);
    if (!username) {
      writeProxyAuthRequired(res);
      return;
    }

    const clientIp = resolveClientIp(req, this.config);

    if (this.proxyAccess) {
      const access = await this.proxyAccess.getAccess(username, clientIp);
      if (!access.allowed) {
        logger.warn("http proxy access denied", { username, clientIp, reason: access.reason });
        res.writeHead(403, { "Content-Type": "text/plain" });
        res.end(`Proxy access denied: ${access.reason}\n`);
        return;
      }

      if (!this.credentials.beginSession(username, access.concurrentLimit ?? undefined)) {
        logger.warn("http proxy concurrent limit reached", { username, clientIp, limit: access.concurrentLimit });
        res.writeHead(429, { "Content-Type": "text/plain" });
        res.end("Too many concurrent sessions\n");
        return;
      }
    } else if (!this.credentials.beginSession(username)) {
      logger.warn("http proxy concurrent limit reached", { username, clientIp });
      res.writeHead(429, { "Content-Type": "text/plain" });
      res.end("Too many concurrent sessions\n");
      return;
    }

    const cleanup = () => this.credentials.endSession(username);
    res.once("close", cleanup);

    let bytesIn = 0;
    let bytesOut = 0;
    const startTime = Date.now();
    let backend: any = null;
    
    req.on("data", (chunk: Buffer) => {
      bytesIn += chunk.length;
    });

    // Parse proxy headers for smart routing
    const metadata = parseProxyHeaders(req.headers);

    try {
      const requestUrl = new URL(req.url ?? "");

      // Phase 8: Check if request should be forwarded to a remote worker
      const remoteTarget = this.resolveWorker ? await this.resolveWorker(username) : null;
      let agent: http.Agent;
      let retryCount = 0;
      
      if (remoteTarget) {
        logger.info("forwarding http to remote worker", { username, host: remoteTarget.publicHost });
        const rawCreds = extractRawCredentials(req);
        agent = new SocksProxyAgent(`socks5h://${encodeURIComponent(rawCreds?.username || username)}:${encodeURIComponent(rawCreds?.password || "")}@${remoteTarget.publicHost}:${remoteTarget.socksProxyPort}`);
      } else {
        // Use retry helper to select backend with automatic failover
        const result = await this.retryHelper.executeWithRetry(
          async (attempt, excludeBackends) => {
            // Also exclude backends with open circuits
            const openCircuits = this.circuitBreaker.getOpenCircuits();
            const allExcluded = new Set([...Array.from(excludeBackends), ...openCircuits]);
            
            // Select backend, excluding failed ones and open circuits
            backend = this.balancer.selectBackend({ 
              userPreference: this.resolveUserRoutingPreference?.(username),
              metadata,
              excludeBackends: Array.from(allExcluded)
            });
            
            logger.info("backend selected", { 
              backendId: backend.id, 
              attempt, 
              excludedCount: excludeBackends.size,
              openCircuits: openCircuits.length,
              circuitState: this.circuitBreaker.getState(String(backend.id))
            });
            
            // Wrap backend operation with circuit breaker
            return await this.circuitBreaker.execute(String(backend.id), async () => {
              // Circuit breaker will track success/failure
              return backend;
            });
          },
          (error) => {
            // Check if it's a circuit breaker error
            if (CircuitBreakerManager.isCircuitBreakerError(error)) {
              logger.warn("backend circuit is open", {
                backendId: error.backendId,
                stats: error.stats
              });
              return true; // Retry with different backend
            }
            return this.isRetryableError(error);
          }
        );
        
        backend = result.result;
        retryCount = result.attempts - 1;
        
        if (retryCount > 0) {
          logger.info("backend selected after retry", { 
            backendId: backend.id, 
            retries: retryCount,
            excludedBackends: Array.from(result.excludedBackends)
          });
        }
        
        agent = new SocksProxyAgent(`socks5h://127.0.0.1:${backend.socksPort}`);
      }

      const protocol = requestUrl.protocol === "https:" ? https : http;
      const upstream = protocol.request(
        {
          method: req.method,
          hostname: requestUrl.hostname,
          port: requestUrl.port || (requestUrl.protocol === "https:" ? 443 : 80),
          path: `${requestUrl.pathname}${requestUrl.search}`,
          headers: req.headers,
          agent
        },
        (upstreamResponse) => {
          upstreamResponse.on("data", (chunk: Buffer) => {
            bytesOut += chunk.length;
          });
          
          // Build proxy response headers
          if (backend) {
            const responseTime = Date.now() - startTime;
            const proxyHeaders = buildProxyResponseHeaders({
              exitIp: backend.exitIp || 'unknown',
              exitCountry: backend.countryCode || 'unknown',
              backendId: String(backend.id),
              retries: retryCount,
              totalTime: responseTime
            });
            
            // Merge proxy headers with upstream headers
            const mergedHeaders = { ...upstreamResponse.headers, ...proxyHeaders };
            res.writeHead(upstreamResponse.statusCode ?? 502, mergedHeaders);
          } else {
            res.writeHead(upstreamResponse.statusCode ?? 502, upstreamResponse.headers);
          }
          
          upstreamResponse.pipe(res);
        }
      );

      upstream.on("error", (error) => {
        logger.warn("upstream http request error", { error: String(error) });
        if (!res.headersSent) {
          res.writeHead(502, { "Content-Type": "text/plain" });
        }
        res.end("Upstream connection failed\n");
      });

      req.pipe(upstream);
    } finally {
      res.once("finish", async () => {
        cleanup();
        
        const responseTime = Date.now() - startTime;
        const success = res.statusCode < 400;
        
        // Track metrics (old collector)
        if (this.metricsCollector && backend) {
          this.metricsCollector.recordRequest({
            success,
            latency: responseTime,
            backendId: String(backend.id),
            country: backend.countryCode || 'unknown',
            username,
            uploadBytes: bytesIn,
            downloadBytes: bytesOut
          });
        }
        
        // Track metrics (new collector for monitoring)
        if (backend) {
          metricsCollector.recordRequest(backend.id, responseTime, success);
          metricsCollector.updateBackendHealth(backend.id, backend.healthy);
        }
        
        // Track usage
        // Note: Usage tracking requires userId which is not available in current ProxyAccessResult
        // This will be enabled once we have access to user repository or ProxyAccessResult is extended
        /*
        if (this.usageTracker && backend && this.proxyAccess) {
          try {
            const access = await this.proxyAccess.getAccess(username, resolveClientIp(req, this.config));
            if (access.userId) {
              await this.usageTracker.recordUsage({
                userId: access.userId,
                username,
                requestCount: 1,
                uploadBytes: bytesIn,
                downloadBytes: bytesOut,
                exitCountry: backend.countryCode || 'unknown',
                backendId: String(backend.id),
                success,
                latencyMs: responseTime
              });
            }
          } catch (err) {
            logger.warn("usage tracking failed", { error: String(err), username });
          }
        }
        */
        
        await this.emitTrafficSample(username, 1, bytesIn, bytesOut);
      });
    }
  }

  private async handleConnectRequest(req: IncomingMessage, clientSocket: Socket | Duplex, head: Buffer): Promise<void> {
    const username = await authenticate(this.credentials, req, this.config);
    if (!username) {
      clientSocket.write(
        "HTTP/1.1 407 Proxy Authentication Required\r\n" +
          "Proxy-Authenticate: Basic realm=\"rotating-proxy\"\r\n" +
          "\r\n"
      );
      clientSocket.destroy();
      return;
    }

    const clientIp = resolveClientIp(req, this.config);

    if (this.proxyAccess) {
      const access = await this.proxyAccess.getAccess(username, clientIp);
      if (!access.allowed) {
        logger.warn("http connect proxy access denied", { username, clientIp, reason: access.reason });
        clientSocket.write("HTTP/1.1 403 Forbidden\r\n\r\n");
        clientSocket.destroy();
        return;
      }

      if (!this.credentials.beginSession(username, access.concurrentLimit ?? undefined)) {
        logger.warn("http connect concurrent limit reached", { username, clientIp, limit: access.concurrentLimit });
        clientSocket.write("HTTP/1.1 429 Too Many Requests\r\n\r\n");
        clientSocket.destroy();
        return;
      }
    } else if (!this.credentials.beginSession(username)) {
      logger.warn("http connect concurrent limit reached", { username, clientIp });
      clientSocket.write("HTTP/1.1 429 Too Many Requests\r\n\r\n");
      clientSocket.destroy();
      return;
    }

    const target = req.url ?? "";
    const [host, rawPort] = target.split(":");
    const port = Number.parseInt(rawPort ?? "443", 10);

    if (!host || Number.isNaN(port)) {
      this.credentials.endSession(username);
      clientSocket.write("HTTP/1.1 400 Bad Request\r\n\r\n");
      clientSocket.destroy();
      return;
    }

    try {
      // Phase 8: remote worker forwarding for CONNECT
      const connectCreds = extractRawCredentials(req);
      const remoteTarget = this.resolveWorker ? await this.resolveWorker(username) : null;
      const routingPref = this.resolveUserRoutingPreference?.(username);
      let lastError: unknown;
      let connection: Awaited<ReturnType<typeof SocksClient.createConnection>> | null = null;

      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          let proxyHost: string;
          let proxyPort: number;
          if (remoteTarget) {
            proxyHost = remoteTarget.publicHost;
            proxyPort = remoteTarget.socksProxyPort;
          } else {
            const backend = this.balancer.selectBackend({ userPreference: routingPref });
            proxyHost = "127.0.0.1";
            proxyPort = backend.socksPort;
          }
          connection = await SocksClient.createConnection({
            command: "connect",
            proxy: { host: proxyHost, port: proxyPort, type: 5, ...(remoteTarget ? { userId: connectCreds?.username, password: connectCreds?.password } : {}) },
            destination: { host, port }
          });
          break;
        } catch (err) {
          lastError = err;
          logger.warn("connect attempt failed, retrying", { attempt, host, port, remote: !!remoteTarget, error: String(err) });
        }
      }

      if (!connection) {
        throw lastError;
      }

      const upstream = connection.socket;

      clientSocket.write("HTTP/1.1 200 Connection Established\r\n\r\n");
      if (head.length > 0) {
        upstream.write(head);
      }

      clientSocket.pipe(upstream);
      upstream.pipe(clientSocket);

      let bytesIn = 0;
      let bytesOut = 0;
      clientSocket.on("data", (chunk: Buffer) => { bytesIn += chunk.length; });
      upstream.on("data", (chunk: Buffer) => { bytesOut += chunk.length; });

      let finished = false;
      const cleanup = async () => {
        if (finished) return;
        finished = true;
        this.credentials.endSession(username);
        await this.emitTrafficSample(username, 1, bytesIn, bytesOut);
      };

      clientSocket.once("close", () => { cleanup().catch(() => undefined); });
      upstream.once("close", () => { cleanup().catch(() => undefined); });
    } catch (error) {
      this.credentials.endSession(username);
      clientSocket.write("HTTP/1.1 502 Bad Gateway\r\n\r\n");
      clientSocket.destroy();
      throw error;
    }
  }

  private async emitTrafficSample(username: string, requestsCountDelta: number, bytesInDelta: number, bytesOutDelta: number): Promise<void> {
    if (!this.onTrafficSample) {
      return;
    }

    try {
      await this.onTrafficSample({
        username,
        requestsCountDelta,
        bytesInDelta,
        bytesOutDelta,
        peakConcurrent: this.credentials.getActiveSessionCount(username)
      });
    } catch (error) {
      logger.warn("failed to emit http traffic sample", { error: String(error), username });
    }
  }

  /**
   * Check if error is retryable (network/connection errors)
   */
  private isRetryableError(error: unknown): boolean {
    if (!error || typeof error !== "object") {
      return false;
    }

    const err = error as { code?: string; message?: string };
    
    // Network errors that should trigger retry
    const retryableCodes = [
      "ECONNREFUSED",
      "ECONNRESET",
      "ETIMEDOUT",
      "ENOTFOUND",
      "ENETUNREACH",
      "EHOSTUNREACH",
      "EPIPE",
      "EAI_AGAIN"
    ];

    if (err.code && retryableCodes.includes(err.code)) {
      return true;
    }

    // Check message for common Tor/SOCKS errors
    const message = err.message?.toLowerCase() || "";
    if (
      message.includes("socks") ||
      message.includes("connection") ||
      message.includes("timeout") ||
      message.includes("refused")
    ) {
      return true;
    }

    return false;
  }
}
