import net, { Socket } from "node:net";

import socks from "socksv5";
import { SocksClient } from "socks";

import { CredentialStore } from "../auth/credentialStore";
import { ProxyAccessService } from "../billing/proxyAccessService";
import { AppConfig } from "../config";
import { logger } from "../observability/logger";
import { MetricsCollector } from "../observability/metricsCollector";
import { UsageTracker } from "../billing/usageTracker";
import { TorUserRoutingPreference, TorBackend } from "../types";
import { RotatingBalancer } from "./balancer";
import { ProxyTrafficSample, RemoteWorkerTarget } from "./httpGateway";
import { RetryHelper } from "../utils/retryHelper";
import { CircuitBreakerManager } from "../utils/circuitBreakerManager";

interface PendingAuth {
  username: string;
  password: string;
  concurrentLimit?: number;
  timestamp: number;
}

export class SocksGateway {
  private readonly server: socks.Server;
  private readonly retryHelper: RetryHelper;
  private readonly circuitBreaker: CircuitBreakerManager;
  private readonly pendingAuthBySocket = new WeakMap<object, PendingAuth>();
  /** FIFO queue of authenticated entries – avoids race conditions when
   *  multiple SOCKS5 connections authenticate concurrently. */
  private readonly authQueue: PendingAuth[] = [];
  private readonly resolveWorker?: (username: string) => Promise<RemoteWorkerTarget | null>;

  constructor(
    private readonly config: AppConfig,
    private readonly credentials: CredentialStore,
    private readonly balancer: RotatingBalancer,
    private readonly proxyAccess: ProxyAccessService | null,
    private readonly resolveUserRoutingPreference?: (username: string) => TorUserRoutingPreference,
    private readonly onTrafficSample?: (sample: ProxyTrafficSample) => Promise<void> | void,
    resolveWorker?: (username: string) => Promise<RemoteWorkerTarget | null>,
    private readonly metricsCollector?: MetricsCollector | null,
    private readonly usageTracker?: UsageTracker | null,
  ) {
    this.retryHelper = new RetryHelper(config.retry);
    this.circuitBreaker = new CircuitBreakerManager(config.circuitBreaker);
    this.resolveWorker = resolveWorker;
    this.server = socks.createServer((info: SocksInfo, accept: SocksAccept, deny: SocksDeny) => {
      this.handleConnection(info, accept, deny).catch((error: unknown) => {
        logger.warn("socks connection failed", { error: String(error) });
        deny();
      });
    });

    this.server.useAuth(
      socks.auth.UserPassword((username: string, password: string, callback: AuthCallback) => {
        this.authorizeSocksUser(username, password)
          .then((entry) => {
            if (entry) {
              this.authQueue.push(entry);
              callback(true);
            } else {
              callback(false);
            }
          })
          .catch(() => {
            callback(false);
          });
      })
    );
  }

  listen(): Promise<void> {
    return new Promise((resolve) => {
      this.server.listen(this.config.socksProxyPort, this.config.host, () => {
        logger.info("socks5 proxy started", {
          host: this.config.host,
          port: this.config.socksProxyPort
        });
        resolve();
      });
    });
  }

  close(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server.close((error?: Error) => {
        if (error) {
          reject(error);
          return;
        }
        resolve();
      });
    });
  }

  private async handleConnection(
    info: SocksInfo,
    accept: SocksAccept,
    deny: SocksDeny
  ): Promise<void> {
    if (!info.dstAddr || !info.dstPort) {
      deny();
      return;
    }

    const authenticated = this.authQueue.shift() ?? null;

    const authenticatedUsername = authenticated?.username;

    if (authenticatedUsername) {
      if (this.proxyAccess) {
        const access = await this.proxyAccess.getAccess(authenticatedUsername, info.srcAddr);
        if (!access.allowed) {
          logger.warn("socks proxy access denied", {
            username: authenticatedUsername,
            clientIp: info.srcAddr,
            reason: access.reason
          });
          deny();
          return;
        }

        if (authenticated) {
          authenticated.concurrentLimit = access.concurrentLimit ?? authenticated.concurrentLimit;
        }
      }

      // Skip IP whitelist check if request comes from trusted proxy (master server)
      const trustedProxies = Array.from(this.config.trustedProxyIps || []);
      const clientIp = info.srcAddr || "";
      const isTrustedProxy = trustedProxies.some((ip: string) => 
        clientIp === ip || clientIp.startsWith(ip)
      );
      
      // Only check IP whitelist if NOT from trusted proxy
      if (!isTrustedProxy && !this.credentials.isIpAllowed(authenticatedUsername, info.srcAddr)) {
        logger.warn("socks proxy ip not whitelisted", {
          username: authenticatedUsername,
          clientIp: info.srcAddr
        });
        deny();
        return;
      }

      const allowed = this.credentials.beginSession(authenticatedUsername, authenticated?.concurrentLimit);
      if (!allowed) {
        logger.warn("socks proxy concurrent limit reached", {
          username: authenticatedUsername,
          clientIp: info.srcAddr,
          limit: authenticated?.concurrentLimit
        });
        deny();
        return;
      }
    }

    // ── Establish backend connection BEFORE accepting the client ──
    // This ensures we only send SOCKS5 SUCCESS to the client when the
    // upstream (Tor / remote worker) is actually reachable.  If the
    // backend is unreachable the client receives a proper SOCKS5 DENY
    // instead of an empty reply.

    const routingPref = authenticatedUsername ? this.resolveUserRoutingPreference?.(authenticatedUsername) : undefined;

    const startTime = Date.now();
    let connection: Awaited<ReturnType<typeof SocksClient.createConnection>> | null = null;
    let selectedBackend: TorBackend | null = null;
    let retryCount = 0;

    // Phase 8: remote worker forwarding for SOCKS
    const remoteTarget = authenticatedUsername && this.resolveWorker
      ? await this.resolveWorker(authenticatedUsername)
      : null;

    try {
      if (remoteTarget) {
        // Remote worker: try direct connection, fallback to local on failure
        try {
          connection = await SocksClient.createConnection({
            command: "connect",
            proxy: { 
              host: remoteTarget.publicHost, 
              port: remoteTarget.socksProxyPort, 
              type: 5, 
              userId: authenticated?.username, 
              password: authenticated?.password 
            },
            destination: { host: info.dstAddr, port: info.dstPort },
            timeout: 10000
          });
        } catch (remoteError) {
          logger.warn("socks remote worker failed, falling back to local", {
            remoteHost: remoteTarget.publicHost,
            remotePort: remoteTarget.socksProxyPort,
            error: String(remoteError)
          });
          // Clear the stale assignment so next request goes local immediately
          connection = null;
        }
      }
      
      if (!connection) {
        // Local backends: use retry helper with failover
        let lastSelectedBackend: TorBackend | null = null;
        
        const result = await this.retryHelper.executeWithRetry(
          async (attempt, excludeBackends) => {
            // Also exclude backends with open circuits
            const openCircuits = this.circuitBreaker.getOpenCircuits();
            const allExcluded = new Set([...Array.from(excludeBackends), ...openCircuits]);
            
            // Select backend, excluding failed ones and open circuits
            lastSelectedBackend = this.balancer.selectBackend({ 
              userPreference: routingPref,
              excludeBackends: Array.from(allExcluded)
            });
            
            logger.info("socks backend selected", { 
              backendId: lastSelectedBackend.id, 
              attempt, 
              excludedCount: excludeBackends.size,
              openCircuits: openCircuits.length,
              circuitState: this.circuitBreaker.getState(String(lastSelectedBackend.id))
            });
            
            // Wrap backend operation with circuit breaker
            return await this.circuitBreaker.execute(String(lastSelectedBackend.id), async () => {
              // Try to connect through selected backend
              logger.info("attempting tor connection", {
                backendId: lastSelectedBackend!.id,
                socksPort: lastSelectedBackend!.socksPort,
                destination: `${info.dstAddr}:${info.dstPort}`
              });
              
              const conn = await SocksClient.createConnection({
                command: "connect",
                proxy: { 
                  host: "127.0.0.1", 
                  port: lastSelectedBackend!.socksPort, 
                  type: 5
                },
                destination: { host: info.dstAddr, port: info.dstPort },
                timeout: 10000
              });
              
              logger.info("tor connection successful", {
                backendId: lastSelectedBackend!.id
              });
              
              return conn;
            });
          },
          (error) => {
            // Check if it's a circuit breaker error
            if (CircuitBreakerManager.isCircuitBreakerError(error)) {
              logger.warn("backend circuit is open", {
                backendId: error.backendId,
                stats: error.stats
              });
              return true; // Retry with different backend
            }
            return this.isRetryableError(error);
          }
        );
        
        connection = result.result;
        selectedBackend = lastSelectedBackend;
        retryCount = result.attempts - 1;
        
        if (retryCount > 0 && selectedBackend) {
          logger.info("socks connection established after retry", { 
            backendId: (selectedBackend as TorBackend).id, 
            retries: retryCount,
            excludedBackends: Array.from(result.excludedBackends)
          });
        }
      }
    } catch (error) {
      if (authenticatedUsername) this.credentials.endSession(authenticatedUsername);
      logger.warn("socks all connect attempts failed, sending DENY to client", { 
        error: String(error),
        errorName: error instanceof Error ? error.name : 'unknown',
        errorMessage: error instanceof Error ? error.message : String(error),
        destination: `${info.dstAddr}:${info.dstPort}`
      });
      // Send proper SOCKS5 DENY instead of destroying the socket silently.
      // This prevents the "Empty reply from server" error on the client side.
      deny();
      return;
    }

    // ── Backend is connected – now accept the client ──
    const clientSocket = accept(true);

    logger.info("socks connection successful, setting up pipes", {
      hasConnection: !!connection,
      hasSocket: !!connection?.socket,
      selectedBackendId: selectedBackend ? String((selectedBackend as TorBackend).id) : 'remote'
    });

    const upstream = connection.socket;
    let bytesIn = 0;
    let bytesOut = 0;
    
    clientSocket.on("data", (chunk: Buffer) => { 
      bytesIn += chunk.length;
      logger.info("socks client->upstream data", { bytes: chunk.length, total: bytesIn });
    });
    
    upstream.on("data", (chunk: Buffer) => { 
      bytesOut += chunk.length;
      logger.info("socks upstream->client data", { bytes: chunk.length, total: bytesOut });
    });

    clientSocket.pipe(upstream);
    upstream.pipe(clientSocket);
    
    const backendIdForLog = selectedBackend ? String((selectedBackend as TorBackend).id) : 'remote';
    logger.info("socks pipes established", { 
      dstAddr: info.dstAddr, 
      dstPort: info.dstPort,
      backendId: backendIdForLog
    });

    const closeBoth = () => {
      clientSocket.destroy();
      upstream.destroy();
    };

    let finished = false;
    const cleanup = async () => {
      if (finished) return;
      finished = true;
      
      const responseTime = Date.now() - startTime;
      const success = !!connection; // Connection successful if not null
      
      if (authenticatedUsername) {
        this.credentials.endSession(authenticatedUsername);
        await this.emitTrafficSample(authenticatedUsername, 1, bytesIn, bytesOut);
        
        // Track metrics
        if (this.metricsCollector && selectedBackend) {
          this.metricsCollector.recordRequest({
            success,
            latency: responseTime,
            backendId: String((selectedBackend as TorBackend).id),
            country: (selectedBackend as TorBackend).countryCode || 'unknown',
            username: authenticatedUsername,
            uploadBytes: bytesIn,
            downloadBytes: bytesOut
          });
        }
        
        // Track usage
        if (this.usageTracker && selectedBackend) {
          try {
            await this.usageTracker.recordUsage({
              userId: 0, // TODO: Get actual userId from proxyAccess or user repository
              username: authenticatedUsername,
              requestCount: 1,
              uploadBytes: bytesIn,
              downloadBytes: bytesOut,
              exitCountry: (selectedBackend as TorBackend).countryCode || 'unknown',
              backendId: String((selectedBackend as TorBackend).id),
              success,
              latencyMs: responseTime
            });
          } catch (error) {
            logger.warn("failed to record socks usage", { error: String(error), username: authenticatedUsername });
          }
        }
      }
    };

    clientSocket.once("error", closeBoth);
    upstream.once("error", closeBoth);
    clientSocket.once("close", () => { cleanup().catch(() => undefined); });
    upstream.once("close", () => { cleanup().catch(() => undefined); });
  }

  private async authorizeSocksUser(username: string, password: string): Promise<PendingAuth | null> {
    // Note: We don't pass clientIp here because socksv5 library doesn't provide it in auth callback
    // IP whitelist check is done later in handleConnection() where we have access to info.srcAddr
    const authResult = await this.credentials.authenticateSocksDetailed(username, password, undefined);
    if (!authResult.session) {
      logger.warn("socks auth failed", { username, reason: authResult.reason });
      return null;
    }

    // Note: We don't check proxyAccess here because we don't have clientIp yet
    // Access check (including IP whitelist) is done in handleConnection() with the actual client IP
    let concurrentLimit: number | undefined;
    if (this.proxyAccess) {
      // Only get concurrent limit, skip access check (will be done in handleConnection)
      const access = await this.proxyAccess.getAccess(username);
      if (typeof access.concurrentLimit === "number" && access.concurrentLimit > 0) {
        concurrentLimit = access.concurrentLimit;
      }
    }

    return { username, password, concurrentLimit, timestamp: Date.now() };
  }

  private async emitTrafficSample(username: string, requestsCountDelta: number, bytesInDelta: number, bytesOutDelta: number): Promise<void> {
    if (!this.onTrafficSample) return;

    try {
      await this.onTrafficSample({
        username,
        requestsCountDelta,
        bytesInDelta,
        bytesOutDelta,
        peakConcurrent: this.credentials.getActiveSessionCount(username)
      });
    } catch (error) {
      logger.warn("failed to emit socks traffic sample", { error: String(error), username });
    }
  }

  /**
   * Check if error is retryable (network/connection errors)
   */
  private isRetryableError(error: unknown): boolean {
    if (!error || typeof error !== "object") {
      return false;
    }

    const err = error as { code?: string; message?: string };
    
    // Network errors that should trigger retry
    const retryableCodes = [
      "ECONNREFUSED",
      "ECONNRESET",
      "ETIMEDOUT",
      "ENOTFOUND",
      "ENETUNREACH",
      "EHOSTUNREACH",
      "EPIPE",
      "EAI_AGAIN"
    ];

    if (err.code && retryableCodes.includes(err.code)) {
      return true;
    }

    // Check message for common Tor/SOCKS errors
    const message = err.message?.toLowerCase() || "";
    if (
      message.includes("socks") ||
      message.includes("connection") ||
      message.includes("timeout") ||
      message.includes("refused")
    ) {
      return true;
    }

    return false;
  }
}

type SocksInfo = {
  dstAddr: string;
  dstPort: number;
  srcAddr?: string;
  srcPort?: number;
};

type SocksAccept = (intercept?: boolean) => Socket;
type SocksDeny = () => void;
type AuthCallback = (success: boolean) => void;
