/**
 * Proxy request metadata extracted from custom headers
 */
export interface ProxyRequestMetadata {
  /** Force IP rotation for this request */
  forceRotate: boolean;
  
  /** Preferred exit countries (fallback order) */
  preferredCountries: string[];
  
  /** Maximum retry attempts on failure */
  maxRetries: number;
  
  /** Custom timeout in milliseconds */
  timeout: number | null;
  
  /** Session ID for sticky routing */
  sessionId: string | null;
  
  /** Enable automatic retry on failure */
  autoRetry: boolean;
}

/**
 * Parse proxy control headers from HTTP request
 */
export function parseProxyHeaders(headers: Record<string, string | string[] | undefined>): ProxyRequestMetadata {
  const getHeader = (name: string): string | null => {
    const value = headers[name.toLowerCase()];
    if (typeof value === 'string') return value.trim();
    if (Array.isArray(value) && value.length > 0) return value[0].trim();
    return null;
  };

  // X-Proxy-Rotate: true/false
  const rotate = getHeader('x-proxy-rotate');
  const forceRotate = rotate === 'true' || rotate === '1';

  // X-Proxy-Country: US,GB,DE (comma-separated fallback list)
  const countryHeader = getHeader('x-proxy-country');
  const preferredCountries = countryHeader
    ? countryHeader
        .split(',')
        .map(c => c.trim().toUpperCase())
        .filter(c => /^[A-Z]{2,3}$/.test(c))
    : [];

  // X-Proxy-Max-Retries: 3
  const retriesHeader = getHeader('x-proxy-max-retries');
  const maxRetries = retriesHeader ? Math.max(0, Math.min(10, parseInt(retriesHeader, 10) || 3)) : 3;

  // X-Proxy-Timeout: 30000 (milliseconds)
  const timeoutHeader = getHeader('x-proxy-timeout');
  const timeout = timeoutHeader ? Math.max(1000, Math.min(300000, parseInt(timeoutHeader, 10))) : null;

  // X-Proxy-Session: session-id-123 (for sticky routing)
  const sessionId = getHeader('x-proxy-session');

  // X-Proxy-Auto-Retry: true/false
  const retryHeader = getHeader('x-proxy-auto-retry');
  const autoRetry = retryHeader !== 'false' && retryHeader !== '0';

  return {
    forceRotate,
    preferredCountries,
    maxRetries,
    timeout,
    sessionId,
    autoRetry,
  };
}

/**
 * Response headers to send back to client
 */
export interface ProxyResponseHeaders {
  /** Exit IP used for this request */
  exitIp: string;
  
  /** Exit country code */
  exitCountry: string;
  
  /** Backend ID that handled the request */
  backendId: string;
  
  /** Number of retries performed */
  retries: number;
  
  /** Total time spent (ms) */
  totalTime: number;
}

/**
 * Build response headers to inform client about proxy routing
 */
export function buildProxyResponseHeaders(info: ProxyResponseHeaders): Record<string, string> {
  return {
    'X-Proxy-Exit-IP': info.exitIp,
    'X-Proxy-Exit-Country': info.exitCountry,
    'X-Proxy-Backend-ID': info.backendId,
    'X-Proxy-Retries': info.retries.toString(),
    'X-Proxy-Total-Time': info.totalTime.toString(),
  };
}
