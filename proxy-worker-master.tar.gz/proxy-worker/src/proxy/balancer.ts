import { TorBackend, TorInstanceRoutingConfig, TorUserRoutingPreference } from "../types";
import { SessionManager } from "./sessionManager";
import { ProxyRequestMetadata } from "./proxyHeaders";

export interface BackendSelectionOptions {
  /** User routing preference (legacy) */
  userPreference?: TorUserRoutingPreference | null;
  
  /** Request metadata from headers */
  metadata?: ProxyRequestMetadata | null;
  
  /** Exclude these backend IDs (for retry logic) */
  excludeBackends?: string[];
}

export class RotatingBalancer {
  private cursor = 0;
  private sessionManager: SessionManager;

  constructor(
    private readonly backends: TorBackend[],
    private readonly getRoutingConfig?: () => Record<string, TorInstanceRoutingConfig>,
    private readonly getRoutingConfigForInstance?: (instanceId: number) => TorInstanceRoutingConfig,
    sessionTtlMs = 3600000
  ) {
    this.sessionManager = new SessionManager(sessionTtlMs);
  }

  /**
   * Select backend with smart routing support
   */
  selectBackend(options: BackendSelectionOptions = {}): TorBackend {
    const { userPreference, metadata, excludeBackends = [] } = options;
    
    let healthy = this.backends.filter((backend) => backend.healthy);
    if (healthy.length === 0) {
      throw new Error("No healthy Tor backend available");
    }

    // Exclude failed backends (for retry)
    if (excludeBackends.length > 0) {
      healthy = healthy.filter(b => !excludeBackends.includes(String(b.id)));
      if (healthy.length === 0) {
        throw new Error("No healthy Tor backend available after exclusions");
      }
    }

    // Session-based sticky routing (highest priority)
    if (metadata?.sessionId) {
      const sessionBackend = this.sessionManager.getBackend(metadata.sessionId, healthy);
      if (sessionBackend) {
        return sessionBackend;
      }
    }

    const routing = this.getRoutingConfig?.() ?? {};

    // Country preference from headers (X-Proxy-Country)
    if (metadata?.preferredCountries && metadata.preferredCountries.length > 0) {
      const backend = this.selectByCountryPreference(healthy, metadata.preferredCountries, routing);
      if (backend) {
        // Save to session if session ID provided
        if (metadata.sessionId) {
          this.sessionManager.setBackend(metadata.sessionId, String(backend.id));
        }
        return backend;
      }
    }

    // User sticky routing (legacy)
    if (userPreference?.mode === "sticky" && normalizeCountryCode(userPreference.countryCode)) {
      const targetCode = normalizeCountryCode(userPreference.countryCode);
      const preferred = healthy.filter(
        (backend) => normalizeCountryCode(backend.countryCode) === targetCode
      );
      const backend = this.selectWeightedBackend(preferred.length > 0 ? preferred : healthy, routing);
      
      if (metadata?.sessionId) {
        this.sessionManager.setBackend(metadata.sessionId, String(backend.id));
      }
      return backend;
    }

    // Default weighted selection
    const backend = this.selectWeightedBackend(healthy, routing);
    
    if (metadata?.sessionId) {
      this.sessionManager.setBackend(metadata.sessionId, String(backend.id));
    }
    
    return backend;
  }

  /**
   * Select backend by country preference list (fallback order)
   */
  private selectByCountryPreference(
    candidates: TorBackend[],
    preferredCountries: string[],
    routing: Record<string, TorInstanceRoutingConfig>
  ): TorBackend | null {
    // Try each country in order
    for (const country of preferredCountries) {
      const matching = candidates.filter(
        (backend) => normalizeCountryCode(backend.countryCode) === country
      );
      
      if (matching.length > 0) {
        return this.selectWeightedBackend(matching, routing);
      }
    }

    // No match found, return null to fallback to default selection
    return null;
  }

  /**
   * Get session manager stats
   */
  getSessionStats() {
    return this.sessionManager.getStats();
  }

  /**
   * Clear a specific session
   */
  clearSession(sessionId: string): void {
    this.sessionManager.removeSession(sessionId);
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    this.sessionManager.destroy();
  }

  private selectWeightedBackend(
    candidates: TorBackend[],
    routing: Record<string, TorInstanceRoutingConfig>
  ): TorBackend {
    const weighted = candidates
      .map((backend) => {
        const config = routing[String(backend.id)]
          ?? this.getRoutingConfigForInstance?.(backend.id)
          ?? null;
        return {
          backend,
          weight: computeWeight(backend, config, candidates)
        };
      })
      .filter((item) => item.weight > 0);

    if (weighted.length === 0) {
      const hasStrictPinned = candidates.some((backend) => {
        const config = routing[String(backend.id)]
          ?? this.getRoutingConfigForInstance?.(backend.id)
          ?? null;
        return (
          config !== null &&
          config.mode === "pinned-country" &&
          config.strict === true &&
          normalizeCountryCode(config.targetCountryCode) !== null
        );
      });

      if (hasStrictPinned) {
        throw new Error("No healthy Tor backend matches strict country pinning");
      }

      // Fallback round-robin
      const backend = candidates[this.cursor % candidates.length];
      this.cursor = (this.cursor + 1) % Number.MAX_SAFE_INTEGER;
      return backend;
    }

    const totalWeight = weighted.reduce((sum, item) => sum + item.weight, 0);
    const roll = Math.random() * totalWeight;
    let cumulative = 0;

    for (const item of weighted) {
      cumulative += item.weight;
      if (roll <= cumulative) {
        return item.backend;
      }
    }

    return weighted[weighted.length - 1].backend;
  }
}

function computeWeight(
  backend: TorBackend,
  config: TorInstanceRoutingConfig | null,
  healthyBackends: TorBackend[]
): number {
  if (!config || config.mode === "random") {
    return 1;
  }

  const backendCountry = normalizeCountryCode(backend.countryCode);
  const targetCountry = normalizeCountryCode(config.targetCountryCode);
  const fallbackCountry = normalizeCountryCode(config.fallbackCountryCode);
  const targetMatches = Boolean(targetCountry && backendCountry && backendCountry === targetCountry);
  const fallbackMatches = Boolean(fallbackCountry && backendCountry && backendCountry === fallbackCountry);

  if (config.mode === "sticky") {
    if (targetMatches) return Math.max(1, config.weightPercent);
    if (fallbackMatches) return Math.max(1, 100 - config.weightPercent);
    return 1;
  }

  if (config.mode === "pinned-country") {
    if (targetMatches) return 100;

    if (config.strict) {
      return 0;
    }

    if (fallbackMatches) return 25;
    return healthyBackends.length > 1 ? 1 : 100;
  }

  return 1;
}

function normalizeCountryCode(value: string | null | undefined): string | null {
  if (!value || typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toUpperCase();
  return /^[A-Z]{2,3}$/.test(normalized) ? normalized : null;
}
