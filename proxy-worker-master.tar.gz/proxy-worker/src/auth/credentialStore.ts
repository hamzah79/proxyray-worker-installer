import { Buffer } from "node:buffer";

import { RuntimeStateStore } from "../config/runtimeStateStore";
import { UsersRepository } from "../db/repositories/usersRepository";
import { verifyPassword } from "./password";
import { AuthSession } from "../types";
import { logger } from "../observability/logger";

export type AuthFailureReason =
  | "missing_header"
  | "invalid_scheme"
  | "invalid_base64"
  | "invalid_format"
  | "user_not_found"
  | "invalid_password"
  | "ip_not_whitelisted";

export interface AuthCheckResult {
  session: AuthSession | null;
  reason: AuthFailureReason | null;
  username: string | null;
}

export class CredentialStore {
  private readonly runtimeStateStore: RuntimeStateStore;
  private readonly usersRepo: UsersRepository | null;
  private readonly activeSessions = new Map<string, number>();

  constructor(runtimeStateStore: RuntimeStateStore, usersRepo?: UsersRepository | null) {
    this.runtimeStateStore = runtimeStateStore;
    this.usersRepo = usersRepo ?? null;
  }

  authenticateProxyAuthorization(headerValue?: string, clientIp?: string): AuthSession | null {
    return this.authenticateProxyAuthorizationDetailedSync(headerValue, clientIp).session;
  }

  authenticateProxyAuthorizationDetailedSync(headerValue?: string, clientIp?: string): AuthCheckResult {
    const parsed = this.parseProxyAuthHeader(headerValue);
    if ("error" in parsed) return parsed.error;
    return this.validateUserPassDetailedSync(parsed.username, parsed.password, clientIp);
  }

  async authenticateProxyAuthorizationDetailed(headerValue?: string, clientIp?: string): Promise<AuthCheckResult> {
    const parsed = this.parseProxyAuthHeader(headerValue);
    if ("error" in parsed) return parsed.error;
    return this.validateUserPassDetailed(parsed.username, parsed.password, clientIp);
  }

  private parseProxyAuthHeader(headerValue?: string): { username: string; password: string } | { error: AuthCheckResult } {
    if (!headerValue) {
      return { error: { session: null, reason: "missing_header", username: null } };
    }

    const parts = headerValue.split(" ");
    const scheme = parts[0];
    const encoded = parts[1];
    
    if (!scheme || !encoded) {
      return { error: { session: null, reason: "invalid_scheme", username: null } };
    }
    
    if (scheme.toLowerCase() !== "basic") {
      return { error: { session: null, reason: "invalid_scheme", username: null } };
    }

    let decoded = "";
    try {
      decoded = Buffer.from(encoded, "base64").toString("utf8");
    } catch {
      return { error: { session: null, reason: "invalid_base64", username: null } };
    }

    const separatorIdx = decoded.indexOf(":");
    if (separatorIdx <= 0) {
      return { error: { session: null, reason: "invalid_format", username: null } };
    }

    const username = decoded.slice(0, separatorIdx);
    const password = decoded.slice(separatorIdx + 1);

    return { username, password };
  }

  authenticateSocks(username: string, password: string, clientIp?: string): boolean {
    return this.authenticateSocksDetailedSync(username, password, clientIp).session !== null;
  }

  /** Synchronous check – only looks at runtime-state (legacy callers). */
  authenticateSocksDetailedSync(username: string, password: string, clientIp?: string): AuthCheckResult {
    return this.validateUserPassDetailedSync(username, password, clientIp);
  }

  /** Async check – tries runtime-state first, then falls back to database. */
  async authenticateSocksDetailed(username: string, password: string, clientIp?: string): Promise<AuthCheckResult> {
    return this.validateUserPassDetailed(username, password, clientIp);
  }

  isIpAllowed(username: string, clientIp?: string): boolean {
    return this.runtimeStateStore.isIpWhitelisted(username, clientIp);
  }

  beginSession(username: string, maxConcurrentOverride?: number): boolean {
    const maxConcurrentPerUser =
      typeof maxConcurrentOverride === "number" && maxConcurrentOverride > 0
        ? maxConcurrentOverride
        : this.runtimeStateStore.getMaxConcurrentPerUser();
    const current = this.activeSessions.get(username) ?? 0;
    if (current >= maxConcurrentPerUser) {
      return false;
    }

    this.activeSessions.set(username, current + 1);
    return true;
  }

  endSession(username: string): void {
    const current = this.activeSessions.get(username) ?? 0;
    if (current <= 1) {
      this.activeSessions.delete(username);
      return;
    }

    this.activeSessions.set(username, current - 1);
  }

  getActiveSessionCount(username: string): number {
    return this.activeSessions.get(username) ?? 0;
  }

  /** Synchronous – only checks runtime-state (plain-text passwords). */
  private validateUserPassDetailedSync(username: string, password: string, clientIp?: string): AuthCheckResult {
    const users = this.runtimeStateStore.getUsersMap();
    const expected = users.get(username);
    if (!expected) {
      return { session: null, reason: "user_not_found", username };
    }

    if (expected !== password) {
      return { session: null, reason: "invalid_password", username };
    }

    // Skip IP whitelist check if clientIp is not provided (e.g., SOCKS5 auth callback)
    // IP check will be done later when clientIp is available
    if (clientIp !== undefined && !this.isIpAllowed(username, clientIp)) {
      return { session: null, reason: "ip_not_whitelisted", username };
    }

    return { session: { username }, reason: null, username };
  }

  /**
   * Async – tries runtime-state first (plain-text), then falls back to
   * database lookup with hashed password verification.  This allows users
   * that only exist in the database (registered via dashboard) to
   * authenticate through the SOCKS5 / HTTP proxy.
   */
  private async validateUserPassDetailed(username: string, password: string, clientIp?: string): Promise<AuthCheckResult> {
    // 1. Try runtime-state (fast, in-memory, plain-text passwords)
    const syncResult = this.validateUserPassDetailedSync(username, password, clientIp);
    if (syncResult.session) {
      return syncResult;
    }

    // 2. If user was found in runtime-state but password was wrong, don't
    //    fall through to DB (the runtime-state entry is authoritative).
    if (syncResult.reason === "invalid_password") {
      return syncResult;
    }

    // 3. Fall back to database (hashed passwords)
    if (!this.usersRepo) {
      return syncResult; // no DB configured – return original result
    }

    try {
      const user = await this.usersRepo.findByUsername(username);
      if (!user) {
        return { session: null, reason: "user_not_found", username };
      }

      const passwordValid = await verifyPassword(password, user.password_hash);
      if (!passwordValid) {
        return { session: null, reason: "invalid_password", username };
      }

      // Skip IP whitelist check if clientIp is not provided
      if (clientIp !== undefined && !this.isIpAllowed(username, clientIp)) {
        return { session: null, reason: "ip_not_whitelisted", username };
      }

      logger.info("socks/proxy auth via database fallback", { username });
      return { session: { username }, reason: null, username };
    } catch (error) {
      logger.warn("database auth fallback failed", { username, error: String(error) });
      return syncResult; // return original result on DB error
    }
  }
}
