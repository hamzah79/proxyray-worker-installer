import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";

export interface UserSession {
  userId: string;
  username: string;
  role: "admin" | "user";
  expiresAt: number;
}

export class SessionStore {
  private readonly sessions = new Map<string, UserSession>();
  private readonly revoked = new Map<string, number>();

  constructor(
    private readonly ttlMs: number,
    private readonly secret: string
  ) {}

  private encodePayload(payload: object): string {
    return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
  }

  private decodePayload(value: string): Record<string, unknown> | null {
    try {
      const decoded = Buffer.from(value, "base64url").toString("utf8");
      const parsed = JSON.parse(decoded) as Record<string, unknown>;
      return parsed;
    } catch {
      return null;
    }
  }

  private sign(value: string): string {
    return createHmac("sha256", this.secret).update(value).digest("base64url");
  }

  private verifySignature(value: string, signature: string): boolean {
    const expected = this.sign(value);
    const expectedBuffer = Buffer.from(expected, "utf8");
    const signatureBuffer = Buffer.from(signature, "utf8");
    if (expectedBuffer.length !== signatureBuffer.length) {
      return false;
    }

    return timingSafeEqual(expectedBuffer, signatureBuffer);
  }

  private purgeRevoked(): void {
    const now = Date.now();
    for (const [token, expiresAt] of this.revoked.entries()) {
      if (expiresAt <= now) {
        this.revoked.delete(token);
      }
    }
  }

  createSession(session: Omit<UserSession, "expiresAt">): { token: string; session: UserSession } {
    const nonce = randomBytes(8).toString("hex");
    const fullSession: UserSession = {
      ...session,
      expiresAt: Date.now() + this.ttlMs
    };

    const payload = this.encodePayload({
      uid: fullSession.userId,
      usr: fullSession.username,
      rol: fullSession.role,
      exp: fullSession.expiresAt,
      n: nonce
    });
    const signature = this.sign(payload);
    const token = `${payload}.${signature}`;

    this.sessions.set(token, fullSession);
    return { token, session: fullSession };
  }

  getSession(token: string): UserSession | null {
    this.purgeRevoked();
    if (this.revoked.has(token)) {
      return null;
    }

    const session = this.sessions.get(token);
    if (session) {
      if (session.expiresAt <= Date.now()) {
        this.sessions.delete(token);
        return null;
      }

      return session;
    }

    const [payload, signature] = token.split(".");
    if (!payload || !signature || !this.verifySignature(payload, signature)) {
      return null;
    }

    const parsed = this.decodePayload(payload);
    if (!parsed) {
      return null;
    }

    const userId = typeof parsed.uid === "string" ? parsed.uid : "";
    const username = typeof parsed.usr === "string" ? parsed.usr : "";
    const role = parsed.rol === "admin" || parsed.rol === "user" ? parsed.rol : null;
    const expiresAt = Number(parsed.exp);

    if (!userId || !username || !role || !Number.isFinite(expiresAt)) {
      return null;
    }

    if (expiresAt <= Date.now()) {
      return null;
    }

    return {
      userId,
      username,
      role,
      expiresAt
    };
  }

  revokeSession(token: string): void {
    this.sessions.delete(token);
    this.revoked.set(token, Date.now() + this.ttlMs);
  }
}
