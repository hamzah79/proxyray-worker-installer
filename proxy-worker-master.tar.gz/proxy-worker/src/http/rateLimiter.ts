import Redis from "ioredis";

interface Bucket {
  count: number;
  resetAt: number;
}

export interface RateLimiter {
  consume(key: string): Promise<{ allowed: boolean; remaining: number; resetAt: number }>;
}

export class FixedWindowRateLimiter implements RateLimiter {
  private readonly buckets = new Map<string, Bucket>();

  constructor(
    private readonly windowMs: number,
    private readonly maxPerWindow: number
  ) {}

  async consume(key: string): Promise<{ allowed: boolean; remaining: number; resetAt: number }> {
    const now = Date.now();
    const current = this.buckets.get(key);

    if (!current || current.resetAt <= now) {
      const fresh: Bucket = {
        count: 1,
        resetAt: now + this.windowMs
      };
      this.buckets.set(key, fresh);
      return { allowed: true, remaining: this.maxPerWindow - 1, resetAt: fresh.resetAt };
    }

    if (current.count >= this.maxPerWindow) {
      return { allowed: false, remaining: 0, resetAt: current.resetAt };
    }

    current.count += 1;
    return { allowed: true, remaining: this.maxPerWindow - current.count, resetAt: current.resetAt };
  }
}

export class RedisFixedWindowRateLimiter implements RateLimiter {
  constructor(
    private readonly redis: Redis,
    private readonly windowMs: number,
    private readonly maxPerWindow: number,
    private readonly keyPrefix: string
  ) {}

  async consume(key: string): Promise<{ allowed: boolean; remaining: number; resetAt: number }> {
    const now = Date.now();
    const windowIndex = Math.floor(now / this.windowMs);
    const resetAt = (windowIndex + 1) * this.windowMs;
    const redisKey = `${this.keyPrefix}:ratelimit:${key}:${windowIndex}`;
    const ttlMs = Math.max(1, resetAt - now);

    const multi = this.redis.multi();
    multi.incr(redisKey);
    multi.pexpire(redisKey, ttlMs);
    const result = await multi.exec();
    const count = Number(result?.[0]?.[1] ?? 0);

    if (count <= 0) {
      return { allowed: true, remaining: this.maxPerWindow - 1, resetAt };
    }

    const allowed = count <= this.maxPerWindow;
    const remaining = allowed ? this.maxPerWindow - count : 0;
    return { allowed, remaining, resetAt };
  }
}
