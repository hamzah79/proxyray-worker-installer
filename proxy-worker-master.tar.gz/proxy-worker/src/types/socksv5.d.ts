declare module "socksv5" {
  import { Socket } from "node:net";

  namespace socks {
    interface RequestInfo {
      dstAddr: string;
      dstPort: number;
      srcAddr?: string;
      srcPort?: number;
    }

    type AcceptFn = (intercept?: boolean) => Socket;
    type DenyFn = () => void;

    interface Server {
      useAuth(authHandler: unknown): void;
      listen(port: number, host?: string, callback?: () => void): this;
      close(callback?: (err?: Error) => void): void;
      on(event: string, listener: (...args: unknown[]) => void): this;
    }

    interface AuthNamespace {
      None(): unknown;
      UserPassword(
        verifier: (
          username: string,
          password: string,
          callback: (success: boolean, userId?: number) => void
        ) => void
      ): unknown;
    }

    function createServer(
      handler: (info: RequestInfo, accept: AcceptFn, deny: DenyFn) => void
    ): Server;

    const auth: AuthNamespace;
  }

  export = socks;
}
