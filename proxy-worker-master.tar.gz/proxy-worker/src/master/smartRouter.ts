import Redis from "ioredis";

import { WorkerInfo } from "../worker/workerAgent";
import { WorkerRegistry } from "./workerRegistry";
import { logger } from "../observability/logger";

export type RoutingStrategy = "geo" | "load" | "sticky" | "round-robin";

export interface UserWorkerAssignment {
  workerId: string;
  publicHost: string;
  httpProxyPort: number;
  socksProxyPort: number;
  region: string;
  strategy: RoutingStrategy;
  assignedAt: string;
}

export interface SmartRouterConfig {
  defaultStrategy: RoutingStrategy;
  assignmentTtlSeconds: number;
  healthThresholdPercent: number;
  circuitBreakerThreshold: number;
  circuitBreakerCooldownSeconds: number;
}

const DEFAULT_CONFIG: SmartRouterConfig = {
  defaultStrategy: "load",
  assignmentTtlSeconds: 300, // 5 minutes instead of 1 hour - faster rebalancing
  healthThresholdPercent: 50,
  circuitBreakerThreshold: 3,
  circuitBreakerCooldownSeconds: 60,
};

interface CircuitBreakerEntry {
  failures: number;
  lastFailureAt: number;
  openUntil: number;
}

export class SmartRouter {
  private readonly redis: Redis;
  private readonly keyPrefix: string;
  private readonly registry: WorkerRegistry;
  private readonly config: SmartRouterConfig;
  private circuitBreakers: Map<string, CircuitBreakerEntry> = new Map();
  private rrIndex = 0;

  constructor(params: {
    redis: Redis;
    keyPrefix: string;
    registry: WorkerRegistry;
    config?: Partial<SmartRouterConfig>;
  }) {
    this.redis = params.redis;
    this.keyPrefix = params.keyPrefix;
    this.registry = params.registry;
    this.config = { ...DEFAULT_CONFIG, ...params.config };
  }

  private assignmentKey(username: string): string {
    return `${this.keyPrefix}:routing:${username}`;
  }

  private overideKey(username: string): string {
    return `${this.keyPrefix}:routing_override:${username}`;
  }

  async resolve(username: string, hints?: { clientRegion?: string }): Promise<UserWorkerAssignment | null> {
    const override = await this.getOverride(username);
    if (override) {
      const worker = await this.registry.getWorkerById(override);
      if (worker && this.isWorkerUsable(worker)) {
        const assignment = this.buildAssignment(worker, "sticky");
        await this.storeAssignment(username, assignment);
        return assignment;
      }
      logger.warn("routing override target unavailable", { username, overideWorkerId: override });
    }
    const existing = await this.getAssignment(username);
    if (existing) {
      const worker = await this.registry.getWorkerById(existing.workerId);
      if (worker && this.isWorkerUsable(worker)) {
        return existing;
      }
      logger.info("assigned worker unavailable, failover", { username, oldWorkerId: existing.workerId });
      await this.clearAssignment(username);
    }
    const workers = await this.getUsableWorkers();
    if (workers.length === 0) return null;
    const strategy = this.config.defaultStrategy;
    const picked = this.pickWorker(workers, strategy, hints);
    if (!picked) return null;
    const assignment = this.buildAssignment(picked, strategy);
    await this.storeAssignment(username, assignment);
    return assignment;
  }

  async getAssignment(username: string): Promise<UserWorkerAssignment | null> {
    const raw = await this.redis.get(this.assignmentKey(username));
    if (!raw) return null;
    try {
      return JSON.parse(raw) as UserWorkerAssignment;
    } catch {
      return null;
    }
  }

  async getAllAssignments(): Promise<Array<{ username: string; assignment: UserWorkerAssignment }>> {
    const pattern = `${this.keyPrefix}:routing:*`;
    const keys = await this.redis.keys(pattern);
    const results: Array<{ username: string; assignment: UserWorkerAssignment }> = [];
    
    for (const key of keys) {
      const username = key.replace(`${this.keyPrefix}:routing:`, '');
      const raw = await this.redis.get(key);
      if (raw) {
        try {
          const assignment = JSON.parse(raw) as UserWorkerAssignment;
          results.push({ username, assignment });
        } catch {
          // Skip invalid entries
        }
      }
    }
    
    return results;
  }

  async clearAssignment(username: string): Promise<void> {
    await this.redis.del(this.assignmentKey(username));
  }

  async setOveride(username: string, workerId: string): Promise<void> {
    await this.redis.set(this.overideKey(username), workerId);
    await this.clearAssignment(username);
    logger.info("routing override set", { username, workerId });
  }

  async clearOverride(username: string): Promise<void> {
    await this.redis.del(this.overideKey(username));
    await this.clearAssignment(username);
    logger.info("routing override cleared", { username });
  }

  async getOverride(username: string): Promise<string | null> {
    return this.redis.get(this.overideKey(username));
  }

  reportFailure(workerId: string): void {
    const now = Date.now();
    const entry = this.circuitBreakers.get(workerId) || { failures: 0, lastFailureAt: 0, openUntil: 0 };
    entry.failures += 1;
    entry.lastFailureAt = now;
    if (entry.failures >= this.config.circuitBreakerThreshold) {
      entry.openUntil = now + this.config.circuitBreakerCooldownSeconds * 1000;
      logger.warn("circuit breaker opened", { workerId, failures: entry.failures });
    }
    this.circuitBreakers.set(workerId, entry);
  }

  reportSuccess(workerId: string): void {
    this.circuitBreakers.delete(workerId);
  }

  isCircuitOpen(workerId: string): boolean {
    const entry = this.circuitBreakers.get(workerId);
    if (!entry) return false;
    if (entry.openUntil <= Date.now()) {
      this.circuitBreakers.delete(workerId);
      return false;
    }
    return true;
  }

  getCircuitBreakerStats(): Array<{ workerId: string; failures: number; openUntil: number }> {
    const stats: Array<{ workerId: string; failures: number; openUntil: number }> = [];
    const now = Date.now();
    
    this.circuitBreakers.forEach((entry, workerId) => {
      if (entry.openUntil > now) {
        stats.push({ workerId, failures: entry.failures, openUntil: entry.openUntil });
      }
    });
    
    return stats;
  }

  resetCircuitBreaker(workerId: string): void {
    this.circuitBreakers.delete(workerId);
    logger.info("circuit breaker reset", { workerId });
  }

  private async storeAssignment(username: string, assignment: UserWorkerAssignment): Promise<void> {
    await this.redis.set(
      this.assignmentKey(username),
      JSON.stringify(assignment),
      "EX",
      this.config.assignmentTtlSeconds,
    );
  }

  private buildAssignment(worker: WorkerInfo, strategy: RoutingStrategy): UserWorkerAssignment {
    return {
      workerId: worker.id,
      publicHost: worker.publicHost,
      httpProxyPort: worker.httpProxyPort,
      socksProxyPort: worker.socksProxyPort,
      region: worker.region,
      strategy,
      assignedAt: new Date().toISOString(),
    };
  }

  private async getUsableWorkers(): Promise<WorkerInfo[]> {
    const all = await this.registry.getAllWorkers();
    return all.filter((w) => this.isWorkerUsable(w));
  }

  private isWorkerUsable(worker: WorkerInfo & { alive?: boolean }): boolean {
    if ("alive" in worker && !worker.alive) return false;
    if (this.isCircuitOpen(worker.id)) return false;
    if (worker.torInstancesTotal === 0) return false;
    const hp = (worker.torInstancesHealthy / worker.torInstancesTotal) * 100;
    if (hp < this.config.healthThresholdPercent) return false;
    if (worker.status === "draining") return false;
    return true;
  }

  private pickWorker(workers: WorkerInfo[], strategy: RoutingStrategy, hints?: { clientRegion?: string }): WorkerInfo | null {
    if (workers.length === 0) return null;
    switch (strategy) {
      case "geo": return this.pickByGeo(workers, hints?.clientRegion);
      case "load": return this.pickByLoad(workers);
      case "round-robin": return this.pickRoundRobin(workers);
      case "sticky": return this.pickByLoad(workers);
      default: return this.pickByLoad(workers);
    }
  }

  private pickByGeo(workers: WorkerInfo[], clientRegion?: string): WorkerInfo {
    if (clientRegion) {
      const n = clientRegion.trim().toLowerCase();
      const regional = workers.filter((w) => w.region.toLowerCase() === n);
      if (regional.length > 0) return this.pickByLoad(regional);
    }
    return this.pickByLoad(workers);
  }

  private pickByLoad(workers: WorkerInfo[]): WorkerInfo {
    let best = workers[0];
    let bestScore = this.loadScore(best);
    for (let i = 1; i < workers.length; i++) {
      const score = this.loadScore(workers[i]);
      // Prefer worker with lower score, or if equal, prefer more Tor instances
      if (score < bestScore || (score === bestScore && workers[i].torInstancesHealthy > best.torInstancesHealthy)) {
        best = workers[i];
        bestScore = score;
      }
    }
    return best;
  }

  private loadScore(worker: WorkerInfo): number {
    return worker.activeConnections / Math.max(1, worker.torInstancesHealthy);
  }

  private pickRoundRobin(workers: WorkerInfo[]): WorkerInfo {
    const index = this.rrIndex % workers.length;
    this.rrIndex = (this.rrIndex + 1) % Number.MAX_SAFE_INTEGER;
    return workers[index];
  }

  /**
   * Clear all user assignments - forces immediate rebalancing on next request
   */
  async clearAllAssignments(): Promise<number> {
    const pattern = `${this.keyPrefix}:routing:*`;
    const keys = await this.redis.keys(pattern);
    if (keys.length === 0) return 0;
    await this.redis.del(...keys);
    logger.info("cleared all routing assignments", { count: keys.length });
    return keys.length;
  }

  /**
   * Auto-rebalance: clear assignments for overloaded workers
   * Call this periodically (e.g., every 30 seconds)
   */
  async autoRebalance(overloadThreshold = 5): Promise<void> {
    const workers = await this.registry.getAllWorkers();
    const overloadedWorkerIds = workers
      .filter((w) => w.alive && this.loadScore(w) > overloadThreshold)
      .map((w) => w.id);

    if (overloadedWorkerIds.length === 0) return;

    logger.warn("detected overloaded workers, clearing assignments", {
      workerIds: overloadedWorkerIds,
      threshold: overloadThreshold,
    });

    // Clear assignments for users on overloaded workers
    const pattern = `${this.keyPrefix}:routing:*`;
    const keys = await this.redis.keys(pattern);
    let cleared = 0;

    for (const key of keys) {
      const raw = await this.redis.get(key);
      if (!raw) continue;
      try {
        const assignment = JSON.parse(raw) as UserWorkerAssignment;
        if (overloadedWorkerIds.includes(assignment.workerId)) {
          await this.redis.del(key);
          cleared++;
        }
      } catch {
        // corrupted data, skip
      }
    }

    if (cleared > 0) {
      logger.info("auto-rebalance cleared assignments", { count: cleared });
    }
  }
}