import Redis from "ioredis";

import { WorkerInfo } from "../worker/workerAgent";
import { logger } from "../observability/logger";

export interface ClusterStats {
  totalWorkers: number;
  onlineWorkers: number;
  degradedWorkers: number;
  offlineWorkers: number;
  totalTorInstances: number;
  healthyTorInstances: number;
  totalActiveConnections: number;
  regions: Array<{
    region: string;
    workerCount: number;
    torHealthy: number;
    torTotal: number;
    activeConnections: number;
  }>;
  updatedAt: string;
}

export class WorkerRegistry {
  private readonly redis: Redis;
  private readonly keyPrefix: string;

  constructor(redis: Redis, keyPrefix?: string) {
    this.redis = redis;
    this.keyPrefix = keyPrefix || "proxy";
  }

  /**
   * Get all registered worker IDs from the index set.
   */
  async getWorkerIds(): Promise<string[]> {
    return this.redis.smembers(`${this.keyPrefix}:workers:_index`);
  }

  /**
   * Get a single worker's info by ID.
   * Returns null if the worker key has expired (offline).
   */
  async getWorkerById(id: string): Promise<WorkerInfo | null> {
    const raw = await this.redis.get(`${this.keyPrefix}:workers:${id}`);
    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw) as WorkerInfo;
    } catch {
      return null;
    }
  }

  /**
   * Get all workers with their current info.
   * Workers whose keys have expired are returned with status "offline".
   */
  async getAllWorkers(): Promise<Array<WorkerInfo & { alive: boolean }>> {
    const ids = await this.getWorkerIds();
    if (ids.length === 0) {
      return [];
    }

    const keys = ids.map((id) => `${this.keyPrefix}:workers:${id}`);
    const rawValues = await this.redis.mget(...keys);

    const results: Array<WorkerInfo & { alive: boolean }> = [];

    for (let i = 0; i < ids.length; i++) {
      const raw = rawValues[i];
      if (raw) {
        try {
          const info = JSON.parse(raw) as WorkerInfo;
          results.push({ ...info, alive: true });
        } catch {
          // corrupted data, skip
        }
      } else {
        // Key expired — worker is offline
        results.push({
          id: ids[i],
          region: "",
          publicHost: "",
          httpProxyPort: 0,
          socksProxyPort: 0,
          adminPort: 0,
          torInstancesTotal: 0,
          torInstancesHealthy: 0,
          activeConnections: 0,
          uptimeSeconds: 0,
          lastHeartbeat: "",
          version: "",
          status: "online",
          alive: false,
        });
      }
    }

    return results;
  }

  /**
   * Get only healthy (alive) workers.
   */
  async getHealthyWorkers(): Promise<WorkerInfo[]> {
    const all = await this.getAllWorkers();
    return all.filter((w) => w.alive && w.status !== "degraded");
  }

  /**
   * Get workers filtered by region.
   */
  async getWorkersByRegion(region: string): Promise<Array<WorkerInfo & { alive: boolean }>> {
    const all = await this.getAllWorkers();
    const normalizedRegion = region.trim().toLowerCase();
    return all.filter((w) => w.region.toLowerCase() === normalizedRegion);
  }

  /**
   * Check if a specific worker is alive (key exists and not expired).
   */
  async isWorkerAlive(id: string): Promise<boolean> {
    const exists = await this.redis.exists(`${this.keyPrefix}:workers:${id}`);
    return exists === 1;
  }

  /**
   * Get cluster-wide statistics.
   */
  async getClusterStats(): Promise<ClusterStats> {
    const all = await this.getAllWorkers();

    let totalTorInstances = 0;
    let healthyTorInstances = 0;
    let totalActiveConnections = 0;
    let onlineWorkers = 0;
    let degradedWorkers = 0;
    let offlineWorkers = 0;

    const regionMap = new Map<string, {
      region: string;
      workerCount: number;
      torHealthy: number;
      torTotal: number;
      activeConnections: number;
    }>();

    for (const worker of all) {
      if (!worker.alive) {
        offlineWorkers += 1;
        continue;
      }

      if (worker.status === "degraded") {
        degradedWorkers += 1;
      } else {
        onlineWorkers += 1;
      }

      totalTorInstances += worker.torInstancesTotal;
      healthyTorInstances += worker.torInstancesHealthy;
      totalActiveConnections += worker.activeConnections;

      const regionKey = (worker.region || "unknown").toLowerCase();
      const existing = regionMap.get(regionKey) || {
        region: worker.region || "unknown",
        workerCount: 0,
        torHealthy: 0,
        torTotal: 0,
        activeConnections: 0,
      };
      existing.workerCount += 1;
      existing.torHealthy += worker.torInstancesHealthy;
      existing.torTotal += worker.torInstancesTotal;
      existing.activeConnections += worker.activeConnections;
      regionMap.set(regionKey, existing);
    }

    return {
      totalWorkers: all.length,
      onlineWorkers,
      degradedWorkers,
      offlineWorkers,
      totalTorInstances,
      healthyTorInstances,
      totalActiveConnections,
      regions: Array.from(regionMap.values()).sort((a, b) => a.region.localeCompare(b.region)),
      updatedAt: new Date().toISOString(),
    };
  }

  /**
   * Cleanup stale worker IDs from the index set.
   * Removes IDs whose keys have expired.
   */
  async cleanupStaleWorkers(): Promise<number> {
    const ids = await this.getWorkerIds();
    let removed = 0;

    for (const id of ids) {
      const exists = await this.redis.exists(`${this.keyPrefix}:workers:${id}`);
      if (exists === 0) {
        await this.redis.srem(`${this.keyPrefix}:workers:_index`, id);
        removed += 1;
        logger.info("removed stale worker from index", { workerId: id });
      }
    }

    return removed;
  }
}