import Redis from "ioredis";
import { randomBytes } from "node:crypto";

import { logger } from "../observability/logger";

export type CommandAction =
  | "rotate_all"
  | "update_config"
  | "shutdown"
  | "ping";

export interface WorkerCommand {
  id: string;
  action: CommandAction;
  payload: Record<string, unknown>;
  issuedAt: string;
  issuedBy: string;
}

export interface CommandResult {
  commandId: string;
  workerId: string;
  status: "ok" | "error";
  message: string;
  completedAt: string;
}

/**
 * CommandDispatcher runs on the Master server.
 * It pushes commands to per-worker Redis lists and reads back results.
 */
export class CommandDispatcher {
  private readonly redis: Redis;
  private readonly keyPrefix: string;

  constructor(redis: Redis, keyPrefix?: string) {
    this.redis = redis;
    this.keyPrefix = keyPrefix || "proxy";
  }

  /**
   * Generate a unique command ID.
   */
  private generateCommandId(): string {
    return randomBytes(12).toString("hex");
  }

  /**
   * Redis key for a worker's command queue (list).
   */
  private commandQueueKey(workerId: string): string {
    return `${this.keyPrefix}:commands:${workerId}`;
  }

  /**
   * Redis key for a command result.
   */
  private commandResultKey(commandId: string): string {
    return `${this.keyPrefix}:command_results:${commandId}`;
  }

  /**
   * Redis key for a worker's command history (sorted set by timestamp).
   */
  private commandHistoryKey(workerId: string): string {
    return `${this.keyPrefix}:command_history:${workerId}`;
  }

  /**
   * Dispatch a command to a specific worker.
   * Returns the command object with its generated ID.
   */
  async dispatch(workerId: string, action: CommandAction, payload: Record<string, unknown> = {}, issuedBy = "admin"): Promise<WorkerCommand> {
    const command: WorkerCommand = {
      id: this.generateCommandId(),
      action,
      payload,
      issuedAt: new Date().toISOString(),
      issuedBy,
    };

    const serialized = JSON.stringify(command);

    const pipeline = this.redis.pipeline();
    // Push command to the worker's queue
    pipeline.lpush(this.commandQueueKey(workerId), serialized);
    // Keep queue bounded (max 100 pending commands)
    pipeline.ltrim(this.commandQueueKey(workerId), 0, 99);
    // Add to history sorted set (score = timestamp ms)
    pipeline.zadd(this.commandHistoryKey(workerId), Date.now().toString(), serialized);
    // Trim history to last 200 entries
    pipeline.zremrangebyrank(this.commandHistoryKey(workerId), 0, -201);
    // Set TTL on history key (7 days)
    pipeline.expire(this.commandHistoryKey(workerId), 7 * 24 * 60 * 60);
    await pipeline.exec();

    logger.info("command dispatched", {
      commandId: command.id,
      workerId,
      action,
    });

    return command;
  }

  /**
   * Dispatch a command to all workers in the index set.
   */
  async dispatchToAll(action: CommandAction, payload: Record<string, unknown> = {}, issuedBy = "admin"): Promise<WorkerCommand[]> {
    const workerIds = await this.redis.smembers(`${this.keyPrefix}:workers:_index`);
    const commands: WorkerCommand[] = [];

    for (const workerId of workerIds) {
      const cmd = await this.dispatch(workerId, action, payload, issuedBy);
      commands.push(cmd);
    }

    return commands;
  }

  /**
   * Get the result of a command (if the worker has reported back).
   * Results have a TTL of 1 hour.
   */
  async getResult(commandId: string): Promise<CommandResult | null> {
    const raw = await this.redis.get(this.commandResultKey(commandId));
    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw) as CommandResult;
    } catch {
      return null;
    }
  }

  /**
   * Get command history for a specific worker.
   * Returns most recent commands first.
   */
  async getCommandHistory(workerId: string, limit = 50): Promise<Array<WorkerCommand & { result?: CommandResult | null }>> {
    const raw = await this.redis.zrevrange(this.commandHistoryKey(workerId), 0, limit - 1);
    const commands: Array<WorkerCommand & { result?: CommandResult | null }> = [];

    for (const entry of raw) {
      try {
        const cmd = JSON.parse(entry) as WorkerCommand;
        const result = await this.getResult(cmd.id);
        commands.push({ ...cmd, result });
      } catch {
        // skip corrupted entries
      }
    }

    return commands;
  }

  /**
   * Get pending (unprocessed) commands for a worker.
   * Returns commands in FIFO order (oldest first).
   */
  async getPendingCommands(workerId: string): Promise<WorkerCommand[]> {
    const raw = await this.redis.lrange(this.commandQueueKey(workerId), 0, -1);
    const commands: WorkerCommand[] = [];

    // lrange returns newest first (since we LPUSH), reverse for FIFO
    for (const entry of raw.reverse()) {
      try {
        commands.push(JSON.parse(entry) as WorkerCommand);
      } catch {
        // skip corrupted
      }
    }

    return commands;
  }
}