import Redis from "ioredis";

import { AppConfig } from "../config";
import { TorBackend } from "../types";
import { logger } from "../observability/logger";
import { WorkerCommand, CommandResult, CommandAction } from "../master/commandDispatcher";

export interface WorkerInfo {
  id: string;
  region: string;
  publicHost: string;
  httpProxyPort: number;
  socksProxyPort: number;
  adminPort: number;
  torInstancesTotal: number;
  torInstancesHealthy: number;
  activeConnections: number;
  uptimeSeconds: number;
  lastHeartbeat: string;
  version: string;
  status: "online" | "degraded" | "draining";
}

export type CommandHandler = (command: WorkerCommand) => Promise<{ ok: boolean; message: string }>;

export class WorkerAgent {
  private readonly redis: Redis;
  private readonly config: AppConfig;
  private readonly keyPrefix: string;
  private readonly heartbeatIntervalMs: number;
  private readonly ttlSeconds: number;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private getBackends: () => TorBackend[];
  private getActiveConnections: () => number;
  private startedAt: number;
  private commandHandlers: Map<CommandAction, CommandHandler> = new Map();

  constructor(params: {
    redis: Redis;
    config: AppConfig;
    getBackends: () => TorBackend[];
    getActiveConnections: () => number;
    heartbeatIntervalMs?: number;
    ttlSeconds?: number;
  }) {
    this.redis = params.redis;
    this.config = params.config;
    this.keyPrefix = params.config.redisKeyPrefix || "proxy";
    this.getBackends = params.getBackends;
    this.getActiveConnections = params.getActiveConnections;
    this.heartbeatIntervalMs = params.heartbeatIntervalMs ?? 10_000;
    this.ttlSeconds = params.ttlSeconds ?? 30;
    this.startedAt = Date.now();
  }

  private get workerKey(): string {
    return `${this.keyPrefix}:workers:${this.config.serverId}`;
  }

  private get commandQueueKey(): string {
    return `${this.keyPrefix}:commands:${this.config.serverId}`;
  }

  private commandResultKey(commandId: string): string {
    return `${this.keyPrefix}:command_results:${commandId}`;
  }

  private collectInfo(): WorkerInfo {
    const backends = this.getBackends();
    const healthyCount = backends.filter((b) => b.healthy).length;
    const activeConnections = this.getActiveConnections();
    const uptimeSeconds = Math.floor((Date.now() - this.startedAt) / 1000);

    let status: WorkerInfo["status"] = "online";
    if (healthyCount === 0 && backends.length > 0) {
      status = "degraded";
    } else if (healthyCount < backends.length * 0.5) {
      status = "degraded";
    }

    return {
      id: this.config.serverId,
      region: this.config.serverRegion || "",
      publicHost: this.config.publicHost || "",
      httpProxyPort: this.config.httpProxyPort,
      socksProxyPort: this.config.socksProxyPort,
      adminPort: this.config.adminPort,
      torInstancesTotal: backends.length,
      torInstancesHealthy: healthyCount,
      activeConnections,
      uptimeSeconds,
      lastHeartbeat: new Date().toISOString(),
      version: "1.0.0",
      status,
    };
  }

  /**
   * Register a handler for a specific command action.
   */
  onCommand(action: CommandAction, handler: CommandHandler): void {
    this.commandHandlers.set(action, handler);
  }

  async register(): Promise<void> {
    const info = this.collectInfo();
    const pipeline = this.redis.pipeline();
    pipeline.set(this.workerKey, JSON.stringify(info), "EX", this.ttlSeconds);
    pipeline.sadd(`${this.keyPrefix}:workers:_index`, this.config.serverId);
    await pipeline.exec();
    logger.info("worker registered", { serverId: this.config.serverId, region: info.region });
  }

  async sendHeartbeat(): Promise<void> {
    try {
      const info = this.collectInfo();
      const pipeline = this.redis.pipeline();
      pipeline.set(this.workerKey, JSON.stringify(info), "EX", this.ttlSeconds);
      pipeline.sadd(`${this.keyPrefix}:workers:_index`, this.config.serverId);
      await pipeline.exec();
    } catch (error) {
      logger.warn("worker heartbeat failed", { error: String(error), serverId: this.config.serverId });
    }
  }

  /**
   * Poll the command queue and process any pending commands.
   * Called automatically during each heartbeat cycle.
   */
  async pollCommands(): Promise<void> {
    try {
      for (let i = 0; i < 10; i++) {
        const raw = await this.redis.rpop(this.commandQueueKey);
        if (!raw) {
          break;
        }

        let command: WorkerCommand;
        try {
          command = JSON.parse(raw) as WorkerCommand;
        } catch {
          logger.warn("invalid command in queue, skipping", { raw: raw.slice(0, 200) });
          continue;
        }

        await this.executeCommand(command);
      }
    } catch (error) {
      logger.warn("command poll failed", { error: String(error), serverId: this.config.serverId });
    }
  }

  /**
   * Execute a single command and report the result back to Redis.
   */
  private async executeCommand(command: WorkerCommand): Promise<void> {
    logger.info("executing command", {
      commandId: command.id,
      action: command.action,
      serverId: this.config.serverId,
    });

    let result: CommandResult;

    try {
      const handler = this.commandHandlers.get(command.action);
      if (!handler) {
        result = {
          commandId: command.id,
          workerId: this.config.serverId,
          status: "error",
          message: `unknown_command_action: ${command.action}`,
          completedAt: new Date().toISOString(),
        };
      } else {
        const handlerResult = await handler(command);
        result = {
          commandId: command.id,
          workerId: this.config.serverId,
          status: handlerResult.ok ? "ok" : "error",
          message: handlerResult.message,
          completedAt: new Date().toISOString(),
        };
      }
    } catch (error) {
      result = {
        commandId: command.id,
        workerId: this.config.serverId,
        status: "error",
        message: String(error),
        completedAt: new Date().toISOString(),
      };
    }

    try {
      await this.redis.set(
        this.commandResultKey(command.id),
        JSON.stringify(result),
        "EX",
        3600
      );
    } catch (error) {
      logger.warn("failed to store command result", {
        commandId: command.id,
        error: String(error),
      });
    }

    logger.info("command executed", {
      commandId: command.id,
      action: command.action,
      status: result.status,
      message: result.message,
    });
  }

  startHeartbeat(): void {
    if (this.heartbeatTimer) {
      return;
    }

    this.heartbeatTimer = setInterval(() => {
      Promise.all([
        this.sendHeartbeat(),
        this.pollCommands(),
      ]).catch((error) => {
        logger.warn("worker heartbeat/poll loop error", { error: String(error) });
      });
    }, this.heartbeatIntervalMs);

    logger.info("worker heartbeat started", {
      serverId: this.config.serverId,
      intervalMs: this.heartbeatIntervalMs,
      ttlSeconds: this.ttlSeconds,
    });
  }

  async stop(): Promise<void> {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }

    try {
      const pipeline = this.redis.pipeline();
      pipeline.del(this.workerKey);
      pipeline.srem(`${this.keyPrefix}:workers:_index`, this.config.serverId);
      await pipeline.exec();
      logger.info("worker deregistered", { serverId: this.config.serverId });
    } catch (error) {
      logger.warn("worker deregister failed", { error: String(error) });
    }
  }
}