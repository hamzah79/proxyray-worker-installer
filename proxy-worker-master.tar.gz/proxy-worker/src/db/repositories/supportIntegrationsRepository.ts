import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type SupportIntegrationProvider = "telegram" | "whatsapp_click_to_chat";

export interface SupportIntegrationRecord {
  id: string;
  provider: SupportIntegrationProvider;
  name: string;
  is_active: boolean;
  telegram_bot_token: string | null;
  telegram_chat_id: string | null;
  whatsapp_phone_number: string | null;
  message_template: string | null;
  categories: string[];
  priorities: string[];
  statuses: string[];
  operating_hours: unknown;
  metadata: unknown;
  created_at: string;
  updated_at: string;
}

export class SupportIntegrationsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async listAll(): Promise<SupportIntegrationRecord[]> {
    return this.db.query<SupportIntegrationRecord>(
      `SELECT
         id,
         provider,
         name,
         is_active,
         telegram_bot_token,
         telegram_chat_id,
         whatsapp_phone_number,
         message_template,
         categories,
         priorities,
         statuses,
         operating_hours,
         metadata,
         created_at,
         updated_at
       FROM support_integrations
       ORDER BY created_at DESC`
    );
  }

  async listActiveMatching(params: {
    category?: string;
    priority?: string;
    status?: string;
  }): Promise<SupportIntegrationRecord[]> {
    return this.db.query<SupportIntegrationRecord>(
      `SELECT
         id,
         provider,
         name,
         is_active,
         telegram_bot_token,
         telegram_chat_id,
         whatsapp_phone_number,
         message_template,
         categories,
         priorities,
         statuses,
         operating_hours,
         metadata,
         created_at,
         updated_at
       FROM support_integrations
       WHERE is_active = TRUE
         AND (
           cardinality(categories) = 0
           OR $1::text IS NULL
           OR $1 = ANY(categories)
         )
         AND (
           cardinality(priorities) = 0
           OR $2::text IS NULL
           OR $2 = ANY(priorities)
         )
         AND (
           cardinality(statuses) = 0
           OR $3::text IS NULL
           OR $3 = ANY(statuses)
         )
       ORDER BY created_at DESC`,
      [params.category ?? null, params.priority ?? null, params.status ?? null]
    );
  }

  async findById(id: string): Promise<SupportIntegrationRecord | null> {
    const rows = await this.db.query<SupportIntegrationRecord>(
      `SELECT
         id,
         provider,
         name,
         is_active,
         telegram_bot_token,
         telegram_chat_id,
         whatsapp_phone_number,
         message_template,
         categories,
         priorities,
         statuses,
         operating_hours,
         metadata,
         created_at,
         updated_at
       FROM support_integrations
       WHERE id = $1
       LIMIT 1`,
      [id]
    );

    return rows[0] ?? null;
  }

  async create(params: {
    provider: SupportIntegrationProvider;
    name: string;
    isActive?: boolean;
    telegramBotToken?: string | null;
    telegramChatId?: string | null;
    whatsappPhoneNumber?: string | null;
    messageTemplate?: string | null;
    categories?: string[];
    priorities?: string[];
    statuses?: string[];
    operatingHours?: unknown;
    metadata?: unknown;
  }): Promise<SupportIntegrationRecord> {
    const id = randomUUID();
    const rows = await this.db.query<SupportIntegrationRecord>(
      `INSERT INTO support_integrations (
         id,
         provider,
         name,
         is_active,
         telegram_bot_token,
         telegram_chat_id,
         whatsapp_phone_number,
         message_template,
         categories,
         priorities,
         statuses,
         operating_hours,
         metadata
       ) VALUES (
         $1,
         $2,
         $3,
         $4,
         $5,
         $6,
         $7,
         $8,
         $9::text[],
         $10::text[],
         $11::text[],
         $12::jsonb,
         $13::jsonb
       )
       RETURNING
         id,
         provider,
         name,
         is_active,
         telegram_bot_token,
         telegram_chat_id,
         whatsapp_phone_number,
         message_template,
         categories,
         priorities,
         statuses,
         operating_hours,
         metadata,
         created_at,
         updated_at`,
      [
        id,
        params.provider,
        params.name,
        params.isActive ?? false,
        params.telegramBotToken ?? null,
        params.telegramChatId ?? null,
        params.whatsappPhoneNumber ?? null,
        params.messageTemplate ?? null,
        params.categories ?? [],
        params.priorities ?? [],
        params.statuses ?? ["open", "in_progress"],
        JSON.stringify(params.operatingHours ?? {}),
        JSON.stringify(params.metadata ?? {})
      ]
    );

    return rows[0];
  }

  async updateById(
    id: string,
    patch: {
      name?: string;
      isActive?: boolean;
      telegramBotToken?: string | null;
      telegramChatId?: string | null;
      whatsappPhoneNumber?: string | null;
      messageTemplate?: string | null;
      categories?: string[];
      priorities?: string[];
      statuses?: string[];
      operatingHours?: unknown;
      metadata?: unknown;
    }
  ): Promise<void> {
    await this.db.query(
      `UPDATE support_integrations
       SET
         name = COALESCE($2, name),
         is_active = COALESCE($3, is_active),
         telegram_bot_token = COALESCE($4, telegram_bot_token),
         telegram_chat_id = COALESCE($5, telegram_chat_id),
         whatsapp_phone_number = COALESCE($6, whatsapp_phone_number),
         message_template = COALESCE($7, message_template),
         categories = COALESCE($8::text[], categories),
         priorities = COALESCE($9::text[], priorities),
         statuses = COALESCE($10::text[], statuses),
         operating_hours = COALESCE($11::jsonb, operating_hours),
         metadata = COALESCE($12::jsonb, metadata),
         updated_at = NOW()
       WHERE id = $1`,
      [
        id,
        patch.name ?? null,
        patch.isActive ?? null,
        patch.telegramBotToken === undefined ? null : patch.telegramBotToken,
        patch.telegramChatId === undefined ? null : patch.telegramChatId,
        patch.whatsappPhoneNumber === undefined ? null : patch.whatsappPhoneNumber,
        patch.messageTemplate === undefined ? null : patch.messageTemplate,
        patch.categories ?? null,
        patch.priorities ?? null,
        patch.statuses ?? null,
        patch.operatingHours === undefined ? null : JSON.stringify(patch.operatingHours),
        patch.metadata === undefined ? null : JSON.stringify(patch.metadata)
      ]
    );
  }
}
