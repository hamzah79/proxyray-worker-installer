import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export interface PaymentChannelRecord {
  id: string;
  code: string;
  name: string;
  provider: string;
  account_name: string;
  account_number: string;
  instructions: string | null;
  is_active: boolean;
  sort_order: number;
  metadata: unknown;
  created_at: string;
  updated_at: string;
}

export class PaymentChannelsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async listActive(): Promise<PaymentChannelRecord[]> {
    return this.db.query<PaymentChannelRecord>(
      `SELECT id, code, name, provider, account_name, account_number, instructions, is_active, sort_order, metadata, created_at, updated_at
       FROM payment_channels
       WHERE is_active = TRUE
       ORDER BY sort_order ASC, created_at DESC`
    );
  }

  async listAll(): Promise<PaymentChannelRecord[]> {
    return this.db.query<PaymentChannelRecord>(
      `SELECT id, code, name, provider, account_name, account_number, instructions, is_active, sort_order, metadata, created_at, updated_at
       FROM payment_channels
       ORDER BY sort_order ASC, created_at DESC`
    );
  }

  async findById(id: string): Promise<PaymentChannelRecord | null> {
    const rows = await this.db.query<PaymentChannelRecord>(
      `SELECT id, code, name, provider, account_name, account_number, instructions, is_active, sort_order, metadata, created_at, updated_at
       FROM payment_channels
       WHERE id = $1
       LIMIT 1`,
      [id]
    );

    return rows[0] ?? null;
  }

  async findByCode(code: string): Promise<PaymentChannelRecord | null> {
    const rows = await this.db.query<PaymentChannelRecord>(
      `SELECT id, code, name, provider, account_name, account_number, instructions, is_active, sort_order, metadata, created_at, updated_at
       FROM payment_channels
       WHERE code = $1
       LIMIT 1`,
      [code]
    );

    return rows[0] ?? null;
  }

  async create(params: {
    code: string;
    name: string;
    provider: string;
    accountName: string;
    accountNumber: string;
    instructions?: string | null;
    isActive?: boolean;
    sortOrder?: number;
    metadata?: unknown;
  }): Promise<PaymentChannelRecord> {
    const id = randomUUID();

    const rows = await this.db.query<PaymentChannelRecord>(
      `INSERT INTO payment_channels (
         id, code, name, provider, account_name, account_number,
         instructions, is_active, sort_order, metadata
       ) VALUES (
         $1, $2, $3, $4, $5, $6,
         $7, $8, $9, $10::jsonb
       )
       RETURNING id, code, name, provider, account_name, account_number, instructions, is_active, sort_order, metadata, created_at, updated_at`,
      [
        id,
        params.code,
        params.name,
        params.provider,
        params.accountName,
        params.accountNumber,
        params.instructions ?? null,
        params.isActive ?? true,
        params.sortOrder ?? 100,
        JSON.stringify(params.metadata ?? {})
      ]
    );

    return rows[0];
  }

  async updateById(
    id: string,
    patch: {
      name?: string;
      provider?: string;
      accountName?: string;
      accountNumber?: string;
      instructions?: string | null;
      isActive?: boolean;
      sortOrder?: number;
      metadata?: unknown;
    }
  ): Promise<void> {
    await this.db.query(
      `UPDATE payment_channels
       SET
         name = COALESCE($2, name),
         provider = COALESCE($3, provider),
         account_name = COALESCE($4, account_name),
         account_number = COALESCE($5, account_number),
         instructions = COALESCE($6, instructions),
         is_active = COALESCE($7, is_active),
         sort_order = COALESCE($8, sort_order),
         metadata = COALESCE($9::jsonb, metadata),
         updated_at = NOW()
       WHERE id = $1`,
      [
        id,
        patch.name ?? null,
        patch.provider ?? null,
        patch.accountName ?? null,
        patch.accountNumber ?? null,
        patch.instructions === undefined ? null : patch.instructions,
        patch.isActive ?? null,
        patch.sortOrder ?? null,
        patch.metadata === undefined ? null : JSON.stringify(patch.metadata)
      ]
    );
  }

  async deleteById(id: string): Promise<void> {
    await this.db.query(`DELETE FROM payment_channels WHERE id = $1`, [id]);
  }

  async ensureDefaults(): Promise<void> {
    const defaults = [
      {
        id: randomUUID(),
        code: "bca_transfer",
        name: "Bank BCA",
        provider: "bank_transfer",
        account_name: "Hamzah",
        account_number: "1390421423",
        instructions: "Gunakan nomor invoice sebagai berita transfer",
        sort_order: 10
      },
      {
        id: randomUUID(),
        code: "dana_wallet",
        name: "DANA",
        provider: "e_wallet",
        account_name: "Hamzah",
        account_number: "085607030852",
        instructions: "Gunakan nomor invoice pada catatan transfer",
        sort_order: 20
      }
    ] as const;

    for (const item of defaults) {
      await this.db.query(
        `INSERT INTO payment_channels (id, code, name, provider, account_name, account_number, instructions, is_active, sort_order)
         VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE, $8)
         ON CONFLICT (code) DO NOTHING`,
        [item.id, item.code, item.name, item.provider, item.account_name, item.account_number, item.instructions, item.sort_order]
      );
    }
  }
}
