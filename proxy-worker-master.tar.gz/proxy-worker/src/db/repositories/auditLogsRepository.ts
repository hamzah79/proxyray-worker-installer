import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export interface AuditLogRecord {
  id: string;
  actor_user_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  before_state: unknown;
  after_state: unknown;
  ip_address: string | null;
  created_at: string;
}

export class AuditLogsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async create(params: {
    actorUserId: string | null;
    action: string;
    entityType: string;
    entityId: string | null;
    beforeState?: unknown;
    afterState?: unknown;
    ipAddress?: string | null;
  }): Promise<void> {
    await this.db.query(
      `INSERT INTO audit_logs (
         id, actor_user_id, action, entity_type, entity_id, before_state, after_state, ip_address
       ) VALUES (
         $1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8
       )`,
      [
        randomUUID(),
        params.actorUserId,
        params.action,
        params.entityType,
        params.entityId,
        JSON.stringify(params.beforeState ?? null),
        JSON.stringify(params.afterState ?? null),
        params.ipAddress ?? null
      ]
    );
  }

  async listRecent(limit: number): Promise<AuditLogRecord[]> {
    return this.db.query<AuditLogRecord>(
      `SELECT id, actor_user_id, action, entity_type, entity_id, before_state, after_state, ip_address, created_at
       FROM audit_logs
       ORDER BY created_at DESC
       LIMIT $1`,
      [limit]
    );
  }
}
