import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export class PaymentEventsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async recordIfNew(params: {
    provider: string;
    eventType: string;
    providerEventId: string;
    invoiceId: string | null;
    subscriptionId: string | null;
    payload: unknown;
  }): Promise<boolean> {
    const id = randomUUID();
    try {
      await this.db.query(
        `INSERT INTO payment_events (
           id, provider, event_type, provider_event_id, invoice_id, subscription_id, payload
         ) VALUES (
           $1, $2, $3, $4, $5, $6, $7::jsonb
         )`,
        [
          id,
          params.provider,
          params.eventType,
          params.providerEventId,
          params.invoiceId,
          params.subscriptionId,
          JSON.stringify(params.payload ?? {})
        ]
      );

      return true;
    } catch (error) {
      if (isUniqueViolation(error)) {
        return false;
      }

      throw error;
    }
  }
}

function isUniqueViolation(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  return "code" in error && (error as { code?: string }).code === "23505";
}
