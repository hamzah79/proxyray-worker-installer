import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type InAppNotificationType = "info" | "success" | "warn" | "error";
export type InAppNotificationAudience = "all" | "user" | "admin";

export interface InAppNotificationRecord {
  id: string;
  title: string;
  message: string;
  type: InAppNotificationType;
  audience: InAppNotificationAudience;
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface InAppNotificationFeedRecord extends InAppNotificationRecord {
  is_read: boolean;
}

export class InAppNotificationsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async listAll(limit = 100): Promise<InAppNotificationRecord[]> {
    return this.db.query<InAppNotificationRecord>(
      `SELECT id, title, message, type, audience, is_active, starts_at, ends_at, created_by, created_at, updated_at
       FROM in_app_notifications
       ORDER BY created_at DESC
       LIMIT $1`,
      [Math.max(1, Math.min(limit, 300))]
    );
  }

  async listFeed(params: {
    readerKey: string;
    audience: InAppNotificationAudience;
    limit?: number;
  }): Promise<InAppNotificationFeedRecord[]> {
    const audiences = params.audience === "admin" ? ["all", "admin"] : ["all", "user"];
    return this.db.query<InAppNotificationFeedRecord>(
      `SELECT
         n.id,
         n.title,
         n.message,
         n.type,
         n.audience,
         n.is_active,
         n.starts_at,
         n.ends_at,
         n.created_by,
         n.created_at,
         n.updated_at,
         (r.notification_id IS NOT NULL) AS is_read
       FROM in_app_notifications n
       LEFT JOIN notification_reads r
         ON r.notification_id = n.id AND r.reader_key = $1
       WHERE n.is_active = TRUE
         AND n.audience = ANY($2::text[])
         AND (n.starts_at IS NULL OR n.starts_at <= NOW())
         AND (n.ends_at IS NULL OR n.ends_at >= NOW())
       ORDER BY n.created_at DESC
       LIMIT $3`,
      [params.readerKey, audiences, Math.max(1, Math.min(params.limit ?? 50, 200))]
    );
  }

  async countUnread(params: { readerKey: string; audience: InAppNotificationAudience }): Promise<number> {
    const audiences = params.audience === "admin" ? ["all", "admin"] : ["all", "user"];
    const rows = await this.db.query<{ unread_count: number }>(
      `SELECT COUNT(*)::int AS unread_count
       FROM in_app_notifications n
       LEFT JOIN notification_reads r
         ON r.notification_id = n.id AND r.reader_key = $1
       WHERE n.is_active = TRUE
         AND n.audience = ANY($2::text[])
         AND (n.starts_at IS NULL OR n.starts_at <= NOW())
         AND (n.ends_at IS NULL OR n.ends_at >= NOW())
         AND r.notification_id IS NULL`,
      [params.readerKey, audiences]
    );

    return rows[0]?.unread_count ?? 0;
  }

  async create(params: {
    title: string;
    message: string;
    type: InAppNotificationType;
    audience: InAppNotificationAudience;
    isActive: boolean;
    startsAt: string | null;
    endsAt: string | null;
    createdBy: string | null;
  }): Promise<InAppNotificationRecord> {
    const id = randomUUID();
    const rows = await this.db.query<InAppNotificationRecord>(
      `INSERT INTO in_app_notifications (
         id, title, message, type, audience, is_active, starts_at, ends_at, created_by
       ) VALUES (
         $1, $2, $3, $4, $5, $6, $7, $8, $9
       )
       RETURNING id, title, message, type, audience, is_active, starts_at, ends_at, created_by, created_at, updated_at`,
      [id, params.title, params.message, params.type, params.audience, params.isActive, params.startsAt, params.endsAt, params.createdBy]
    );

    if (!rows[0]) {
      throw new Error("notification_create_failed");
    }

    return rows[0];
  }

  async updateById(
    id: string,
    params: {
      title: string;
      message: string;
      type: InAppNotificationType;
      audience: InAppNotificationAudience;
      isActive: boolean;
      startsAt: string | null;
      endsAt: string | null;
    }
  ): Promise<InAppNotificationRecord | null> {
    const rows = await this.db.query<InAppNotificationRecord>(
      `UPDATE in_app_notifications
       SET
         title = $2,
         message = $3,
         type = $4,
         audience = $5,
         is_active = $6,
         starts_at = $7,
         ends_at = $8,
         updated_at = NOW()
       WHERE id = $1
       RETURNING id, title, message, type, audience, is_active, starts_at, ends_at, created_by, created_at, updated_at`,
      [id, params.title, params.message, params.type, params.audience, params.isActive, params.startsAt, params.endsAt]
    );

    return rows[0] ?? null;
  }

  async deleteById(id: string): Promise<boolean> {
    const rows = await this.db.query<{ id: string }>(
      `DELETE FROM in_app_notifications
       WHERE id = $1
       RETURNING id`,
      [id]
    );

    return Boolean(rows[0]);
  }

  async findById(id: string): Promise<InAppNotificationRecord | null> {
    const rows = await this.db.query<InAppNotificationRecord>(
      `SELECT id, title, message, type, audience, is_active, starts_at, ends_at, created_by, created_at, updated_at
       FROM in_app_notifications
       WHERE id = $1
       LIMIT 1`,
      [id]
    );

    return rows[0] ?? null;
  }

  async markRead(notificationId: string, readerKey: string): Promise<void> {
    await this.db.query(
      `INSERT INTO notification_reads (notification_id, reader_key)
       VALUES ($1, $2)
       ON CONFLICT (notification_id, reader_key)
       DO UPDATE SET read_at = NOW()`,
      [notificationId, readerKey]
    );
  }

  async markAllRead(params: { readerKey: string; audience: InAppNotificationAudience }): Promise<number> {
    const audiences = params.audience === "admin" ? ["all", "admin"] : ["all", "user"];
    const rows = await this.db.query<{ inserted_count: number }>(
      `WITH inserted AS (
         INSERT INTO notification_reads (notification_id, reader_key)
         SELECT n.id, $1
         FROM in_app_notifications n
         LEFT JOIN notification_reads r
           ON r.notification_id = n.id AND r.reader_key = $1
         WHERE n.is_active = TRUE
           AND n.audience = ANY($2::text[])
           AND (n.starts_at IS NULL OR n.starts_at <= NOW())
           AND (n.ends_at IS NULL OR n.ends_at >= NOW())
           AND r.notification_id IS NULL
         ON CONFLICT (notification_id, reader_key) DO NOTHING
         RETURNING notification_id
       )
       SELECT COUNT(*)::int AS inserted_count FROM inserted`,
      [params.readerKey, audiences]
    );

    return rows[0]?.inserted_count ?? 0;
  }
}
