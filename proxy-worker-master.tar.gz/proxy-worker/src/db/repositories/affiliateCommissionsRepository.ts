import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type AffiliateCommissionStatus = "pending" | "approved" | "paid" | "rejected";

export interface AffiliateCommissionRecord {
  id: string;
  referrer_user_id: string;
  referred_user_id: string;
  invoice_id: string;
  commission_cents: number;
  status: AffiliateCommissionStatus;
  approved_at: string | null;
  paid_at: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export class AffiliateCommissionsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async create(params: {
    referrerUserId: string;
    referredUserId: string;
    invoiceId: string;
    commissionCents: number;
    status?: AffiliateCommissionStatus;
    notes?: string | null;
  }): Promise<AffiliateCommissionRecord> {
    const rows = await this.db.query<AffiliateCommissionRecord>(
      `INSERT INTO affiliate_commissions (
         id, referrer_user_id, referred_user_id, invoice_id,
         commission_cents, status, notes
       ) VALUES (
         $1, $2, $3, $4,
         $5, $6, $7
       )
       RETURNING id, referrer_user_id, referred_user_id, invoice_id,
         commission_cents, status, approved_at, paid_at, notes, created_at, updated_at`,
      [
        randomUUID(),
        params.referrerUserId,
        params.referredUserId,
        params.invoiceId,
        params.commissionCents,
        params.status ?? "pending",
        params.notes ?? null
      ]
    );

    return rows[0];
  }

  async findByInvoiceId(invoiceId: string): Promise<AffiliateCommissionRecord | null> {
    const rows = await this.db.query<AffiliateCommissionRecord>(
      `SELECT id, referrer_user_id, referred_user_id, invoice_id,
         commission_cents, status, approved_at, paid_at, notes, created_at, updated_at
       FROM affiliate_commissions
       WHERE invoice_id = $1
       LIMIT 1`,
      [invoiceId]
    );

    return rows[0] ?? null;
  }

  async findById(id: string): Promise<AffiliateCommissionRecord | null> {
    const rows = await this.db.query<AffiliateCommissionRecord>(
      `SELECT id, referrer_user_id, referred_user_id, invoice_id,
         commission_cents, status, approved_at, paid_at, notes, created_at, updated_at
       FROM affiliate_commissions
       WHERE id = $1
       LIMIT 1`,
      [id]
    );

    return rows[0] ?? null;
  }

  async listAll(limit: number = 200): Promise<AffiliateCommissionRecord[]> {
    return this.db.query<AffiliateCommissionRecord>(
      `SELECT id, referrer_user_id, referred_user_id, invoice_id,
         commission_cents, status, approved_at, paid_at, notes, created_at, updated_at
       FROM affiliate_commissions
       ORDER BY created_at DESC
       LIMIT $1`,
      [limit]
    );
  }

  async listByReferrerUserId(referrerUserId: string, limit: number = 200): Promise<AffiliateCommissionRecord[]> {
    return this.db.query<AffiliateCommissionRecord>(
      `SELECT id, referrer_user_id, referred_user_id, invoice_id,
         commission_cents, status, approved_at, paid_at, notes, created_at, updated_at
       FROM affiliate_commissions
       WHERE referrer_user_id = $1
       ORDER BY created_at DESC
       LIMIT $2`,
      [referrerUserId, limit]
    );
  }

  async updateStatus(id: string, status: AffiliateCommissionStatus, notes?: string | null): Promise<void> {
    await this.db.query(
      `UPDATE affiliate_commissions
       SET
         status = $2,
         approved_at = CASE
           WHEN $2 = 'approved' THEN NOW()
           ELSE approved_at
         END,
         paid_at = CASE
           WHEN $2 = 'paid' THEN NOW()
           ELSE paid_at
         END,
         notes = COALESCE($3, notes),
         updated_at = NOW()
       WHERE id = $1`,
      [id, status, notes ?? null]
    );
  }

  async summarizeByReferrerUserId(referrerUserId: string): Promise<{ pending_cents: number; approved_cents: number; paid_cents: number }> {
    const rows = await this.db.query<{ pending_cents: string; approved_cents: string; paid_cents: string }>(
      `SELECT
         COALESCE(SUM(commission_cents) FILTER (WHERE status = 'pending'), 0)::text AS pending_cents,
         COALESCE(SUM(commission_cents) FILTER (WHERE status = 'approved'), 0)::text AS approved_cents,
         COALESCE(SUM(commission_cents) FILTER (WHERE status = 'paid'), 0)::text AS paid_cents
       FROM affiliate_commissions
       WHERE referrer_user_id = $1`,
      [referrerUserId]
    );

    return {
      pending_cents: Number(rows[0]?.pending_cents ?? 0),
      approved_cents: Number(rows[0]?.approved_cents ?? 0),
      paid_cents: Number(rows[0]?.paid_cents ?? 0)
    };
  }
}
