import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export interface UsagePeriodRecord {
  id: string;
  user_id: string;
  subscription_id: string | null;
  period_start: string;
  period_end: string;
  requests_count: string;
  bytes_in: string;
  bytes_out: string;
  peak_concurrent: number;
  created_at: string;
  updated_at: string;
}

export class UsagePeriodsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async upsertUsageSample(params: {
    userId: string;
    subscriptionId: string | null;
    requestsCountDelta: number;
    bytesInDelta: number;
    bytesOutDelta: number;
    peakConcurrent: number;
  }): Promise<void> {
    const periodStart = startOfMonthUtc();
    const periodEnd = startOfNextMonthUtc();

    const updated = await this.db.query<{ id: string }>(
      `UPDATE usage_periods
       SET
         requests_count = requests_count + $5,
         bytes_in = bytes_in + $6,
         bytes_out = bytes_out + $7,
         peak_concurrent = GREATEST(peak_concurrent, $8),
         updated_at = NOW()
       WHERE user_id = $1
         AND subscription_id IS NOT DISTINCT FROM $2
         AND period_start = $3
         AND period_end = $4
       RETURNING id`,
      [
        params.userId,
        params.subscriptionId,
        periodStart,
        periodEnd,
        Math.max(0, Math.trunc(params.requestsCountDelta)),
        Math.max(0, Math.trunc(params.bytesInDelta)),
        Math.max(0, Math.trunc(params.bytesOutDelta)),
        Math.max(0, Math.trunc(params.peakConcurrent))
      ]
    );

    if (updated.length > 0) {
      return;
    }

    await this.db.query(
      `INSERT INTO usage_periods (
         id, user_id, subscription_id, period_start, period_end,
         requests_count, bytes_in, bytes_out, peak_concurrent
       ) VALUES (
         $1, $2, $3, $4, $5,
         $6, $7, $8, $9
       )`,
      [
        randomUUID(),
        params.userId,
        params.subscriptionId,
        periodStart,
        periodEnd,
        Math.max(0, Math.trunc(params.requestsCountDelta)),
        Math.max(0, Math.trunc(params.bytesInDelta)),
        Math.max(0, Math.trunc(params.bytesOutDelta)),
        Math.max(0, Math.trunc(params.peakConcurrent))
      ]
    );
  }

  async listByUser(userId: string): Promise<UsagePeriodRecord[]> {
    return this.db.query<UsagePeriodRecord>(
      `SELECT id, user_id, subscription_id, period_start, period_end,
         requests_count, bytes_in, bytes_out, peak_concurrent, created_at, updated_at
       FROM usage_periods
       WHERE user_id = $1
       ORDER BY period_start DESC`,
      [userId]
    );
  }
}

function startOfMonthUtc(): string {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1, 0, 0, 0)).toISOString();
}

function startOfNextMonthUtc(): string {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, 0, 0, 0)).toISOString();
}
