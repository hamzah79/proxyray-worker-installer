import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type SupportTicketCategory = "general" | "billing" | "technical" | "account" | "abuse" | "other";
export type SupportTicketPriority = "low" | "medium" | "high" | "urgent";
export type SupportTicketStatus = "open" | "in_progress" | "waiting_customer" | "resolved" | "closed";
export type SupportSenderRole = "user" | "admin" | "system";

export interface SupportTicketRecord {
  id: string;
  user_id: string;
  subject: string;
  category: SupportTicketCategory;
  priority: SupportTicketPriority;
  status: SupportTicketStatus;
  assigned_admin_user_id: string | null;
  last_message_at: string;
  created_at: string;
  updated_at: string;
}

export interface SupportTicketListRecord extends SupportTicketRecord {
  username: string;
  user_email: string | null;
  message_count: number;
}

export interface SupportTicketMessageRecord {
  id: string;
  ticket_id: string;
  sender_user_id: string | null;
  sender_role: SupportSenderRole;
  channel: "app" | "telegram" | "whatsapp" | "system";
  message_text: string;
  is_internal: boolean;
  created_at: string;
  sender_username: string | null;
}

export class SupportTicketsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async createTicket(params: {
    userId: string;
    subject: string;
    category: SupportTicketCategory;
    priority: SupportTicketPriority;
    initialMessage: string;
  }): Promise<SupportTicketRecord> {
    const ticketId = randomUUID();
    const messageId = randomUUID();

    await this.db.withTransaction(async (client) => {
      await client.query(
        `INSERT INTO support_tickets (
           id, user_id, subject, category, priority, status, last_message_at
         ) VALUES (
           $1, $2, $3, $4, $5, 'open', NOW()
         )`,
        [ticketId, params.userId, params.subject, params.category, params.priority]
      );

      await client.query(
        `INSERT INTO support_ticket_messages (
           id, ticket_id, sender_user_id, sender_role, channel, message_text, is_internal
         ) VALUES (
           $1, $2, $3, 'user', 'app', $4, FALSE
         )`,
        [messageId, ticketId, params.userId, params.initialMessage]
      );
    });

    const created = await this.findById(ticketId);
    if (!created) {
      throw new Error("ticket_create_failed");
    }

    return created;
  }

  async findById(ticketId: string): Promise<SupportTicketRecord | null> {
    const rows = await this.db.query<SupportTicketRecord>(
      `SELECT id, user_id, subject, category, priority, status, assigned_admin_user_id, last_message_at, created_at, updated_at
       FROM support_tickets
       WHERE id = $1
       LIMIT 1`,
      [ticketId]
    );

    return rows[0] ?? null;
  }

  async findByIdForUser(ticketId: string, userId: string): Promise<SupportTicketRecord | null> {
    const rows = await this.db.query<SupportTicketRecord>(
      `SELECT id, user_id, subject, category, priority, status, assigned_admin_user_id, last_message_at, created_at, updated_at
       FROM support_tickets
       WHERE id = $1 AND user_id = $2
       LIMIT 1`,
      [ticketId, userId]
    );

    return rows[0] ?? null;
  }

  async listByUser(userId: string, limit = 50, offset = 0): Promise<SupportTicketListRecord[]> {
    return this.db.query<SupportTicketListRecord>(
      `SELECT
         t.id,
         t.user_id,
         t.subject,
         t.category,
         t.priority,
         t.status,
         t.assigned_admin_user_id,
         t.last_message_at,
         t.created_at,
         t.updated_at,
         u.username,
         u.email AS user_email,
         COALESCE(m.message_count, 0) AS message_count
       FROM support_tickets t
       JOIN users u ON u.id = t.user_id
       LEFT JOIN (
         SELECT ticket_id, COUNT(*)::int AS message_count
         FROM support_ticket_messages
         GROUP BY ticket_id
       ) m ON m.ticket_id = t.id
       WHERE t.user_id = $1
       ORDER BY t.updated_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, Math.max(1, Math.min(limit, 200)), Math.max(0, offset)]
    );
  }

  async listForAdmin(filters: {
    status?: SupportTicketStatus;
    priority?: SupportTicketPriority;
    category?: SupportTicketCategory;
    assignedAdminUserId?: string;
    limit?: number;
    offset?: number;
  }): Promise<SupportTicketListRecord[]> {
    return this.db.query<SupportTicketListRecord>(
      `SELECT
         t.id,
         t.user_id,
         t.subject,
         t.category,
         t.priority,
         t.status,
         t.assigned_admin_user_id,
         t.last_message_at,
         t.created_at,
         t.updated_at,
         u.username,
         u.email AS user_email,
         COALESCE(m.message_count, 0) AS message_count
       FROM support_tickets t
       JOIN users u ON u.id = t.user_id
       LEFT JOIN (
         SELECT ticket_id, COUNT(*)::int AS message_count
         FROM support_ticket_messages
         GROUP BY ticket_id
       ) m ON m.ticket_id = t.id
       WHERE ($1::text IS NULL OR t.status = $1)
         AND ($2::text IS NULL OR t.priority = $2)
         AND ($3::text IS NULL OR t.category = $3)
         AND ($4::text IS NULL OR t.assigned_admin_user_id = $4)
       ORDER BY t.updated_at DESC
       LIMIT $5 OFFSET $6`,
      [
        filters.status ?? null,
        filters.priority ?? null,
        filters.category ?? null,
        filters.assignedAdminUserId ?? null,
        Math.max(1, Math.min(filters.limit ?? 100, 300)),
        Math.max(0, filters.offset ?? 0)
      ]
    );
  }

  async addMessage(params: {
    ticketId: string;
    senderUserId: string | null;
    senderRole: SupportSenderRole;
    messageText: string;
    channel?: "app" | "telegram" | "whatsapp" | "system";
    isInternal?: boolean;
  }): Promise<SupportTicketMessageRecord> {
    const id = randomUUID();
    await this.db.withTransaction(async (client) => {
      await client.query(
        `INSERT INTO support_ticket_messages (
           id, ticket_id, sender_user_id, sender_role, channel, message_text, is_internal
         ) VALUES (
           $1, $2, $3, $4, $5, $6, $7
         )`,
        [
          id,
          params.ticketId,
          params.senderUserId,
          params.senderRole,
          params.channel ?? "app",
          params.messageText,
          params.isInternal ?? false
        ]
      );

      await client.query(
        `UPDATE support_tickets
         SET updated_at = NOW(), last_message_at = NOW()
         WHERE id = $1`,
        [params.ticketId]
      );
    });

    const rows = await this.db.query<SupportTicketMessageRecord>(
      `SELECT
         m.id,
         m.ticket_id,
         m.sender_user_id,
         m.sender_role,
         m.channel,
         m.message_text,
         m.is_internal,
         m.created_at,
         u.username AS sender_username
       FROM support_ticket_messages m
       LEFT JOIN users u ON u.id = m.sender_user_id
       WHERE m.id = $1
       LIMIT 1`,
      [id]
    );

    if (!rows[0]) {
      throw new Error("ticket_message_create_failed");
    }

    return rows[0];
  }

  async listMessages(ticketId: string, includeInternal: boolean): Promise<SupportTicketMessageRecord[]> {
    return this.db.query<SupportTicketMessageRecord>(
      `SELECT
         m.id,
         m.ticket_id,
         m.sender_user_id,
         m.sender_role,
         m.channel,
         m.message_text,
         m.is_internal,
         m.created_at,
         u.username AS sender_username
       FROM support_ticket_messages m
       LEFT JOIN users u ON u.id = m.sender_user_id
       WHERE m.ticket_id = $1
         AND ($2::boolean = TRUE OR m.is_internal = FALSE)
       ORDER BY m.created_at ASC`,
      [ticketId, includeInternal]
    );
  }

  async updateTicketById(
    ticketId: string,
    patch: {
      status?: SupportTicketStatus;
      priority?: SupportTicketPriority;
      category?: SupportTicketCategory;
      assignedAdminUserId?: string | null;
    }
  ): Promise<void> {
    const hasAssignedAdminPatch = patch.assignedAdminUserId !== undefined;
    await this.db.query(
      `UPDATE support_tickets
       SET
         status = COALESCE($2, status),
         priority = COALESCE($3, priority),
         category = COALESCE($4, category),
         assigned_admin_user_id = CASE WHEN $6::boolean THEN $5 ELSE assigned_admin_user_id END,
         updated_at = NOW()
       WHERE id = $1`,
      [
        ticketId,
        patch.status ?? null,
        patch.priority ?? null,
        patch.category ?? null,
        patch.assignedAdminUserId ?? null,
        hasAssignedAdminPatch
      ]
    );
  }
}
