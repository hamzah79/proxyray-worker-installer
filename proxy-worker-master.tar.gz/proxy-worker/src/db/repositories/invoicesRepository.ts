import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type InvoiceStatus = "draft" | "pending" | "awaiting_payment" | "paid" | "expired" | "failed" | "refunded" | "void";

export interface InvoiceRecord {
  id: string;
  invoice_number: string;
  user_id: string;
  subscription_id: string | null;
  plan_id: string;
  status: InvoiceStatus;
  amount_cents: number;
  discount_cents: number;
  final_amount_cents: number;
  voucher_code: string | null;
  currency: string;
  due_at: string;
  paid_at: string | null;
  provider: string;
  provider_ref: string | null;
  idempotency_key: string;
  metadata: unknown;
  created_at: string;
  updated_at: string;
}

export class InvoicesRepository {
  constructor(private readonly db: DatabaseClient) {}

  async create(params: {
    userId: string;
    subscriptionId: string;
    planId: string;
    status: InvoiceStatus;
    amountCents: number;
    discountCents?: number;
    finalAmountCents?: number;
    voucherCode?: string | null;
    currency: string;
    dueAtIso: string;
    provider: "paypal" | "bank_transfer" | "pakasir";
    providerRef: string | null;
    idempotencyKey: string;
    metadata: unknown;
  }): Promise<InvoiceRecord> {
    const id = randomUUID();
    const invoiceNumber = buildInvoiceNumber();

    const rows = await this.db.query<InvoiceRecord>(
      `INSERT INTO invoices (
         id, invoice_number, user_id, subscription_id, plan_id,
         status, amount_cents, discount_cents, final_amount_cents, voucher_code,
         currency, due_at, provider, provider_ref,
         idempotency_key, metadata
       ) VALUES (
         $1, $2, $3, $4, $5,
         $6, $7, $8, $9, $10,
         $11, $12, $13, $14,
         $15, $16::jsonb
       )
       RETURNING id, invoice_number, user_id, subscription_id, plan_id,
         status, amount_cents, discount_cents, final_amount_cents, voucher_code,
         currency, due_at, paid_at, provider, provider_ref,
         idempotency_key, metadata, created_at, updated_at`,
      [
        id,
        invoiceNumber,
        params.userId,
        params.subscriptionId,
        params.planId,
        params.status,
        params.amountCents,
        params.discountCents ?? 0,
        params.finalAmountCents ?? params.amountCents,
        params.voucherCode ?? null,
        params.currency,
        params.dueAtIso,
        params.provider,
        params.providerRef,
        params.idempotencyKey,
        JSON.stringify(params.metadata ?? {})
      ]
    );

    return rows[0];
  }

  async findById(invoiceId: string): Promise<InvoiceRecord | null> {
    const rows = await this.db.query<InvoiceRecord>(
      `SELECT id, invoice_number, user_id, subscription_id, plan_id,
        status, amount_cents, discount_cents, final_amount_cents, voucher_code,
        currency, due_at, paid_at, provider, provider_ref,
         idempotency_key, metadata, created_at, updated_at
       FROM invoices
       WHERE id = $1
       LIMIT 1`,
      [invoiceId]
    );

    return rows[0] ?? null;
  }

  async listByUser(userId: string): Promise<InvoiceRecord[]> {
    return this.db.query<InvoiceRecord>(
      `SELECT id, invoice_number, user_id, subscription_id, plan_id,
        status, amount_cents, discount_cents, final_amount_cents, voucher_code,
        currency, due_at, paid_at, provider, provider_ref,
         idempotency_key, metadata, created_at, updated_at
       FROM invoices
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [userId]
    );
  }

  async listAll(): Promise<InvoiceRecord[]> {
    return this.db.query<InvoiceRecord>(
      `SELECT id, invoice_number, user_id, subscription_id, plan_id,
        status, amount_cents, discount_cents, final_amount_cents, voucher_code,
        currency, due_at, paid_at, provider, provider_ref,
         idempotency_key, metadata, created_at, updated_at
       FROM invoices
       ORDER BY created_at DESC`
    );
  }

  async setPaid(invoiceId: string, providerRef: string | null): Promise<void> {
    await this.db.query(
      `UPDATE invoices
       SET status = 'paid', paid_at = NOW(), provider_ref = COALESCE($2, provider_ref), updated_at = NOW()
       WHERE id = $1 AND status <> 'paid'`,
      [invoiceId, providerRef]
    );
  }

  async setStatus(invoiceId: string, status: InvoiceStatus): Promise<void> {
    await this.db.query(
      `UPDATE invoices
       SET status = $2, updated_at = NOW()
       WHERE id = $1`,
      [invoiceId, status]
    );
  }

  async countPaidByUser(userId: string): Promise<number> {
    const rows = await this.db.query<{ count: string }>(
      `SELECT COUNT(*)::text AS count
       FROM invoices
       WHERE user_id = $1 AND status = 'paid'`,
      [userId]
    );

    return Number(rows[0]?.count ?? 0);
  }
}

function buildInvoiceNumber(): string {
  const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 14);
  const suffix = randomUUID().slice(0, 8).toUpperCase();
  return `INV-${timestamp}-${suffix}`;
}
