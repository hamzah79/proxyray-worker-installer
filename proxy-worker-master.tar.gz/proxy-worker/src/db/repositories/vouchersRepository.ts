import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type VoucherDiscountType = "percent" | "fixed";

export interface VoucherRecord {
  id: string;
  code: string;
  name: string;
  discount_type: VoucherDiscountType;
  discount_value: number;
  max_redemptions: number | null;
  max_redemptions_per_user: number;
  starts_at: string | null;
  ends_at: string | null;
  plan_code: string | null;
  is_active: boolean;
  metadata: unknown;
  created_at: string;
  updated_at: string;
}

export class VouchersRepository {
  constructor(private readonly db: DatabaseClient) {}

  async listAll(): Promise<VoucherRecord[]> {
    return this.db.query<VoucherRecord>(
      `SELECT id, code, name, discount_type, discount_value,
         max_redemptions, max_redemptions_per_user,
         starts_at, ends_at, plan_code, is_active, metadata, created_at, updated_at
       FROM vouchers
       ORDER BY created_at DESC`
    );
  }

  async findById(id: string): Promise<VoucherRecord | null> {
    const rows = await this.db.query<VoucherRecord>(
      `SELECT id, code, name, discount_type, discount_value,
         max_redemptions, max_redemptions_per_user,
         starts_at, ends_at, plan_code, is_active, metadata, created_at, updated_at
       FROM vouchers
       WHERE id = $1
       LIMIT 1`,
      [id]
    );

    return rows[0] ?? null;
  }

  async findByCode(code: string): Promise<VoucherRecord | null> {
    const rows = await this.db.query<VoucherRecord>(
      `SELECT id, code, name, discount_type, discount_value,
         max_redemptions, max_redemptions_per_user,
         starts_at, ends_at, plan_code, is_active, metadata, created_at, updated_at
       FROM vouchers
       WHERE code = $1
       LIMIT 1`,
      [code]
    );

    return rows[0] ?? null;
  }

  async create(params: {
    code: string;
    name: string;
    discountType: VoucherDiscountType;
    discountValue: number;
    maxRedemptions?: number | null;
    maxRedemptionsPerUser?: number;
    startsAtIso?: string | null;
    endsAtIso?: string | null;
    planCode?: string | null;
    isActive?: boolean;
    metadata?: unknown;
  }): Promise<VoucherRecord> {
    const rows = await this.db.query<VoucherRecord>(
      `INSERT INTO vouchers (
         id, code, name, discount_type, discount_value,
         max_redemptions, max_redemptions_per_user,
         starts_at, ends_at, plan_code, is_active, metadata
       ) VALUES (
         $1, $2, $3, $4, $5,
         $6, $7,
         $8, $9, $10, $11, $12::jsonb
       )
       RETURNING id, code, name, discount_type, discount_value,
         max_redemptions, max_redemptions_per_user,
         starts_at, ends_at, plan_code, is_active, metadata, created_at, updated_at`,
      [
        randomUUID(),
        params.code,
        params.name,
        params.discountType,
        params.discountValue,
        params.maxRedemptions ?? null,
        params.maxRedemptionsPerUser ?? 1,
        params.startsAtIso ?? null,
        params.endsAtIso ?? null,
        params.planCode ?? null,
        params.isActive ?? true,
        JSON.stringify(params.metadata ?? {})
      ]
    );

    return rows[0];
  }

  async updateById(
    id: string,
    patch: {
      name?: string;
      discountType?: VoucherDiscountType;
      discountValue?: number;
      maxRedemptions?: number | null;
      maxRedemptionsPerUser?: number;
      startsAtIso?: string | null;
      endsAtIso?: string | null;
      planCode?: string | null;
      isActive?: boolean;
      metadata?: unknown;
    }
  ): Promise<void> {
    const hasMaxRedemptions = patch.maxRedemptions !== undefined;
    const hasStartsAt = patch.startsAtIso !== undefined;
    const hasEndsAt = patch.endsAtIso !== undefined;
    const hasPlanCode = patch.planCode !== undefined;

    await this.db.query(
      `UPDATE vouchers
       SET
         name = COALESCE($2, name),
         discount_type = COALESCE($3, discount_type),
         discount_value = COALESCE($4, discount_value),
         max_redemptions = CASE WHEN $12 THEN $5 ELSE max_redemptions END,
         max_redemptions_per_user = COALESCE($6, max_redemptions_per_user),
         starts_at = CASE WHEN $13 THEN $7 ELSE starts_at END,
         ends_at = CASE WHEN $14 THEN $8 ELSE ends_at END,
         plan_code = CASE WHEN $15 THEN $9 ELSE plan_code END,
         is_active = COALESCE($10, is_active),
         metadata = COALESCE($11::jsonb, metadata),
         updated_at = NOW()
       WHERE id = $1`,
      [
        id,
        patch.name ?? null,
        patch.discountType ?? null,
        patch.discountValue ?? null,
        patch.maxRedemptions === undefined ? null : patch.maxRedemptions,
        patch.maxRedemptionsPerUser ?? null,
        patch.startsAtIso === undefined ? null : patch.startsAtIso,
        patch.endsAtIso === undefined ? null : patch.endsAtIso,
        patch.planCode === undefined ? null : patch.planCode,
        patch.isActive ?? null,
        patch.metadata === undefined ? null : JSON.stringify(patch.metadata),
        hasMaxRedemptions,
        hasStartsAt,
        hasEndsAt,
        hasPlanCode
      ]
    );
  }

  async disableById(id: string): Promise<void> {
    await this.db.query(
      `UPDATE vouchers
       SET is_active = FALSE, updated_at = NOW()
       WHERE id = $1`,
      [id]
    );
  }
}
