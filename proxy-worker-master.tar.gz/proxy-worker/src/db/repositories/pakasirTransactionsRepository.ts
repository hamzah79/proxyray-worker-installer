import { DatabaseClient } from "../client";

export interface PakasirTransaction {
  id: number;
  invoice_id: string;
  pakasir_order_id: string;
  payment_method: string;
  amount_cents: number;
  fee_cents: number;
  total_amount_cents: number;
  status: string;
  payment_url: string | null;
  expired_at: Date | null;
  completed_at: Date | null;
  last_checked_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

export class PakasirTransactionsRepository {
  constructor(private db: DatabaseClient) {}

  async create(params: {
    invoiceId: string;
    pakasirOrderId: string;
    paymentMethod: string;
    amountCents: number;
    feeCents: number;
    totalAmountCents: number;
    paymentUrl?: string;
    expiredAt?: Date | null;
  }): Promise<PakasirTransaction> {
    const rows = await this.db.query<Record<string, unknown>>(
      `
      INSERT INTO pakasir_transactions (
        invoice_id, pakasir_order_id, payment_method, amount_cents, fee_cents, 
        total_amount_cents, payment_url, expired_at, status, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())
      RETURNING *
      `,
      [
        params.invoiceId,
        params.pakasirOrderId,
        params.paymentMethod,
        params.amountCents,
        params.feeCents,
        params.totalAmountCents,
        params.paymentUrl || null,
        params.expiredAt || null,
        "pending",
      ]
    );

    return this.rowToTransaction(rows[0]);
  }

  async findByInvoiceId(invoiceId: string): Promise<PakasirTransaction | null> {
    const rows = await this.db.query<Record<string, unknown>>(
      `SELECT * FROM pakasir_transactions WHERE invoice_id = $1`,
      [invoiceId]
    );

    if (rows.length === 0) {
      return null;
    }

    return this.rowToTransaction(rows[0]);
  }

  async findByOrderId(pakasirOrderId: string): Promise<PakasirTransaction | null> {
    const rows = await this.db.query<Record<string, unknown>>(
      `SELECT * FROM pakasir_transactions WHERE pakasir_order_id = $1`,
      [pakasirOrderId]
    );

    if (rows.length === 0) {
      return null;
    }

    return this.rowToTransaction(rows[0]);
  }

  async updateStatus(params: {
    invoiceId: string;
    status: string;
    completedAt?: Date;
  }): Promise<PakasirTransaction> {
    const rows = await this.db.query<Record<string, unknown>>(
      `
      UPDATE pakasir_transactions 
      SET status = $1, completed_at = $2, updated_at = NOW(), last_checked_at = NOW()
      WHERE invoice_id = $3
      RETURNING *
      `,
      [params.status, params.completedAt || null, params.invoiceId]
    );

    if (rows.length === 0) {
      throw new Error(`PakasirTransaction not found for invoice ${params.invoiceId}`);
    }

    return this.rowToTransaction(rows[0]);
  }

  async updateLastChecked(invoiceId: string): Promise<void> {
    await this.db.query(
      `UPDATE pakasir_transactions SET last_checked_at = NOW(), updated_at = NOW() WHERE invoice_id = $1`,
      [invoiceId]
    );
  }

  async listPending(limit: number = 50): Promise<PakasirTransaction[]> {
    const rows = await this.db.query<Record<string, unknown>>(
      `
      SELECT * FROM pakasir_transactions 
      WHERE status = 'pending' AND (last_checked_at IS NULL OR last_checked_at < NOW() - INTERVAL '5 minutes')
      ORDER BY updated_at ASC
      LIMIT $1
      `,
      [limit]
    );

    return rows.map((row) => this.rowToTransaction(row));
  }

  async listByStatus(status: string, limit: number = 100): Promise<PakasirTransaction[]> {
    const rows = await this.db.query<Record<string, unknown>>(
      `
      SELECT * FROM pakasir_transactions 
      WHERE status = $1
      ORDER BY created_at DESC
      LIMIT $2
      `,
      [status, limit]
    );

    return rows.map((row) => this.rowToTransaction(row));
  }

  private rowToTransaction(row: Record<string, unknown>): PakasirTransaction {
    return {
      id: Number(row.id),
      invoice_id: String(row.invoice_id),
      pakasir_order_id: String(row.pakasir_order_id),
      payment_method: String(row.payment_method),
      amount_cents: Number(row.amount_cents),
      fee_cents: Number(row.fee_cents),
      total_amount_cents: Number(row.total_amount_cents),
      status: String(row.status),
      payment_url: row.payment_url ? String(row.payment_url) : null,
      expired_at: row.expired_at ? new Date(String(row.expired_at)) : null,
      completed_at: row.completed_at ? new Date(String(row.completed_at)) : null,
      last_checked_at: row.last_checked_at ? new Date(String(row.last_checked_at)) : null,
      created_at: new Date(String(row.created_at)),
      updated_at: new Date(String(row.updated_at)),
    };
  }
}
