import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export interface VoucherRedemptionRecord {
  id: string;
  voucher_id: string;
  user_id: string;
  invoice_id: string | null;
  discount_cents: number;
  created_at: string;
}

export class VoucherRedemptionsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async create(params: {
    voucherId: string;
    userId: string;
    invoiceId: string | null;
    discountCents: number;
  }): Promise<VoucherRedemptionRecord> {
    const rows = await this.db.query<VoucherRedemptionRecord>(
      `INSERT INTO voucher_redemptions (
         id, voucher_id, user_id, invoice_id, discount_cents
       ) VALUES (
         $1, $2, $3, $4, $5
       )
       RETURNING id, voucher_id, user_id, invoice_id, discount_cents, created_at`,
      [randomUUID(), params.voucherId, params.userId, params.invoiceId, params.discountCents]
    );

    return rows[0];
  }

  async countByVoucherId(voucherId: string): Promise<number> {
    const rows = await this.db.query<{ count: string }>(
      `SELECT COUNT(*)::text AS count
       FROM voucher_redemptions
       WHERE voucher_id = $1`,
      [voucherId]
    );

    return Number(rows[0]?.count ?? 0);
  }

  async countByVoucherIdAndUserId(voucherId: string, userId: string): Promise<number> {
    const rows = await this.db.query<{ count: string }>(
      `SELECT COUNT(*)::text AS count
       FROM voucher_redemptions
       WHERE voucher_id = $1 AND user_id = $2`,
      [voucherId, userId]
    );

    return Number(rows[0]?.count ?? 0);
  }

  async findByInvoiceId(invoiceId: string): Promise<VoucherRedemptionRecord | null> {
    const rows = await this.db.query<VoucherRedemptionRecord>(
      `SELECT id, voucher_id, user_id, invoice_id, discount_cents, created_at
       FROM voucher_redemptions
       WHERE invoice_id = $1
       LIMIT 1`,
      [invoiceId]
    );

    return rows[0] ?? null;
  }
}
