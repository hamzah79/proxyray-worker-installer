import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export interface PlanRecord {
  id: string;
  code: string;
  name: string;
  billing_period: "weekly" | "monthly" | "yearly";
  price_cents: number;
  currency: string;
  concurrent_limit: number;
  bandwidth_limit_bytes: string | null;
  description: string | null;
  is_public: boolean;
  sort_order: number;
  trial_days: number;
  whitelist_ip_limit: number;
  is_active: boolean;
}

export class PlansRepository {
  constructor(private readonly db: DatabaseClient) {}

  async findById(id: string): Promise<PlanRecord | null> {
    const rows = await this.db.query<PlanRecord>(
      `SELECT id, code, name, billing_period, price_cents, currency, concurrent_limit, bandwidth_limit_bytes, description,
        is_public, sort_order, trial_days, whitelist_ip_limit, is_active
       FROM plans
       WHERE id = $1
       LIMIT 1`,
      [id]
    );

    return rows[0] ?? null;
  }

  async findByCode(code: string): Promise<PlanRecord | null> {
    const rows = await this.db.query<PlanRecord>(
      `SELECT id, code, name, billing_period, price_cents, currency, concurrent_limit, bandwidth_limit_bytes, description,
        is_public, sort_order, trial_days, whitelist_ip_limit, is_active
       FROM plans
       WHERE code = $1
       LIMIT 1`,
      [code]
    );

    return rows[0] ?? null;
  }

  async listActive(): Promise<PlanRecord[]> {
    return this.db.query<PlanRecord>(
      `SELECT id, code, name, billing_period, price_cents, currency, concurrent_limit, bandwidth_limit_bytes, description,
        is_public, sort_order, trial_days, whitelist_ip_limit, is_active
       FROM plans
       WHERE is_active = TRUE
       ORDER BY sort_order ASC, price_cents ASC`
    );
  }

  async listAll(): Promise<PlanRecord[]> {
    return this.db.query<PlanRecord>(
      `SELECT id, code, name, billing_period, price_cents, currency, concurrent_limit, bandwidth_limit_bytes, description,
        is_public, sort_order, trial_days, whitelist_ip_limit, is_active
       FROM plans
       ORDER BY created_at DESC`
    );
  }

  async create(params: {
    code: string;
    name: string;
    billingPeriod: "weekly" | "monthly" | "yearly";
    priceCents: number;
    currency: string;
    concurrentLimit: number;
    bandwidthLimitBytes: number | null;
    description: string | null;
    isPublic?: boolean;
    sortOrder?: number;
    trialDays?: number;
    whitelistIpLimit?: number;
    isActive: boolean;
  }): Promise<PlanRecord> {
    const id = randomUUID();
    const rows = await this.db.query<PlanRecord>(
      `INSERT INTO plans (
         id, code, name, billing_period, price_cents, currency,
         concurrent_limit, bandwidth_limit_bytes, description, is_public, sort_order, trial_days, whitelist_ip_limit, is_active
       ) VALUES (
         $1, $2, $3, $4, $5, $6,
         $7, $8, $9, $10, $11, $12, $13, $14
       )
       RETURNING id, code, name, billing_period, price_cents, currency, concurrent_limit, bandwidth_limit_bytes, description,
         is_public, sort_order, trial_days, whitelist_ip_limit, is_active`,
      [
        id,
        params.code,
        params.name,
        params.billingPeriod,
        params.priceCents,
        params.currency,
        params.concurrentLimit,
        params.bandwidthLimitBytes,
        params.description,
        params.isPublic ?? true,
        params.sortOrder ?? 100,
        params.trialDays ?? 0,
        params.whitelistIpLimit ?? 0,
        params.isActive
      ]
    );

    return rows[0];
  }

  async updateById(
    id: string,
    patch: {
      name?: string;
      priceCents?: number;
      concurrentLimit?: number;
      bandwidthLimitBytes?: number | null;
      description?: string | null;
      isPublic?: boolean;
      sortOrder?: number;
      trialDays?: number;
      whitelistIpLimit?: number;
      isActive?: boolean;
    }
  ): Promise<void> {
    await this.db.query(
      `UPDATE plans
       SET
         name = COALESCE($2, name),
         price_cents = COALESCE($3, price_cents),
         concurrent_limit = COALESCE($4, concurrent_limit),
         bandwidth_limit_bytes = COALESCE($5, bandwidth_limit_bytes),
         description = COALESCE($6, description),
         is_public = COALESCE($7, is_public),
         sort_order = COALESCE($8, sort_order),
         trial_days = COALESCE($9, trial_days),
         whitelist_ip_limit = COALESCE($10, whitelist_ip_limit),
         is_active = COALESCE($11, is_active),
         updated_at = NOW()
       WHERE id = $1`,
      [
        id,
        patch.name ?? null,
        patch.priceCents ?? null,
        patch.concurrentLimit ?? null,
        patch.bandwidthLimitBytes === undefined ? null : patch.bandwidthLimitBytes,
        patch.description === undefined ? null : patch.description,
        patch.isPublic ?? null,
        patch.sortOrder ?? null,
        patch.trialDays ?? null,
        patch.whitelistIpLimit ?? null,
        patch.isActive ?? null
      ]
    );
  }

  async deleteById(id: string): Promise<void> {
    await this.db.query("DELETE FROM plans WHERE id = $1", [id]);
  }

  async countReferences(id: string): Promise<number> {
    const subscriptionRows = await this.db.query<{ count: string }>(
      `SELECT COUNT(*)::TEXT AS count FROM subscriptions WHERE plan_id = $1`,
      [id]
    );
    const invoiceRows = await this.db.query<{ count: string }>(
      `SELECT COUNT(*)::TEXT AS count FROM invoices WHERE plan_id = $1`,
      [id]
    );

    return Number(subscriptionRows[0]?.count ?? "0") + Number(invoiceRows[0]?.count ?? "0");
  }

  async ensureDefaults(): Promise<void> {
    const defaults = [
      {
        id: randomUUID(),
        code: "basic_weekly",
        name: "Basic Weekly",
        billing_period: "weekly",
        price_cents: 40000,
        currency: "IDR",
        concurrent_limit: 100,
        bandwidth_limit_bytes: null,
        description: "Weekly proxy subscription"
      },
      {
        id: randomUUID(),
        code: "basic_monthly",
        name: "Basic Monthly",
        billing_period: "monthly",
        price_cents: 120000,
        currency: "IDR",
        concurrent_limit: 100,
        bandwidth_limit_bytes: null,
        description: "Monthly proxy subscription"
      },
      {
        id: randomUUID(),
        code: "basic_yearly",
        name: "Basic Yearly",
        billing_period: "yearly",
        price_cents: 1200000,
        currency: "IDR",
        concurrent_limit: 100,
        bandwidth_limit_bytes: null,
        description: "Yearly proxy subscription"
      }
    ] as const;

    for (const item of defaults) {
      await this.db.query(
        `INSERT INTO plans (id, code, name, billing_period, price_cents, currency, concurrent_limit, bandwidth_limit_bytes, description, is_active)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, TRUE)
         ON CONFLICT (code) DO NOTHING`,
        [
          item.id,
          item.code,
          item.name,
          item.billing_period,
          item.price_cents,
          item.currency,
          item.concurrent_limit,
          item.bandwidth_limit_bytes,
          item.description
        ]
      );
    }
  }
}
