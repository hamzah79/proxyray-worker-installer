import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export interface UserRecord {
  id: string;
  username: string;
  email: string | null;
  email_verified: boolean;
  email_verified_at: string | null;
  email_verification_token_hash: string | null;
  email_verification_expires_at: string | null;
  bank_name: string | null;
  bank_account_name: string | null;
  bank_account_number: string | null;
  profile_address: string | null;
  password_hash: string;
  role: "admin" | "user";
  status: "active" | "suspended" | "disabled";
  referral_code: string | null;
  referred_by_user_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProxyAccessProfile {
  user_id: string;
  username: string;
  user_status: "active" | "suspended" | "disabled";
  subscription_id: string | null;
  subscription_status: "pending" | "active" | "past_due" | "grace" | "expired" | "canceled" | "trial" | null;
  ends_at: string | null;
  grace_until: string | null;
  concurrent_limit: number | null;
  plan_whitelist_ip_limit: number | null;
}

export class UsersRepository {
  constructor(private readonly db: DatabaseClient) {}

  async findById(userId: string): Promise<UserRecord | null> {
    const rows = await this.db.query<UserRecord>(
      `SELECT id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at
       FROM users
       WHERE id = $1
       LIMIT 1`,
      [userId]
    );

    return rows[0] ?? null;
  }

  async findProxyAccessProfile(username: string): Promise<ProxyAccessProfile | null> {
    const rows = await this.db.query<ProxyAccessProfile>(
      `SELECT
         u.id AS user_id,
         u.username,
         u.status AS user_status,
         s.id AS subscription_id,
         s.status AS subscription_status,
         s.ends_at,
         s.grace_until,
         p.concurrent_limit,
         p.whitelist_ip_limit AS plan_whitelist_ip_limit
       FROM users u
       LEFT JOIN LATERAL (
         SELECT id, plan_id, status, ends_at, grace_until
         FROM subscriptions
         WHERE user_id = u.id
         ORDER BY ends_at DESC
         LIMIT 1
       ) s ON TRUE
       LEFT JOIN plans p ON p.id = s.plan_id
       WHERE u.username = $1
       LIMIT 1`,
      [username]
    );

    return rows[0] ?? null;
  }

  async findByUsername(username: string): Promise<UserRecord | null> {
    const rows = await this.db.query<UserRecord>(
      `SELECT id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at
       FROM users
       WHERE username = $1
       LIMIT 1`,
      [username]
    );

    return rows[0] ?? null;
  }

  async findByReferralCode(referralCode: string): Promise<UserRecord | null> {
    const rows = await this.db.query<UserRecord>(
      `SELECT id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at
       FROM users
       WHERE referral_code = $1
       LIMIT 1`,
      [referralCode]
    );

    return rows[0] ?? null;
  }

  async findByEmail(email: string): Promise<UserRecord | null> {
    const rows = await this.db.query<UserRecord>(
      `SELECT id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at
       FROM users
       WHERE LOWER(email) = LOWER($1)
       LIMIT 1`,
      [email]
    );

    return rows[0] ?? null;
  }

  async findByEmailVerificationTokenHash(tokenHash: string): Promise<UserRecord | null> {
    const rows = await this.db.query<UserRecord>(
      `SELECT id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at
       FROM users
       WHERE email_verification_token_hash = $1
       LIMIT 1`,
      [tokenHash]
    );

    return rows[0] ?? null;
  }

  async listAll(): Promise<UserRecord[]> {
    const rows = await this.db.query<UserRecord>(
      `SELECT id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at
       FROM users
       ORDER BY created_at DESC`
    );

    return rows;
  }

  async create(params: {
    username: string;
    email: string | null;
    passwordHash: string;
    emailVerified?: boolean;
    emailVerificationTokenHash?: string | null;
    emailVerificationExpiresAt?: string | null;
    referralCode?: string | null;
    referredByUserId?: string | null;
  }): Promise<UserRecord> {
    const id = randomUUID();
    const rows = await this.db.query<UserRecord>(
      `INSERT INTO users (
         id, username, email,
         email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at,
         bank_name, bank_account_name, bank_account_number, profile_address,
         password_hash, role, status, referral_code, referred_by_user_id
       )
       VALUES (
         $1, $2, $3,
         $4, CASE WHEN $4 THEN NOW() ELSE NULL END, $5, $6,
         NULL, NULL, NULL, NULL,
         $7, 'user', 'active', $8, $9
       )
      RETURNING id, username, email, email_verified, email_verified_at, email_verification_token_hash, email_verification_expires_at, bank_name, bank_account_name, bank_account_number, profile_address, password_hash, role, status, referral_code, referred_by_user_id, created_at, updated_at`,
      [
        id,
        params.username,
        params.email,
        Boolean(params.emailVerified),
        params.emailVerificationTokenHash ?? null,
        params.emailVerificationExpiresAt ?? null,
        params.passwordHash,
        params.referralCode ?? null,
        params.referredByUserId ?? null
      ]
    );

    return rows[0];
  }

  async setReferralCode(userId: string, referralCode: string): Promise<void> {
    await this.db.query(
      `UPDATE users
       SET referral_code = $2, updated_at = NOW()
       WHERE id = $1`,
      [userId, referralCode]
    );
  }

  async updateProfile(userId: string, patch: {
    email?: string | null;
    bankName?: string | null;
    bankAccountName?: string | null;
    bankAccountNumber?: string | null;
    profileAddress?: string | null;
  }): Promise<void> {
    await this.db.query(
      `UPDATE users
       SET
         email = COALESCE($2, email),
         bank_name = COALESCE($3, bank_name),
         bank_account_name = COALESCE($4, bank_account_name),
         bank_account_number = COALESCE($5, bank_account_number),
         profile_address = COALESCE($6, profile_address),
         updated_at = NOW()
       WHERE id = $1`,
      [
        userId,
        patch.email === undefined ? null : patch.email,
        patch.bankName === undefined ? null : patch.bankName,
        patch.bankAccountName === undefined ? null : patch.bankAccountName,
        patch.bankAccountNumber === undefined ? null : patch.bankAccountNumber,
        patch.profileAddress === undefined ? null : patch.profileAddress
      ]
    );
  }

  async updateLastLogin(userId: string): Promise<void> {
    await this.db.query(`UPDATE users SET last_login_at = NOW(), updated_at = NOW() WHERE id = $1`, [userId]);
  }

  async updatePassword(userId: string, passwordHash: string): Promise<void> {
    await this.db.query(
      `UPDATE users
       SET password_hash = $2, updated_at = NOW()
       WHERE id = $1`,
      [userId, passwordHash]
    );
  }

  async setEmailVerification(userId: string, tokenHash: string, expiresAtIso: string): Promise<void> {
    await this.db.query(
      `UPDATE users
       SET email_verification_token_hash = $2,
           email_verification_expires_at = $3,
           updated_at = NOW()
       WHERE id = $1`,
      [userId, tokenHash, expiresAtIso]
    );
  }

  async markEmailVerified(userId: string): Promise<void> {
    await this.db.query(
      `UPDATE users
       SET email_verified = TRUE,
           email_verified_at = NOW(),
           email_verification_token_hash = NULL,
           email_verification_expires_at = NULL,
           updated_at = NOW()
       WHERE id = $1`,
      [userId]
    );
  }

  async setStatus(userId: string, status: "active" | "suspended" | "disabled"): Promise<void> {
    await this.db.query(
      `UPDATE users
       SET status = $2, updated_at = NOW()
       WHERE id = $1`,
      [userId, status]
    );
  }

  async deleteById(userId: string): Promise<void> {
    await this.db.query(`DELETE FROM users WHERE id = $1`, [userId]);
  }
}
