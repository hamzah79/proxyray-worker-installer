import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../client";

export type SubscriptionStatus = "pending" | "active" | "past_due" | "grace" | "expired" | "canceled" | "trial";

export interface SubscriptionRecord {
  id: string;
  user_id: string;
  plan_id: string;
  status: SubscriptionStatus;
  starts_at: string;
  ends_at: string;
  grace_until: string | null;
  auto_renew: boolean;
  external_ref: string | null;
}

export class SubscriptionsRepository {
  constructor(private readonly db: DatabaseClient) {}

  async createTrial(params: {
    userId: string;
    planId: string;
    startsAtIso: string;
    endsAtIso: string;
    externalRef?: string | null;
  }): Promise<SubscriptionRecord> {
    const id = randomUUID();
    const rows = await this.db.query<SubscriptionRecord>(
      `INSERT INTO subscriptions (id, user_id, plan_id, status, starts_at, ends_at, auto_renew, external_ref)
       VALUES ($1, $2, $3, 'trial', $4, $5, FALSE, $6)
       RETURNING id, user_id, plan_id, status, starts_at, ends_at, grace_until, auto_renew, external_ref`,
      [id, params.userId, params.planId, params.startsAtIso, params.endsAtIso, params.externalRef ?? "trial"]
    );

    return rows[0];
  }

  async createPending(params: {
    userId: string;
    planId: string;
    startsAtIso: string;
    endsAtIso: string;
  }): Promise<SubscriptionRecord> {
    const id = randomUUID();
    const rows = await this.db.query<SubscriptionRecord>(
      `INSERT INTO subscriptions (id, user_id, plan_id, status, starts_at, ends_at, auto_renew)
       VALUES ($1, $2, $3, 'pending', $4, $5, TRUE)
       RETURNING id, user_id, plan_id, status, starts_at, ends_at, grace_until, auto_renew, external_ref`,
      [id, params.userId, params.planId, params.startsAtIso, params.endsAtIso]
    );

    return rows[0];
  }

  async findById(subscriptionId: string): Promise<SubscriptionRecord | null> {
    const rows = await this.db.query<SubscriptionRecord>(
      `SELECT id, user_id, plan_id, status, starts_at, ends_at, grace_until, auto_renew, external_ref
       FROM subscriptions
       WHERE id = $1
       LIMIT 1`,
      [subscriptionId]
    );

    return rows[0] ?? null;
  }

  async findLatestByUserId(userId: string): Promise<SubscriptionRecord | null> {
    const rows = await this.db.query<SubscriptionRecord>(
      `SELECT id, user_id, plan_id, status, starts_at, ends_at, grace_until, auto_renew, external_ref
       FROM subscriptions
       WHERE user_id = $1
       ORDER BY ends_at DESC
       LIMIT 1`,
      [userId]
    );

    return rows[0] ?? null;
  }

  async findActiveTrialByUserId(userId: string): Promise<SubscriptionRecord | null> {
    const rows = await this.db.query<SubscriptionRecord>(
      `SELECT id, user_id, plan_id, status, starts_at, ends_at, grace_until, auto_renew, external_ref
       FROM subscriptions
       WHERE user_id = $1
         AND status = 'trial'
         AND ends_at >= NOW()
       ORDER BY ends_at DESC
       LIMIT 1`,
      [userId]
    );

    return rows[0] ?? null;
  }

  async hasTrialHistory(userId: string): Promise<boolean> {
    const rows = await this.db.query<{ has_trial: boolean }>(
      `SELECT EXISTS (
         SELECT 1
         FROM subscriptions
         WHERE user_id = $1
           AND (status = 'trial' OR external_ref = 'trial')
       ) AS has_trial`,
      [userId]
    );

    return Boolean(rows[0]?.has_trial);
  }

  async expireDueTrials(nowIso: string): Promise<number> {
    const rows = await this.db.query<{ count: string }>(
      `WITH updated AS (
         UPDATE subscriptions
         SET status = 'expired', updated_at = NOW()
         WHERE status = 'trial' AND ends_at < $1
         RETURNING id
       )
       SELECT COUNT(*)::text AS count FROM updated`,
      [nowIso]
    );

    return Number(rows[0]?.count ?? 0);
  }

  async listAll(): Promise<SubscriptionRecord[]> {
    return this.db.query<SubscriptionRecord>(
      `SELECT id, user_id, plan_id, status, starts_at, ends_at, grace_until, auto_renew, external_ref
       FROM subscriptions
       ORDER BY created_at DESC`
    );
  }

  async setStatus(subscriptionId: string, status: SubscriptionStatus): Promise<void> {
    await this.db.query(
      `UPDATE subscriptions
       SET status = $2, updated_at = NOW()
       WHERE id = $1`,
      [subscriptionId, status]
    );
  }

  async activate(subscriptionId: string): Promise<void> {
    await this.setStatus(subscriptionId, "active");
  }
}
