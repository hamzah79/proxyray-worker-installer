import fs from "node:fs/promises";
import path from "node:path";

import { Pool, PoolClient, QueryResultRow } from "pg";

export class DatabaseClient {
  private readonly pool: Pool;
  public readonly readOnly: boolean;

  constructor(connectionString: string, options?: { readOnly?: boolean }) {
    this.readOnly = options?.readOnly ?? false;
    this.pool = new Pool({ connectionString });
  }

  async query<T extends QueryResultRow = QueryResultRow>(text: string, values?: unknown[]): Promise<T[]> {
    if (this.readOnly) {
      const upper = text.trimStart().toUpperCase();
      if (upper.startsWith("INSERT") || upper.startsWith("UPDATE") || upper.startsWith("DELETE") || upper.startsWith("CREATE") || upper.startsWith("ALTER") || upper.startsWith("DROP")) {
        throw new Error("database_read_only: write operation blocked in worker mode");
      }
    }
    const result = await this.pool.query<T>(text, values);
    return result.rows;
  }

  async withTransaction<T>(callback: (client: PoolClient) => Promise<T>): Promise<T> {
    if (this.readOnly) {
      throw new Error("database_read_only: transactions blocked in worker mode");
    }
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const result = await callback(client);
      await client.query("COMMIT");
      return result;
    } catch (error) {
      try {
        await client.query("ROLLBACK");
      } catch {
        // ignore rollback errors
      }
      throw error;
    } finally {
      client.release();
    }
  }

  async close(): Promise<void> {
    await this.pool.end();
  }
}

async function ensureMigrationTrackingTable(db: DatabaseClient): Promise<void> {
  await db.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      filename TEXT PRIMARY KEY,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
}

export async function runSqlMigrationFile(db: DatabaseClient, relativeFilePath: string): Promise<void> {
  const absolutePath = path.resolve(process.cwd(), relativeFilePath);
  const sql = await fs.readFile(absolutePath, "utf8");
  await db.withTransaction(async (client) => {
    await client.query(sql);
  });
}

export async function runPendingSqlMigrations(db: DatabaseClient, relativeFilePaths: string[]): Promise<void> {
  await ensureMigrationTrackingTable(db);

  const appliedRows = await db.query<{ filename: string }>("SELECT filename FROM schema_migrations ORDER BY filename ASC");
  const applied = new Set(appliedRows.map((row) => row.filename));

  for (const relativeFilePath of relativeFilePaths) {
    if (applied.has(relativeFilePath)) {
      continue;
    }

    await db.withTransaction(async (client) => {
      const absolutePath = path.resolve(process.cwd(), relativeFilePath);
      const sql = await fs.readFile(absolutePath, "utf8");
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (filename) VALUES ($1)", [relativeFilePath]);
    });
  }
}
