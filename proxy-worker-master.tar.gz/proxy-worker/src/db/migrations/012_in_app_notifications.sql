CREATE TABLE IF NOT EXISTS in_app_notifications (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info' CHECK (type IN ('info', 'success', 'warn', 'error')),
  audience TEXT NOT NULL DEFAULT 'all' CHECK (audience IN ('all', 'user', 'admin')),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notification_reads (
  notification_id TEXT NOT NULL REFERENCES in_app_notifications(id) ON DELETE CASCADE,
  reader_key TEXT NOT NULL,
  read_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (notification_id, reader_key)
);

CREATE INDEX IF NOT EXISTS idx_in_app_notifications_active_window
  ON in_app_notifications (is_active, starts_at, ends_at, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_notification_reads_reader_key
  ON notification_reads (reader_key, read_at DESC);