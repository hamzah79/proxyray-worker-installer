-- Usage tracking for billing and analytics
CREATE TABLE IF NOT EXISTS usage_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  username TEXT NOT NULL,
  timestamp TIMESTAMPTZ NOT NULL,
  request_count INTEGER NOT NULL DEFAULT 1,
  upload_bytes BIGINT NOT NULL DEFAULT 0,
  download_bytes BIGINT NOT NULL DEFAULT 0,
  total_bytes BIGINT NOT NULL DEFAULT 0,
  exit_country TEXT NOT NULL DEFAULT 'UNKNOWN',
  backend_id TEXT NOT NULL DEFAULT 'unknown',
  success BOOLEAN NOT NULL DEFAULT true,
  latency_ms INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast user queries
CREATE INDEX IF NOT EXISTS idx_usage_logs_user_timestamp ON usage_logs(user_id, timestamp DESC);

-- Index for analytics queries
CREATE INDEX IF NOT EXISTS idx_usage_logs_timestamp ON usage_logs(timestamp DESC);

-- Index for country-based queries
CREATE INDEX IF NOT EXISTS idx_usage_logs_country ON usage_logs(exit_country);

-- Unique constraint to prevent duplicate aggregated records
CREATE UNIQUE INDEX IF NOT EXISTS idx_usage_logs_unique ON usage_logs(user_id, timestamp);

-- Partition by month for better performance (optional, for high-volume)
-- This can be enabled later if needed
