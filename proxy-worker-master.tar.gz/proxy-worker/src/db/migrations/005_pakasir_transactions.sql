-- Migration: Add Pakasir payment gateway integration
-- Tracks Pakasir transactions and provides audit trail

CREATE TABLE IF NOT EXISTS pakasir_transactions (
  id SERIAL PRIMARY KEY,
  invoice_id TEXT NOT NULL UNIQUE REFERENCES invoices(id) ON DELETE CASCADE,
  pakasir_order_id VARCHAR(255) NOT NULL UNIQUE,
  payment_method VARCHAR(50) NOT NULL,
  amount_cents BIGINT NOT NULL,
  fee_cents BIGINT NOT NULL,
  total_amount_cents BIGINT NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  payment_url TEXT,
  expired_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  last_checked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pakasir_invoices_order_id 
  ON pakasir_transactions(pakasir_order_id);

CREATE INDEX IF NOT EXISTS idx_pakasir_transactions_status 
  ON pakasir_transactions(status);

CREATE INDEX IF NOT EXISTS idx_pakasir_transactions_invoice_id 
  ON pakasir_transactions(invoice_id);

CREATE INDEX IF NOT EXISTS idx_pakasir_transactions_updated_at 
  ON pakasir_transactions(updated_at);
