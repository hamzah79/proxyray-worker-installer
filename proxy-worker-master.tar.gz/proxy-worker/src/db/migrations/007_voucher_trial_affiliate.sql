ALTER TABLE plans
  ADD COLUMN IF NOT EXISTS is_public BOOLEAN NOT NULL DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS sort_order INTEGER NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS trial_days INTEGER NOT NULL DEFAULT 0;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE,
  ADD COLUMN IF NOT EXISTS referred_by_user_id TEXT REFERENCES users(id) ON DELETE SET NULL;

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS discount_cents INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS voucher_code TEXT;

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS final_amount_cents INTEGER;

UPDATE invoices
SET final_amount_cents = GREATEST(0, amount_cents - discount_cents)
WHERE final_amount_cents IS NULL;

ALTER TABLE invoices
  ALTER COLUMN final_amount_cents SET NOT NULL;

CREATE TABLE IF NOT EXISTS vouchers (
  id TEXT PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percent', 'fixed')),
  discount_value INTEGER NOT NULL CHECK (discount_value >= 0),
  max_redemptions INTEGER CHECK (max_redemptions IS NULL OR max_redemptions >= 1),
  max_redemptions_per_user INTEGER NOT NULL DEFAULT 1 CHECK (max_redemptions_per_user >= 1),
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  plan_code TEXT REFERENCES plans(code) ON DELETE SET NULL ON UPDATE CASCADE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (ends_at IS NULL OR starts_at IS NULL OR ends_at >= starts_at)
);

CREATE TABLE IF NOT EXISTS voucher_redemptions (
  id TEXT PRIMARY KEY,
  voucher_id TEXT NOT NULL REFERENCES vouchers(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invoice_id TEXT REFERENCES invoices(id) ON DELETE SET NULL,
  discount_cents INTEGER NOT NULL CHECK (discount_cents >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS affiliate_commissions (
  id TEXT PRIMARY KEY,
  referrer_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  commission_cents INTEGER NOT NULL CHECK (commission_cents >= 0),
  status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'paid', 'rejected')),
  approved_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (referrer_user_id <> referred_user_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_referral_code_unique
  ON users(referral_code)
  WHERE referral_code IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_plans_public_sort
  ON plans(is_public, sort_order, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_vouchers_code_active
  ON vouchers(code, is_active);

CREATE INDEX IF NOT EXISTS idx_vouchers_window
  ON vouchers(starts_at, ends_at, is_active);

CREATE INDEX IF NOT EXISTS idx_voucher_redemptions_voucher_user
  ON voucher_redemptions(voucher_id, user_id, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS idx_voucher_redemptions_invoice_unique
  ON voucher_redemptions(invoice_id)
  WHERE invoice_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_affiliate_commissions_referrer_status
  ON affiliate_commissions(referrer_user_id, status, created_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS idx_affiliate_commissions_invoice_unique
  ON affiliate_commissions(invoice_id);
