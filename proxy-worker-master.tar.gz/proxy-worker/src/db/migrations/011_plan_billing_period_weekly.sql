ALTER TABLE plans
  DROP CONSTRAINT IF EXISTS plans_billing_period_check;

ALTER TABLE plans
  ADD CONSTRAINT plans_billing_period_check
  CHECK (billing_period IN ('weekly', 'monthly', 'yearly'));