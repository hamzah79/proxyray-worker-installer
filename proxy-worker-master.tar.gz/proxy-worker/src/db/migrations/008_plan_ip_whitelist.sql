ALTER TABLE plans
  ADD COLUMN IF NOT EXISTS whitelist_ip_limit INTEGER NOT NULL DEFAULT 0;

ALTER TABLE plans
  DROP COLUMN IF EXISTS whitelist_ips;

DROP INDEX IF EXISTS idx_plans_whitelist_ips;