import Redis from "ioredis";

import { logger } from "../observability/logger";

export async function createRedisClient(redisUrl: string): Promise<Redis | null> {
  if (!redisUrl) {
    return null;
  }

  const client = new Redis(redisUrl, {
    lazyConnect: true,
    maxRetriesPerRequest: 3
  });

  try {
    await client.connect();
    await client.ping();
    logger.info("redis connected");
    return client;
  } catch (error) {
    logger.warn("redis not available, fallback to local mode", { error: String(error) });
    try {
      client.disconnect();
    } catch {
      // ignore
    }
    return null;
  }
}
