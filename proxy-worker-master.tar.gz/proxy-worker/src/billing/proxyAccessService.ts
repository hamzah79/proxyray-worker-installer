import { UsersRepository } from "../db/repositories/usersRepository";

interface ProxyAccessResult {
  allowed: boolean;
  reason: "user_not_found" | "user_not_active" | "no_subscription" | "subscription_not_active" | "subscription_expired" | "ok";
  concurrentLimit: number | null;
}

interface CachedAccess {
  expiresAt: number;
  value: ProxyAccessResult;
}

export class ProxyAccessService {
  private readonly cache = new Map<string, CachedAccess>();

  constructor(
    private readonly usersRepo: UsersRepository,
    private readonly cacheTtlMs: number = 10_000
  ) {}

  async getAccess(username: string, clientIp?: string): Promise<ProxyAccessResult> {
    const cached = this.cache.get(username);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.value;
    }

    const profile = await this.usersRepo.findProxyAccessProfile(username);
    if (!profile) {
      return this.save(username, {
        allowed: false,
        reason: "user_not_found",
        concurrentLimit: null
      });
    }

    if (profile.user_status !== "active") {
      return this.save(username, {
        allowed: false,
        reason: "user_not_active",
        concurrentLimit: profile.concurrent_limit
      });
    }

    if (!profile.subscription_status) {
      return this.save(username, {
        allowed: false,
        reason: "no_subscription",
        concurrentLimit: profile.concurrent_limit
      });
    }

    if (profile.subscription_status !== "active" && profile.subscription_status !== "grace" && profile.subscription_status !== "trial") {
      return this.save(username, {
        allowed: false,
        reason: "subscription_not_active",
        concurrentLimit: profile.concurrent_limit
      });
    }

    const now = Date.now();
    const endsAt = profile.ends_at ? new Date(profile.ends_at).getTime() : 0;
    const graceUntil = profile.grace_until ? new Date(profile.grace_until).getTime() : 0;

    if ((profile.subscription_status === "active" || profile.subscription_status === "trial") && endsAt > 0 && endsAt <= now) {
      return this.save(username, {
        allowed: false,
        reason: "subscription_expired",
        concurrentLimit: profile.concurrent_limit
      });
    }

    if (profile.subscription_status === "grace" && graceUntil > 0 && graceUntil <= now) {
      return this.save(username, {
        allowed: false,
        reason: "subscription_expired",
        concurrentLimit: profile.concurrent_limit
      });
    }

    return this.save(username, {
      allowed: true,
      reason: "ok",
      concurrentLimit: profile.concurrent_limit
    });
  }

  invalidate(username: string): void {
    this.cache.delete(username);
  }

  private save(username: string, value: ProxyAccessResult): ProxyAccessResult {
    this.cache.set(username, {
      value,
      expiresAt: Date.now() + this.cacheTtlMs
    });

    return value;
  }
}
