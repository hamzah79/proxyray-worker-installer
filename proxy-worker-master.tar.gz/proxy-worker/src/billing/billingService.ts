import { randomUUID } from "node:crypto";

import { AppConfig } from "../config";
import { InvoiceRecord, InvoicesRepository } from "../db/repositories/invoicesRepository";
import { PaymentChannelsRepository } from "../db/repositories/paymentChannelsRepository";
import { PaymentEventsRepository } from "../db/repositories/paymentEventsRepository";
import { PlansRepository } from "../db/repositories/plansRepository";
import { SubscriptionsRepository } from "../db/repositories/subscriptionsRepository";
import { PakasirTransactionsRepository } from "../db/repositories/pakasirTransactionsRepository";
import { VoucherRecord, VouchersRepository } from "../db/repositories/vouchersRepository";
import { VoucherRedemptionsRepository } from "../db/repositories/voucherRedemptionsRepository";
import { UsersRepository } from "../db/repositories/usersRepository";
import { AffiliateCommissionsRepository } from "../db/repositories/affiliateCommissionsRepository";
import { PakasirProvider } from "./pakasirProvider";

export type CheckoutPaymentMethod = "paypal" | "bank_transfer" | "pakasir_qris" | "pakasir_va_bni" | "pakasir_va_bri" | "pakasir_va_cimb" | "pakasir_va_maybank" | "pakasir_va_permata" | "pakasir_va_bnc" | "pakasir_va_atm" | "pakasir_va_sampoerna" | "pakasir_va_artha" | "pakasir_paypal";

export class BillingService {
  constructor(
    private readonly config: AppConfig,
    private readonly plansRepo: PlansRepository,
    private readonly subscriptionsRepo: SubscriptionsRepository,
    private readonly invoicesRepo: InvoicesRepository,
    private readonly paymentEventsRepo: PaymentEventsRepository,
    private readonly paymentChannelsRepo: PaymentChannelsRepository | null,
    private readonly vouchersRepo: VouchersRepository | null,
    private readonly voucherRedemptionsRepo: VoucherRedemptionsRepository | null,
    private readonly usersRepo: UsersRepository | null,
    private readonly affiliateCommissionsRepo: AffiliateCommissionsRepository | null,
    private readonly pakasirProvider: PakasirProvider | null = null,
    private readonly pakasirTransactionsRepo: PakasirTransactionsRepository | null = null
  ) {}

  async createCheckout(params: {
    userId: string;
    planCode: string;
    paymentMethod: CheckoutPaymentMethod;
    paymentChannelCode?: string | null;
    voucherCode?: string | null;
    appBaseUrl?: string | null;
  }): Promise<{ invoice: InvoiceRecord; checkout: Record<string, unknown> }> {
    const plan = await this.plansRepo.findByCode(params.planCode);
    if (!plan || !plan.is_active) {
      throw new Error("plan_not_found");
    }

    const now = new Date();
    const startsAt = now.toISOString();
    const endsAt = new Date(now);
    if (plan.billing_period === "weekly") {
      endsAt.setDate(endsAt.getDate() + 7);
    } else if (plan.billing_period === "monthly") {
      endsAt.setMonth(endsAt.getMonth() + 1);
    } else {
      endsAt.setFullYear(endsAt.getFullYear() + 1);
    }

    const dueAt = new Date(now);
    dueAt.setDate(dueAt.getDate() + 1);

    const subscription = await this.subscriptionsRepo.createPending({
      userId: params.userId,
      planId: plan.id,
      startsAtIso: startsAt,
      endsAtIso: endsAt.toISOString()
    });

    // Check if payment method is Pakasir
    const isPakasirMethod = params.paymentMethod.startsWith("pakasir_");
    if (isPakasirMethod && !this.pakasirProvider?.isEnabled()) {
      throw new Error("pakasir_not_enabled");
    }

    if (isPakasirMethod && !this.config.pakasirEnabledMethods.has(params.paymentMethod)) {
      throw new Error("pakasir_method_not_enabled");
    }

    // Pakasir PayPal is not reliably available for all merchant accounts.
    if (params.paymentMethod === "pakasir_paypal") {
      throw new Error("unsupported_payment_method");
    }

    let invoiceProvider: "paypal" | "bank_transfer" | "pakasir";
    if (isPakasirMethod) {
      invoiceProvider = "pakasir";
    } else if (params.paymentMethod === "paypal" || params.paymentMethod === "bank_transfer") {
      invoiceProvider = params.paymentMethod;
    } else {
      throw new Error("unsupported_payment_method");
    }

    let selectedChannel: {
      code: string;
      name: string;
      provider: string;
      accountName: string;
      accountNumber: string;
      instructions: string | null;
    } | null = null;

    if (params.paymentMethod === "bank_transfer") {
      if (this.paymentChannelsRepo) {
        const channels = await this.paymentChannelsRepo.listActive();
        const selectedByCode = params.paymentChannelCode
          ? channels.find((item) => item.code === params.paymentChannelCode)
          : null;
        const picked = selectedByCode ?? channels[0] ?? null;

        if (params.paymentChannelCode && !picked) {
          throw new Error("payment_channel_not_found");
        }

        if (picked) {
          selectedChannel = {
            code: picked.code,
            name: picked.name,
            provider: picked.provider,
            accountName: picked.account_name,
            accountNumber: picked.account_number,
            instructions: picked.instructions
          };
        }
      }

      if (!selectedChannel) {
        selectedChannel = {
          code: "default_bank_transfer",
          name: this.config.bankTransferBankName,
          provider: "bank_transfer",
          accountName: this.config.bankTransferAccountName,
          accountNumber: this.config.bankTransferAccountNumber,
          instructions: "Gunakan invoice number sebagai berita transfer"
        };
      }
    }

    const voucherCode = (params.voucherCode ?? "").trim();
    let appliedVoucher: {
      id: string;
      code: string;
      discountType: "percent" | "fixed";
      discountValue: number;
      discountCents: number;
    } | null = null;

    if (voucherCode) {
      if (!this.vouchersRepo || !this.voucherRedemptionsRepo) {
        throw new Error("voucher_not_available");
      }

      const voucher = await this.vouchersRepo.findByCode(voucherCode);
      if (!voucher || !voucher.is_active) {
        throw new Error("voucher_not_found");
      }

      this.assertVoucherIsValidForCheckout(voucher, plan.code, now);

      if (voucher.max_redemptions !== null) {
        const totalRedemptions = await this.voucherRedemptionsRepo.countByVoucherId(voucher.id);
        if (totalRedemptions >= voucher.max_redemptions) {
          throw new Error("voucher_usage_limit_reached");
        }
      }

      const userRedemptions = await this.voucherRedemptionsRepo.countByVoucherIdAndUserId(voucher.id, params.userId);
      if (userRedemptions >= voucher.max_redemptions_per_user) {
        throw new Error("voucher_user_limit_reached");
      }

      const discountCents = this.calculateDiscountCents(plan.price_cents, voucher);
      if (discountCents > 0) {
        appliedVoucher = {
          id: voucher.id,
          code: voucher.code,
          discountType: voucher.discount_type,
          discountValue: voucher.discount_value,
          discountCents
        };
      }
    }

    const discountCents = appliedVoucher?.discountCents ?? 0;
    const finalAmountCents = Math.max(0, plan.price_cents - discountCents);

    const invoiceStatus = isPakasirMethod ? "awaiting_payment" : params.paymentMethod === "bank_transfer" ? "awaiting_payment" : "pending";

    // Temporary invoice metadata for later reference
    const tempInvoiceId = randomUUID();
    let invoiceMetadata: Record<string, unknown>;

    if (isPakasirMethod) {
      invoiceMetadata = {
        pakasir: {
          method: params.paymentMethod,
          orderIdPrefix: `INV-${tempInvoiceId.substring(0, 8)}`
        },
        voucher: appliedVoucher
      };
    } else if (params.paymentMethod === "bank_transfer") {
      invoiceMetadata = {
        paymentChannel: selectedChannel,
        transferInstructions: {
          bankName: selectedChannel?.name ?? this.config.bankTransferBankName,
          accountName: selectedChannel?.accountName ?? this.config.bankTransferAccountName,
          accountNumber: selectedChannel?.accountNumber ?? this.config.bankTransferAccountNumber,
          note: selectedChannel?.instructions ?? "Gunakan invoice number sebagai berita transfer"
        },
        voucher: appliedVoucher
      };
    } else {
      invoiceMetadata = {
        paypal: {
          mode: "stub",
          message: "Integrate PayPal order API for production"
        },
        voucher: appliedVoucher
      };
    }

    const invoice = await this.invoicesRepo.create({
      userId: params.userId,
      subscriptionId: subscription.id,
      planId: plan.id,
      status: invoiceStatus,
      amountCents: plan.price_cents,
      discountCents,
      finalAmountCents,
      voucherCode: appliedVoucher?.code ?? null,
      currency: plan.currency,
      dueAtIso: dueAt.toISOString(),
      provider: invoiceProvider,
      providerRef: null,
      idempotencyKey: randomUUID(),
      metadata: invoiceMetadata
    });

    if (appliedVoucher && this.voucherRedemptionsRepo) {
      await this.voucherRedemptionsRepo.create({
        voucherId: appliedVoucher.id,
        userId: params.userId,
        invoiceId: invoice.id,
        discountCents: appliedVoucher.discountCents
      });
    }

    let checkout: Record<string, unknown>;

    if (isPakasirMethod) {
      // Create Pakasir payment
      const pakasirMethod = this.mapToPakasirMethod(params.paymentMethod);
      const orderId = `INV-${invoice.id.substring(0, 12)}`;
      const appBaseUrl = (params.appBaseUrl ?? this.config.appBaseUrl ?? "http://localhost:9090").replace(/\/$/, "");
      const redirectUrl = `${appBaseUrl}/app?invoice=${invoice.id}`;

      const pakasirPayment = await this.pakasirProvider!.createPayment(
        orderId,
        invoice.final_amount_cents,
        pakasirMethod,
        redirectUrl
      );

      // Store Pakasir transaction
      if (this.pakasirTransactionsRepo) {
        await this.pakasirTransactionsRepo.create({
          invoiceId: invoice.id,
          pakasirOrderId: orderId,
          paymentMethod: params.paymentMethod,
          amountCents: invoice.final_amount_cents,
          feeCents: pakasirPayment.fee,
          totalAmountCents: pakasirPayment.totalAmount,
          paymentUrl: pakasirPayment.paymentUrl,
          expiredAt: pakasirPayment.expiredAt
        });
      }

      checkout = {
        provider: "pakasir",
        method: params.paymentMethod,
        orderId,
        paymentUrl: pakasirPayment.paymentUrl,
        amountCents: invoice.final_amount_cents,
        discountCents: invoice.discount_cents,
        subtotalCents: invoice.amount_cents,
        finalAmountCents: invoice.final_amount_cents,
        feeCents: pakasirPayment.fee,
        totalAmountCents: pakasirPayment.totalAmount,
        expiredAt: pakasirPayment.expiredAt
      };
    } else if (params.paymentMethod === "paypal") {
      checkout = {
        provider: "paypal",
        mode: "stub",
        orderRef: `paypal_order_${invoice.id}`,
        checkoutUrl: `https://www.paypal.com/checkoutnow?token=${invoice.id}`,
        discountCents: invoice.discount_cents,
        subtotalCents: invoice.amount_cents,
        finalAmountCents: invoice.final_amount_cents
      };
    } else {
      checkout = {
        provider: "bank_transfer",
        instructions: {
          channelCode: selectedChannel?.code ?? "default_bank_transfer",
          channelName: selectedChannel?.name ?? this.config.bankTransferBankName,
          provider: selectedChannel?.provider ?? "bank_transfer",
          bankName: selectedChannel?.name ?? this.config.bankTransferBankName,
          accountName: selectedChannel?.accountName ?? this.config.bankTransferAccountName,
          accountNumber: selectedChannel?.accountNumber ?? this.config.bankTransferAccountNumber,
          amountCents: invoice.final_amount_cents,
          subtotalCents: invoice.amount_cents,
          discountCents: invoice.discount_cents,
          finalAmountCents: invoice.final_amount_cents,
          currency: invoice.currency,
          invoiceNumber: invoice.invoice_number,
          dueAt: invoice.due_at,
          note: selectedChannel?.instructions ?? "Gunakan invoice number sebagai berita transfer"
        }
      };
    }

    return { invoice, checkout };
  }

  private assertVoucherIsValidForCheckout(voucher: VoucherRecord, planCode: string, now: Date): void {
    if (voucher.plan_code && voucher.plan_code !== planCode) {
      throw new Error("voucher_not_applicable_plan");
    }

    const nowTime = now.getTime();
    const startsAt = voucher.starts_at ? new Date(voucher.starts_at).getTime() : null;
    const endsAt = voucher.ends_at ? new Date(voucher.ends_at).getTime() : null;

    if (startsAt !== null && nowTime < startsAt) {
      throw new Error("voucher_not_started");
    }

    if (endsAt !== null && nowTime > endsAt) {
      throw new Error("voucher_expired");
    }
  }

  private calculateDiscountCents(baseAmountCents: number, voucher: VoucherRecord): number {
    if (baseAmountCents <= 0) {
      return 0;
    }

    if (voucher.discount_type === "percent") {
      const percent = Math.max(0, Math.min(100, voucher.discount_value));
      return Math.min(baseAmountCents, Math.floor((baseAmountCents * percent) / 100));
    }

    return Math.min(baseAmountCents, Math.max(0, voucher.discount_value));
  }

  private mapToPakasirMethod(method: string): "qris" | "paypal" | "bni_va" | "bri_va" | "cimb_niaga_va" | "maybank_va" | "permata_va" | "bnc_va" | "atm_bersama_va" | "sampoerna_va" | "artha_graha_va" {
    const mapping: Record<string, any> = {
      pakasir_qris: "qris",
      pakasir_va_bni: "bni_va",
      pakasir_va_bri: "bri_va",
      pakasir_va_cimb: "cimb_niaga_va",
      pakasir_va_maybank: "maybank_va",
      pakasir_va_permata: "permata_va",
      pakasir_va_bnc: "bnc_va",
      pakasir_va_atm: "atm_bersama_va",
      pakasir_va_sampoerna: "sampoerna_va",
      pakasir_va_artha: "artha_graha_va",
      pakasir_paypal: "paypal"
    };
    return mapping[method] || "qris";
  }

  async startTrial(params: {
    userId: string;
    planCode?: string | null;
  }): Promise<{ subscriptionId: string; planCode: string; startsAt: string; endsAt: string }> {
    const hasTrialHistory = await this.subscriptionsRepo.hasTrialHistory(params.userId);
    if (hasTrialHistory) {
      throw new Error("trial_already_used");
    }

    const latest = await this.subscriptionsRepo.findLatestByUserId(params.userId);
    if (latest && (latest.status === "active" || latest.status === "trial") && new Date(latest.ends_at).getTime() > Date.now()) {
      throw new Error("active_subscription_exists");
    }

    const candidatePlan = await this.resolveTrialPlan(params.planCode ?? null);
    if (!candidatePlan) {
      throw new Error("trial_plan_not_found");
    }

    const trialDays = candidatePlan.trial_days > 0 ? candidatePlan.trial_days : this.config.defaultTrialDays;
    if (trialDays <= 0) {
      throw new Error("trial_disabled");
    }

    const startsAt = new Date();
    const endsAt = new Date(startsAt);
    endsAt.setDate(endsAt.getDate() + trialDays);

    const subscription = await this.subscriptionsRepo.createTrial({
      userId: params.userId,
      planId: candidatePlan.id,
      startsAtIso: startsAt.toISOString(),
      endsAtIso: endsAt.toISOString(),
      externalRef: "trial"
    });

    return {
      subscriptionId: subscription.id,
      planCode: candidatePlan.code,
      startsAt: subscription.starts_at,
      endsAt: subscription.ends_at
    };
  }

  async getTrialStatus(userId: string): Promise<{ active: boolean; subscriptionId: string | null; startsAt: string | null; endsAt: string | null }> {
    const expiredCount = await this.subscriptionsRepo.expireDueTrials(new Date().toISOString());
    if (expiredCount > 0) {
      // Trial expiration update is best-effort and should not interrupt reads.
    }

    const activeTrial = await this.subscriptionsRepo.findActiveTrialByUserId(userId);
    if (!activeTrial) {
      return {
        active: false,
        subscriptionId: null,
        startsAt: null,
        endsAt: null
      };
    }

    return {
      active: true,
      subscriptionId: activeTrial.id,
      startsAt: activeTrial.starts_at,
      endsAt: activeTrial.ends_at
    };
  }

  async markInvoicePaid(invoiceId: string, providerRef: string | null): Promise<{ justPaid: boolean; userId: string; invoiceNumber: string }> {
    const invoice = await this.invoicesRepo.findById(invoiceId);
    if (!invoice) {
      throw new Error("invoice_not_found");
    }

    const justPaid = invoice.status !== "paid";
    await this.invoicesRepo.setPaid(invoice.id, providerRef);
    if (invoice.subscription_id) {
      await this.subscriptionsRepo.activate(invoice.subscription_id);
    }

    if (justPaid) {
      await this.createAffiliateCommissionIfEligible({
        id: invoice.id,
        userId: invoice.user_id,
        finalAmountCents: invoice.final_amount_cents
      });
    }

    return {
      justPaid,
      userId: invoice.user_id,
      invoiceNumber: invoice.invoice_number
    };
  }

  async processPaypalWebhook(params: {
    providerEventId: string;
    eventType: string;
    invoiceId: string;
    providerRef: string | null;
    payload: unknown;
  }): Promise<{ processed: boolean; invoiceStatus: string | null; justPaid: boolean; userId: string | null; invoiceNumber: string | null }> {
    const invoice = await this.invoicesRepo.findById(params.invoiceId);
    if (!invoice) {
      throw new Error("invoice_not_found");
    }

    const inserted = await this.paymentEventsRepo.recordIfNew({
      provider: "paypal",
      eventType: params.eventType,
      providerEventId: params.providerEventId,
      invoiceId: invoice.id,
      subscriptionId: invoice.subscription_id,
      payload: params.payload
    });

    if (!inserted) {
      return {
        processed: false,
        invoiceStatus: invoice.status,
        justPaid: false,
        userId: invoice.user_id,
        invoiceNumber: invoice.invoice_number
      };
    }

    const success = isPaypalSuccess(params.eventType, params.payload);
    const failure = isPaypalFailure(params.eventType, params.payload);

    if (success) {
      const paidResult = await this.markInvoicePaid(invoice.id, params.providerRef);
      return {
        processed: true,
        invoiceStatus: "paid",
        justPaid: paidResult.justPaid,
        userId: paidResult.userId,
        invoiceNumber: paidResult.invoiceNumber
      };
    }

    if (failure) {
      await this.invoicesRepo.setStatus(invoice.id, "failed");
      return {
        processed: true,
        invoiceStatus: "failed",
        justPaid: false,
        userId: invoice.user_id,
        invoiceNumber: invoice.invoice_number
      };
    }

    return {
      processed: true,
      invoiceStatus: invoice.status,
      justPaid: false,
      userId: invoice.user_id,
      invoiceNumber: invoice.invoice_number
    };
  }

  async verifyBankTransfer(invoiceId: string): Promise<{ justPaid: boolean; userId: string; invoiceNumber: string }> {
    const invoice = await this.invoicesRepo.findById(invoiceId);
    if (!invoice) {
      throw new Error("invoice_not_found");
    }

    if (invoice.provider !== "bank_transfer") {
      throw new Error("invoice_provider_not_bank_transfer");
    }

    return this.markInvoicePaid(invoice.id, invoice.provider_ref);
  }

  private async resolveTrialPlan(planCode: string | null): Promise<{ id: string; code: string; trial_days: number } | null> {
    if (planCode) {
      const plan = await this.plansRepo.findByCode(planCode);
      if (!plan || !plan.is_active) {
        return null;
      }

      return {
        id: plan.id,
        code: plan.code,
        trial_days: plan.trial_days
      };
    }

    const activePlans = await this.plansRepo.listActive();
    if (activePlans.length === 0) {
      return null;
    }

    const selected = activePlans.find((item) => item.trial_days > 0) ?? activePlans[0];
    return {
      id: selected.id,
      code: selected.code,
      trial_days: selected.trial_days
    };
  }

  private async createAffiliateCommissionIfEligible(params: { id: string; userId: string; finalAmountCents: number }): Promise<void> {
    if (!this.usersRepo || !this.affiliateCommissionsRepo) {
      return;
    }

    if (params.finalAmountCents <= 0) {
      return;
    }

    const existingCommission = await this.affiliateCommissionsRepo.findByInvoiceId(params.id);
    if (existingCommission) {
      return;
    }

    const paidCount = await this.invoicesRepo.countPaidByUser(params.userId);
    if (paidCount !== 1) {
      return;
    }

    const user = await this.usersRepo.findById(params.userId);
    if (!user?.referred_by_user_id) {
      return;
    }

    const commissionCents = Math.floor((params.finalAmountCents * this.config.affiliateCommissionPercent) / 100);
    if (commissionCents <= 0) {
      return;
    }

    await this.affiliateCommissionsRepo.create({
      referrerUserId: user.referred_by_user_id,
      referredUserId: user.id,
      invoiceId: params.id,
      commissionCents,
      status: "pending"
    });
  }
}

function isPaypalSuccess(eventType: string, payload: unknown): boolean {
  const status = extractResourceStatus(payload);
  return (
    ["PAYMENT.CAPTURE.COMPLETED", "CHECKOUT.ORDER.APPROVED", "INVOICE.PAID"].includes(eventType) ||
    status === "COMPLETED"
  );
}

function isPaypalFailure(eventType: string, payload: unknown): boolean {
  const status = extractResourceStatus(payload);
  return (
    ["PAYMENT.CAPTURE.DENIED", "PAYMENT.CAPTURE.DECLINED", "CHECKOUT.ORDER.CANCELLED"].includes(eventType) ||
    status === "DENIED" ||
    status === "FAILED" ||
    status === "VOIDED"
  );
}

function extractResourceStatus(payload: unknown): string {
  if (!payload || typeof payload !== "object") return "";
  const resource = (payload as { resource?: unknown }).resource;
  if (!resource || typeof resource !== "object") return "";
  const status = (resource as { status?: unknown }).status;
  return typeof status === "string" ? status.toUpperCase() : "";
}
