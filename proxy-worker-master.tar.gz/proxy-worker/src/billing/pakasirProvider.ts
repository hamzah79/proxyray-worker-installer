import { Pakasir, PaymentPayload, PaymentMethod } from 'pakasir-sdk';
import { logger } from '../observability/logger';

export interface PakasirProviderConfig {
  slug: string;
  apikey: string;
  enabled: boolean;
}

export interface PakasirPaymentResult {
  status: 'pending' | 'paid' | 'failed' | 'expired';
  paymentUrl: string;
  paymentMethod: string;
  totalAmount: number;
  fee: number;
  expiredAt: Date | null;
}

export class PakasirProvider {
  private client: Pakasir | null = null;
  private config: PakasirProviderConfig;

  constructor(config: PakasirProviderConfig) {
    this.config = config;
    if (config.enabled && config.slug && config.apikey) {
      try {
        this.client = new Pakasir({
          slug: config.slug,
          apikey: config.apikey,
        });
        logger.info('pakasir_provider initialized', { slug: config.slug });
      } catch (error) {
        logger.error('pakasir_provider initialization failed', { error: String(error) });
      }
    }
  }

  isEnabled(): boolean {
    return this.config.enabled && Boolean(this.client);
  }

  async createPayment(
    orderId: string,
    amountCents: number,
    method: PaymentMethod = 'qris',
    redirectUrl?: string
  ): Promise<PakasirPaymentResult> {
    if (!this.client) {
      throw new Error('PakasirProvider not initialized');
    }

    const amountRupiah = Math.floor(amountCents / 100);
    if (amountRupiah < 500) {
      throw new Error('Amount must be at least Rp500');
    }

    try {
      const payload: PaymentPayload = await this.client.createPayment(
        method,
        orderId,
        amountRupiah,
        redirectUrl
      );

      return {
        status: this.mapPakasirStatus(payload.status),
        paymentUrl: payload.payment_url || '',
        paymentMethod: method,
        totalAmount: payload.total_payment,
        fee: payload.fee,
        expiredAt: payload.expired_at ? new Date(payload.expired_at) : null,
      };
    } catch (error) {
      logger.error('pakasir_create_payment failed', {
        orderId,
        amountCents,
        method,
        error: String(error),
      });
      throw new Error(`Failed to create Pakasir payment: ${String(error)}`);
    }
  }

  async getPaymentStatus(orderId: string, amountCents: number): Promise<PakasirPaymentResult> {
    if (!this.client) {
      throw new Error('PakasirProvider not initialized');
    }

    const amountRupiah = Math.floor(amountCents / 100);

    try {
      const payload: PaymentPayload = await this.client.detailPayment(orderId, amountRupiah);

      return {
        status: this.mapPakasirStatus(payload.status),
        paymentUrl: payload.payment_url || '',
        paymentMethod: payload.payment_method || 'unknown',
        totalAmount: payload.total_payment,
        fee: payload.fee,
        expiredAt: payload.expired_at ? new Date(payload.expired_at) : null,
      };
    } catch (error) {
      logger.error('pakasir_detail_payment failed', {
        orderId,
        amountCents,
        error: String(error),
      });
      throw new Error(`Failed to get Pakasir payment status: ${String(error)}`);
    }
  }

  async cancelPayment(orderId: string, amountCents: number): Promise<void> {
    if (!this.client) {
      throw new Error('PakasirProvider not initialized');
    }

    const amountRupiah = Math.floor(amountCents / 100);

    try {
      await this.client.cancelPayment(orderId, amountRupiah);
      logger.info('pakasir_cancel_payment succeeded', { orderId });
    } catch (error) {
      logger.error('pakasir_cancel_payment failed', {
        orderId,
        amountCents,
        error: String(error),
      });
      throw new Error(`Failed to cancel Pakasir payment: ${String(error)}`);
    }
  }

  async simulatePayment(orderId: string, amountCents: number): Promise<PakasirPaymentResult> {
    if (!this.client) {
      throw new Error('PakasirProvider not initialized');
    }

    const amountRupiah = Math.floor(amountCents / 100);

    try {
      const payload: PaymentPayload = await this.client.simulationPayment(
        orderId,
        amountRupiah
      );

      return {
        status: this.mapPakasirStatus(payload.status),
        paymentUrl: payload.payment_url || '',
        paymentMethod: payload.payment_method || 'qris',
        totalAmount: payload.total_payment,
        fee: payload.fee,
        expiredAt: payload.expired_at ? new Date(payload.expired_at) : null,
      };
    } catch (error) {
      logger.error('pakasir_simulation_payment failed', {
        orderId,
        amountCents,
        error: String(error),
      });
      throw new Error(`Failed to simulate Pakasir payment: ${String(error)}`);
    }
  }

  private mapPakasirStatus(status: string): 'pending' | 'paid' | 'failed' | 'expired' {
    switch (status?.toLowerCase()) {
      case 'completed':
      case 'paid':
        return 'paid';
      case 'pending':
        return 'pending';
      case 'canceled':
      case 'failed':
        return 'failed';
      case 'expired':
        return 'expired';
      default:
        return 'pending';
    }
  }

  updateConfig(config: Partial<PakasirProviderConfig>): void {
    this.config = { ...this.config, ...config };
    if (config.enabled && config.slug && config.apikey) {
      try {
        this.client = new Pakasir({
          slug: config.slug,
          apikey: config.apikey,
        });
        logger.info('pakasir_provider config updated', { slug: config.slug });
      } catch (error) {
        logger.error('pakasir_provider config update failed', { error: String(error) });
      }
    }
  }
}
