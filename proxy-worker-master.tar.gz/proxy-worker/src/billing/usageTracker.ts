import { DatabaseClient } from '../db/client';

/**
 * Usage record for a single request
 */
export interface UsageRecord {
  userId: number;
  username: string;
  timestamp: Date;
  requestCount: number;
  uploadBytes: number;
  downloadBytes: number;
  totalBytes: number;
  exitCountry: string;
  backendId: string;
  success: boolean;
  latencyMs: number;
}

/**
 * Usage summary for a user
 */
export interface UsageSummary {
  userId: number;
  username: string;
  periodStart: Date;
  periodEnd: Date;
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  totalBytes: number;
  uploadBytes: number;
  downloadBytes: number;
  avgLatencyMs: number;
  countriesUsed: string[];
}

/**
 * Track usage for billing and analytics
 */
export class UsageTracker {
  private buffer: UsageRecord[] = [];
  private readonly bufferSize: number;
  private readonly flushIntervalMs: number;
  private flushTimer: NodeJS.Timeout | null = null;

  constructor(
    private readonly db: DatabaseClient | null,
    bufferSize = 100,
    flushIntervalMs = 30000
  ) {
    this.bufferSize = bufferSize;
    this.flushIntervalMs = flushIntervalMs;
    
    if (this.db) {
      this.startAutoFlush();
    }
  }

  /**
   * Record usage for a request
   */
  async recordUsage(record: Omit<UsageRecord, 'timestamp' | 'totalBytes'>): Promise<void> {
    const fullRecord: UsageRecord = {
      ...record,
      timestamp: new Date(),
      totalBytes: record.uploadBytes + record.downloadBytes,
    };

    this.buffer.push(fullRecord);

    // Auto-flush if buffer is full
    if (this.buffer.length >= this.bufferSize) {
      await this.flush();
    }
  }

  /**
   * Flush buffered records to database
   */
  async flush(): Promise<void> {
    if (!this.db || this.buffer.length === 0) {
      return;
    }

    const records = [...this.buffer];
    this.buffer = [];

    try {
      // Aggregate records by user and 5-minute window
      const aggregated = this.aggregateRecords(records);

      // Insert into database
      for (const agg of aggregated) {
        await this.db.query(
          `INSERT INTO usage_logs (
            user_id, username, timestamp, request_count,
            upload_bytes, download_bytes, total_bytes,
            exit_country, backend_id, success, latency_ms
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
          ON CONFLICT (user_id, timestamp) DO UPDATE SET
            request_count = usage_logs.request_count + EXCLUDED.request_count,
            upload_bytes = usage_logs.upload_bytes + EXCLUDED.upload_bytes,
            download_bytes = usage_logs.download_bytes + EXCLUDED.download_bytes,
            total_bytes = usage_logs.total_bytes + EXCLUDED.total_bytes`,
          [
            agg.userId,
            agg.username,
            agg.timestamp,
            agg.requestCount,
            agg.uploadBytes,
            agg.downloadBytes,
            agg.totalBytes,
            agg.exitCountry,
            agg.backendId,
            agg.success,
            agg.latencyMs,
          ]
        );
      }
    } catch (error) {
      // Log error but don't throw - we don't want to break proxy operations
      console.error('[UsageTracker] Failed to flush records:', error);
      
      // Put records back in buffer for retry
      this.buffer.unshift(...records);
      
      // Prevent buffer from growing too large
      if (this.buffer.length > this.bufferSize * 10) {
        this.buffer = this.buffer.slice(-this.bufferSize * 5);
      }
    }
  }

  /**
   * Get usage summary for a user
   */
  async getUserUsage(
    userId: number,
    startDate: Date,
    endDate: Date
  ): Promise<UsageSummary | null> {
    if (!this.db) {
      return null;
    }

    const result = await this.db.query(
      `SELECT
        user_id,
        username,
        SUM(request_count) as total_requests,
        SUM(CASE WHEN success THEN request_count ELSE 0 END) as successful_requests,
        SUM(CASE WHEN NOT success THEN request_count ELSE 0 END) as failed_requests,
        SUM(total_bytes) as total_bytes,
        SUM(upload_bytes) as upload_bytes,
        SUM(download_bytes) as download_bytes,
        AVG(latency_ms) as avg_latency_ms,
        ARRAY_AGG(DISTINCT exit_country) as countries_used
      FROM usage_logs
      WHERE user_id = $1 AND timestamp >= $2 AND timestamp <= $3
      GROUP BY user_id, username`,
      [userId, startDate, endDate]
    );

    if (result.length === 0) {
      return null;
    }

    const row = result[0];
    return {
      userId: row.user_id,
      username: row.username,
      periodStart: startDate,
      periodEnd: endDate,
      totalRequests: parseInt(row.total_requests, 10) || 0,
      successfulRequests: parseInt(row.successful_requests, 10) || 0,
      failedRequests: parseInt(row.failed_requests, 10) || 0,
      totalBytes: parseInt(row.total_bytes, 10) || 0,
      uploadBytes: parseInt(row.upload_bytes, 10) || 0,
      downloadBytes: parseInt(row.download_bytes, 10) || 0,
      avgLatencyMs: parseFloat(row.avg_latency_ms) || 0,
      countriesUsed: row.countries_used || [],
    };
  }

  /**
   * Get top users by bandwidth
   */
  async getTopUsers(limit = 10, startDate?: Date, endDate?: Date): Promise<UsageSummary[]> {
    if (!this.db) {
      return [];
    }

    const params: any[] = [limit];
    let whereClause = '';
    
    if (startDate && endDate) {
      whereClause = 'WHERE timestamp >= $2 AND timestamp <= $3';
      params.push(startDate, endDate);
    }

    const result = await this.db.query(
      `SELECT
        user_id,
        username,
        SUM(request_count) as total_requests,
        SUM(CASE WHEN success THEN request_count ELSE 0 END) as successful_requests,
        SUM(CASE WHEN NOT success THEN request_count ELSE 0 END) as failed_requests,
        SUM(total_bytes) as total_bytes,
        SUM(upload_bytes) as upload_bytes,
        SUM(download_bytes) as download_bytes,
        AVG(latency_ms) as avg_latency_ms,
        ARRAY_AGG(DISTINCT exit_country) as countries_used
      FROM usage_logs
      ${whereClause}
      GROUP BY user_id, username
      ORDER BY total_bytes DESC
      LIMIT $1`,
      params
    );

    return result.map(row => ({
      userId: row.user_id,
      username: row.username,
      periodStart: startDate || new Date(0),
      periodEnd: endDate || new Date(),
      totalRequests: parseInt(row.total_requests, 10) || 0,
      successfulRequests: parseInt(row.successful_requests, 10) || 0,
      failedRequests: parseInt(row.failed_requests, 10) || 0,
      totalBytes: parseInt(row.total_bytes, 10) || 0,
      uploadBytes: parseInt(row.upload_bytes, 10) || 0,
      downloadBytes: parseInt(row.download_bytes, 10) || 0,
      avgLatencyMs: parseFloat(row.avg_latency_ms) || 0,
      countriesUsed: row.countries_used || [],
    }));
  }

  /**
   * Aggregate records by user and time window
   */
  private aggregateRecords(records: UsageRecord[]): UsageRecord[] {
    const map = new Map<string, UsageRecord>();

    for (const record of records) {
      // Round timestamp to 5-minute window
      const windowMs = 5 * 60 * 1000;
      const windowTimestamp = new Date(Math.floor(record.timestamp.getTime() / windowMs) * windowMs);
      
      const key = `${record.userId}-${windowTimestamp.getTime()}-${record.exitCountry}-${record.backendId}`;
      
      const existing = map.get(key);
      if (existing) {
        existing.requestCount += record.requestCount;
        existing.uploadBytes += record.uploadBytes;
        existing.downloadBytes += record.downloadBytes;
        existing.totalBytes += record.totalBytes;
        existing.latencyMs = (existing.latencyMs + record.latencyMs) / 2; // Average latency
      } else {
        map.set(key, {
          ...record,
          timestamp: windowTimestamp,
        });
      }
    }

    return Array.from(map.values());
  }

  /**
   * Start auto-flush timer
   */
  private startAutoFlush(): void {
    this.flushTimer = setInterval(() => {
      this.flush().catch(err => {
        console.error('[UsageTracker] Auto-flush failed:', err);
      });
    }, this.flushIntervalMs);
  }

  /**
   * Stop auto-flush and cleanup
   */
  async destroy(): Promise<void> {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
    
    // Final flush
    await this.flush();
  }
}
