import http from "node:http";
import https from "node:https";

import { SocksProxyAgent } from "socks-proxy-agent";

import { AppConfig } from "../config";
import { logger } from "../observability/logger";
import { TorManager } from "../tor/torManager";
import { TorBackend } from "../types";

type HealthcheckPayload = {
  IP?: string;
  ip?: string;
  country?: string;
  country_name?: string;
  countryCode?: string;
  country_code?: string;
  countryCodeIso?: string;
  cc?: string;
};

type IpApiPayload = {
  country?: string;
  country_name?: string;
};

type IpWhoPayload = {
  success?: boolean;
  country_code?: string;
  country?: string;
};

type IpApiComPayload = {
  status?: string;
  countryCode?: string;
  country?: string;
};

export class HealthMonitor {
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly config: AppConfig,
    private readonly torManager: TorManager
  ) {}

  start(): void {
    this.timer = setInterval(() => {
      this.runChecks().catch((error: unknown) => {
        logger.error("health check cycle failed", { error: String(error) });
      });
    }, this.config.healthcheckIntervalMs);

    this.runChecks().catch((error: unknown) => {
      logger.error("initial health check failed", { error: String(error) });
    });
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private async runChecks(): Promise<void> {
    const backends = this.torManager.getBackends();
    await Promise.all(backends.map((backend) => this.checkBackend(backend)));
  }

  private async checkBackend(backend: TorBackend): Promise<void> {
    const targetUrl = new URL(this.config.healthcheckUrl);
    const protocol = targetUrl.protocol === "https:" ? https : http;
    const agent = new SocksProxyAgent(`socks5h://127.0.0.1:${backend.socksPort}`);

    await new Promise<void>((resolve) => {
      const request = protocol.request(
        {
          method: "GET",
          hostname: targetUrl.hostname,
          port: targetUrl.port || (targetUrl.protocol === "https:" ? 443 : 80),
          path: `${targetUrl.pathname}${targetUrl.search}`,
          timeout: 12000,
          agent
        },
        (response) => {
          const chunks: Buffer[] = [];
          response.on("data", (chunk: Buffer) => chunks.push(chunk));
          response.on("end", async () => {
            const healthy = response.statusCode !== undefined && response.statusCode < 500;
            this.torManager.markHealth(backend.id, healthy);
            this.torManager.updateBackendTelemetry(backend.id, {
              lastCheckedAt: new Date().toISOString()
            });

            if (!healthy) {
              resolve();
              return;
            }

            const responseText = Buffer.concat(chunks).toString("utf8");
            const telemetryFromHealth = this.extractTelemetryFromHealthcheck(responseText);
            const exitIp = telemetryFromHealth.exitIp;
            if (!exitIp) {
              resolve();
              return;
            }

            let countryCode = telemetryFromHealth.countryCode;
            let countryName = telemetryFromHealth.countryName;

            if (!countryCode || !countryName) {
              const geo = await this.lookupCountry(exitIp);
              countryCode = geo.countryCode || countryCode;
              countryName = geo.countryName || countryName;
            }

            this.torManager.updateBackendTelemetry(backend.id, {
              exitIp,
              countryCode: countryCode || null,
              countryName: countryName || null
            });
            resolve();
          });
        }
      );

      request.on("timeout", () => {
        this.torManager.markHealth(backend.id, false);
        this.torManager.updateBackendTelemetry(backend.id, {
          lastCheckedAt: new Date().toISOString()
        });
        request.destroy();
        resolve();
      });

      request.on("error", () => {
        this.torManager.markHealth(backend.id, false);
        this.torManager.updateBackendTelemetry(backend.id, {
          lastCheckedAt: new Date().toISOString()
        });
        resolve();
      });

      request.end();
    });
  }

  private extractTelemetryFromHealthcheck(responseText: string): {
    exitIp: string | null;
    countryCode: string | null;
    countryName: string | null;
  } {
    if (!responseText) {
      return { exitIp: null, countryCode: null, countryName: null };
    }

    try {
      const parsed = JSON.parse(responseText) as HealthcheckPayload;
      const ip = typeof parsed.IP === "string" ? parsed.IP : typeof parsed.ip === "string" ? parsed.ip : "";
      const countryCodeRaw =
        typeof parsed.countryCode === "string"
          ? parsed.countryCode
          : typeof parsed.country_code === "string"
            ? parsed.country_code
            : typeof parsed.countryCodeIso === "string"
              ? parsed.countryCodeIso
              : typeof parsed.cc === "string"
                ? parsed.cc
                : "";
      const countryNameRaw =
        typeof parsed.country_name === "string"
          ? parsed.country_name
          : typeof parsed.country === "string"
            ? parsed.country
            : "";

      return {
        exitIp: ip.trim() || null,
        countryCode: countryCodeRaw.trim().toUpperCase() || null,
        countryName: countryNameRaw.trim() || null
      };
    } catch {
      const match = responseText.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b|\b(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}\b/);
      return {
        exitIp: match ? match[0].trim() : null,
        countryCode: null,
        countryName: null
      };
    }
  }

  private async lookupCountry(exitIp: string): Promise<{ countryCode: string | null; countryName: string | null }> {
    const providers = [
      () => this.lookupCountryViaIpApi(exitIp),
      () => this.lookupCountryViaIpWho(exitIp),
      () => this.lookupCountryViaIpApiCom(exitIp)
    ];

    for (const provider of providers) {
      const result = await provider();
      if (result.countryCode && result.countryName) {
        return result;
      }
    }

    return { countryCode: null, countryName: null };
  }

  private async lookupCountryViaIpApi(exitIp: string): Promise<{ countryCode: string | null; countryName: string | null }> {
    const body = await this.requestViaProxy({
      protocol: "https",
      hostname: "ipapi.co",
      port: 443,
      path: `/${encodeURIComponent(exitIp)}/json/`,
      timeout: 5000
    });

    if (!body) {
      return { countryCode: null, countryName: null };
    }

    try {
      const parsed = JSON.parse(body) as IpApiPayload;
      const code = typeof parsed.country === "string" ? parsed.country.trim().toUpperCase() : "";
      const name = typeof parsed.country_name === "string" ? parsed.country_name.trim() : "";
      return {
        countryCode: code || null,
        countryName: name || null
      };
    } catch {
      return { countryCode: null, countryName: null };
    }
  }

  private async lookupCountryViaIpWho(exitIp: string): Promise<{ countryCode: string | null; countryName: string | null }> {
    const body = await this.requestViaProxy({
      protocol: "https",
      hostname: "ipwho.is",
      port: 443,
      path: `/${encodeURIComponent(exitIp)}`,
      timeout: 5000
    });

    if (!body) {
      return { countryCode: null, countryName: null };
    }

    try {
      const parsed = JSON.parse(body) as IpWhoPayload;
      if (parsed.success === false) {
        return { countryCode: null, countryName: null };
      }

      const code = typeof parsed.country_code === "string" ? parsed.country_code.trim().toUpperCase() : "";
      const name = typeof parsed.country === "string" ? parsed.country.trim() : "";
      return {
        countryCode: code || null,
        countryName: name || null
      };
    } catch {
      return { countryCode: null, countryName: null };
    }
  }

  private async lookupCountryViaIpApiCom(exitIp: string): Promise<{ countryCode: string | null; countryName: string | null }> {
    const body = await this.requestViaProxy({
      protocol: "http",
      hostname: "ip-api.com",
      port: 80,
      path: `/json/${encodeURIComponent(exitIp)}?fields=status,country,countryCode`,
      timeout: 5000
    });

    if (!body) {
      return { countryCode: null, countryName: null };
    }

    try {
      const parsed = JSON.parse(body) as IpApiComPayload;
      if (parsed.status && parsed.status.toLowerCase() !== "success") {
        return { countryCode: null, countryName: null };
      }

      const code = typeof parsed.countryCode === "string" ? parsed.countryCode.trim().toUpperCase() : "";
      const name = typeof parsed.country === "string" ? parsed.country.trim() : "";
      return {
        countryCode: code || null,
        countryName: name || null
      };
    } catch {
      return { countryCode: null, countryName: null };
    }
  }

  private async requestViaProxy(options: {
    protocol: "http" | "https";
    hostname: string;
    port: number;
    path: string;
    timeout: number;
    agent?: SocksProxyAgent;
  }): Promise<string | null> {
    const protocol = options.protocol === "https" ? https : http;

    return new Promise((resolve) => {
      const req = protocol.request(
        {
          method: "GET",
          hostname: options.hostname,
          port: options.port,
          path: options.path,
          timeout: options.timeout,
          agent: options.agent
        },
        (res) => {
          const statusCode = res.statusCode ?? 0;
          const chunks: Buffer[] = [];
          res.on("data", (chunk: Buffer) => chunks.push(chunk));
          res.on("end", () => {
            if (statusCode < 200 || statusCode >= 300) {
              resolve(null);
              return;
            }
            resolve(Buffer.concat(chunks).toString("utf8"));
          });
        }
      );

      req.on("timeout", () => {
        req.destroy();
        resolve(null);
      });

      req.on("error", () => {
        resolve(null);
      });

      req.end();
    });
  }
}
