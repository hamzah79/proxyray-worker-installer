import * as http from 'node:http';
import * as https from 'node:https';
import { ConnectionPoolConfig } from '../config/connectionPoolConfig';
import { logger } from '../observability/logger';

/**
 * Pooled Connection wrapper
 */
interface PooledConnection {
  agent: http.Agent | https.Agent;
  lastUsed: number;
  activeRequests: number;
  backendId: string;
}

/**
 * Connection Pool Statistics
 */
export interface PoolStats {
  backendId: string;
  totalConnections: number;
  activeConnections: number;
  idleConnections: number;
  totalRequests: number;
  reuseCount: number;
}

/**
 * HTTP/HTTPS Connection Pool Manager
 * Manages connection pooling for backend requests
 */
export class ConnectionPool {
  private readonly config: ConnectionPoolConfig;
  private readonly pools = new Map<string, PooledConnection>();
  private readonly stats = new Map<string, { requests: number; reuses: number }>();
  private cleanupInterval?: NodeJS.Timeout;

  constructor(config: ConnectionPoolConfig) {
    this.config = config;
    this.startCleanup();
  }

  /**
   * Get or create HTTP agent for backend
   */
  getHttpAgent(backendId: string): http.Agent {
    return this.getAgent(backendId, false) as http.Agent;
  }

  /**
   * Get or create HTTPS agent for backend
   */
  getHttpsAgent(backendId: string): https.Agent {
    return this.getAgent(backendId, true) as https.Agent;
  }

  /**
   * Get or create agent for backend
   */
  private getAgent(backendId: string, isHttps: boolean): http.Agent | https.Agent {
    const key = `${backendId}:${isHttps ? 'https' : 'http'}`;
    let pooled = this.pools.get(key);

    if (!pooled) {
      // Create new agent with pooling configuration
      const AgentClass = isHttps ? https.Agent : http.Agent;
      const agent = new AgentClass({
        keepAlive: this.config.keepAlive,
        keepAliveMsecs: this.config.keepAliveInitialDelay,
        maxSockets: this.config.maxConnectionsPerBackend,
        maxFreeSockets: this.config.maxConnectionsPerBackend,
        timeout: this.config.connectionTimeout,
        scheduling: 'lifo', // Last-in-first-out for better connection reuse
      });

      pooled = {
        agent,
        lastUsed: Date.now(),
        activeRequests: 0,
        backendId,
      };

      this.pools.set(key, pooled);
      this.stats.set(key, { requests: 0, reuses: 0 });

      logger.info('connection pool created', {
        backendId,
        protocol: isHttps ? 'https' : 'http',
        maxConnections: this.config.maxConnectionsPerBackend,
      });
    }

    // Update usage stats
    pooled.lastUsed = Date.now();
    pooled.activeRequests++;

    const stats = this.stats.get(key)!;
    stats.requests++;
    if (stats.requests > 1) {
      stats.reuses++;
    }

    return pooled.agent;
  }

  /**
   * Release agent after request completes
   */
  releaseAgent(backendId: string, isHttps: boolean): void {
    const key = `${backendId}:${isHttps ? 'https' : 'http'}`;
    const pooled = this.pools.get(key);

    if (pooled && pooled.activeRequests > 0) {
      pooled.activeRequests--;
      pooled.lastUsed = Date.now();
    }
  }

  /**
   * Get pool statistics for all backends
   */
  getStats(): PoolStats[] {
    const result: PoolStats[] = [];

    for (const [key, pooled] of Array.from(this.pools.entries())) {
      const stats = this.stats.get(key) || { requests: 0, reuses: 0 };
      const sockets = (pooled.agent as any).sockets || {};
      const freeSockets = (pooled.agent as any).freeSockets || {};

      let totalConnections = 0;
      let idleConnections = 0;

      // Count active sockets
      for (const socketList of Object.values(sockets)) {
        if (Array.isArray(socketList)) {
          totalConnections += socketList.length;
        }
      }

      // Count idle sockets
      for (const socketList of Object.values(freeSockets)) {
        if (Array.isArray(socketList)) {
          idleConnections += socketList.length;
        }
      }

      result.push({
        backendId: key,
        totalConnections,
        activeConnections: totalConnections - idleConnections,
        idleConnections,
        totalRequests: stats.requests,
        reuseCount: stats.reuses,
      });
    }

    return result;
  }

  /**
   * Get statistics for specific backend
   */
  getBackendStats(backendId: string): PoolStats | null {
    const allStats = this.getStats();
    return allStats.find(s => s.backendId.startsWith(backendId)) || null;
  }

  /**
   * Close all connections for a backend
   */
  closeBackend(backendId: string): void {
    const keysToClose: string[] = [];

    for (const key of Array.from(this.pools.keys())) {
      if (key.startsWith(backendId)) {
        keysToClose.push(key);
      }
    }

    for (const key of keysToClose) {
      const pooled = this.pools.get(key);
      if (pooled) {
        pooled.agent.destroy();
        this.pools.delete(key);
        this.stats.delete(key);

        logger.info('connection pool closed', {
          backendId: pooled.backendId,
        });
      }
    }
  }

  /**
   * Close all connections
   */
  closeAll(): void {
    for (const pooled of Array.from(this.pools.values())) {
      pooled.agent.destroy();
    }

    this.pools.clear();
    this.stats.clear();

    logger.info('all connection pools closed');
  }

  /**
   * Start periodic cleanup of idle connections
   */
  private startCleanup(): void {
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, this.config.maxIdleTime / 2); // Check at half the idle time
  }

  /**
   * Cleanup idle connections
   */
  private cleanup(): void {
    const now = Date.now();
    const keysToClose: string[] = [];

    for (const [key, pooled] of Array.from(this.pools.entries())) {
      const idleTime = now - pooled.lastUsed;

      // Close if idle too long and no active requests
      if (idleTime > this.config.maxIdleTime && pooled.activeRequests === 0) {
        keysToClose.push(key);
      }
    }

    if (keysToClose.length > 0) {
      logger.info('cleaning up idle connection pools', {
        count: keysToClose.length,
      });

      for (const key of keysToClose) {
        const pooled = this.pools.get(key);
        if (pooled) {
          pooled.agent.destroy();
          this.pools.delete(key);
          this.stats.delete(key);
        }
      }
    }
  }

  /**
   * Stop cleanup interval
   */
  destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }

    this.closeAll();
  }
}
