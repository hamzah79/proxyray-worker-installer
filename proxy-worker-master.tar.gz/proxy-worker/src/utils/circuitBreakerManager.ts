import { CircuitBreaker, CircuitBreakerOpenError } from './circuitBreaker';
import { CircuitBreakerConfig, CircuitState, CircuitStats } from '../config/circuitBreakerConfig';
import { logger } from '../observability/logger';

/**
 * Circuit Breaker Manager - manages circuit breakers for multiple backends
 */
export class CircuitBreakerManager {
  private breakers = new Map<string, CircuitBreaker>();

  constructor(private readonly config: CircuitBreakerConfig) {}

  /**
   * Get or create circuit breaker for backend
   */
  private getBreaker(backendId: string): CircuitBreaker {
    let breaker = this.breakers.get(backendId);
    
    if (!breaker) {
      breaker = new CircuitBreaker(backendId, this.config);
      this.breakers.set(backendId, breaker);
      
      logger.info('circuit breaker created', {
        backendId,
        config: this.config
      });
    }
    
    return breaker;
  }

  /**
   * Execute operation with circuit breaker protection
   * 
   * @param backendId Backend identifier
   * @param operation Operation to execute
   * @returns Result of operation
   * @throws CircuitBreakerOpenError if circuit is open
   */
  async execute<T>(backendId: string, operation: () => Promise<T>): Promise<T> {
    const breaker = this.getBreaker(backendId);
    return breaker.execute(operation);
  }

  /**
   * Check if backend circuit is open
   */
  isOpen(backendId: string): boolean {
    const breaker = this.breakers.get(backendId);
    return breaker ? breaker.isOpen() : false;
  }

  /**
   * Check if backend circuit is closed
   */
  isClosed(backendId: string): boolean {
    const breaker = this.breakers.get(backendId);
    return breaker ? breaker.isClosed() : true; // Default to closed if not exists
  }

  /**
   * Get circuit breaker state for backend
   */
  getState(backendId: string): CircuitState {
    const breaker = this.breakers.get(backendId);
    return breaker ? breaker.getState() : CircuitState.CLOSED;
  }

  /**
   * Get circuit breaker statistics for backend
   */
  getStats(backendId: string): CircuitStats | null {
    const breaker = this.breakers.get(backendId);
    return breaker ? breaker.getStats() : null;
  }

  /**
   * Get all circuit breaker statistics
   */
  getAllStats(): Map<string, CircuitStats> {
    const stats = new Map<string, CircuitStats>();
    
    for (const [backendId, breaker] of Array.from(this.breakers.entries())) {
      stats.set(backendId, breaker.getStats());
    }
    
    return stats;
  }

  /**
   * Get list of backends with open circuits
   */
  getOpenCircuits(): string[] {
    const openCircuits: string[] = [];
    
    for (const [backendId, breaker] of Array.from(this.breakers.entries())) {
      if (breaker.isOpen()) {
        openCircuits.push(backendId);
      }
    }
    
    return openCircuits;
  }

  /**
   * Get list of backends with half-open circuits
   */
  getHalfOpenCircuits(): string[] {
    const halfOpenCircuits: string[] = [];
    
    for (const [backendId, breaker] of Array.from(this.breakers.entries())) {
      if (breaker.isHalfOpen()) {
        halfOpenCircuits.push(backendId);
      }
    }
    
    return halfOpenCircuits;
  }

  /**
   * Reset circuit breaker for specific backend
   */
  reset(backendId: string): void {
    const breaker = this.breakers.get(backendId);
    if (breaker) {
      breaker.reset();
    }
  }

  /**
   * Reset all circuit breakers
   */
  resetAll(): void {
    logger.info('resetting all circuit breakers', {
      count: this.breakers.size
    });

    for (const breaker of Array.from(this.breakers.values())) {
      breaker.reset();
    }
  }

  /**
   * Get summary of circuit breaker states
   */
  getSummary(): {
    total: number;
    closed: number;
    open: number;
    halfOpen: number;
  } {
    let closed = 0;
    let open = 0;
    let halfOpen = 0;

    for (const breaker of Array.from(this.breakers.values())) {
      const state = breaker.getState();
      if (state === CircuitState.CLOSED) closed++;
      else if (state === CircuitState.OPEN) open++;
      else if (state === CircuitState.HALF_OPEN) halfOpen++;
    }

    return {
      total: this.breakers.size,
      closed,
      open,
      halfOpen
    };
  }

  /**
   * Check if CircuitBreakerOpenError
   */
  static isCircuitBreakerError(error: unknown): error is CircuitBreakerOpenError {
    return error instanceof CircuitBreakerOpenError;
  }
}
