import { RetryConfig } from '../config/retryConfig';
import { logger } from '../observability/logger';

/**
 * Error with backend information for retry exclusion
 */
export interface RetryableError extends Error {
  backendId?: string;
  statusCode?: number;
  code?: string;
  retryable?: boolean;
}

/**
 * Result of retry operation with metadata
 */
export interface RetryResult<T> {
  result: T;
  attempts: number;
  excludedBackends: Set<string>;
}

/**
 * Helper class for executing operations with automatic retry and exponential backoff
 */
export class RetryHelper {
  constructor(private readonly config: RetryConfig) {}

  /**
   * Execute an operation with automatic retry
   * 
   * @param operation Function to execute, receives attempt number and excluded backends
   * @param isRetryable Function to determine if error is retryable
   * @returns Result of the operation with retry metadata
   * @throws Last error if all retries fail
   */
  async executeWithRetry<T>(
    operation: (attempt: number, excludeBackends: Set<string>) => Promise<T>,
    isRetryable?: (error: RetryableError) => boolean
  ): Promise<RetryResult<T>> {
    const excludeBackends = new Set<string>();
    let lastError: RetryableError | null = null;

    for (let attempt = 0; attempt < this.config.maxAttempts; attempt++) {
      try {
        const result = await operation(attempt, excludeBackends);
        
        // Log successful retry
        if (attempt > 0) {
          logger.info('retry succeeded', {
            attempt,
            excludedBackends: Array.from(excludeBackends)
          });
        }
        
        return {
          result,
          attempts: attempt + 1,
          excludedBackends: excludeBackends
        };
      } catch (error: any) {
        lastError = error as RetryableError;
        
        // Check if this is the last attempt
        const isLastAttempt = attempt === this.config.maxAttempts - 1;
        
        // Check if error is retryable
        const shouldRetry = isRetryable 
          ? isRetryable(lastError)
          : this.isRetryableError(lastError);
        
        if (!shouldRetry || isLastAttempt) {
          logger.warn('retry failed, not retrying', {
            attempt,
            isLastAttempt,
            shouldRetry,
            error: lastError.message,
            code: lastError.code,
            statusCode: lastError.statusCode
          });
          throw lastError;
        }

        // Add failed backend to exclusion list
        if (lastError.backendId) {
          excludeBackends.add(lastError.backendId);
          logger.info('backend excluded from retry', {
            backendId: lastError.backendId,
            attempt,
            totalExcluded: excludeBackends.size
          });
        }

        // Calculate delay with exponential backoff and jitter
        const delay = this.calculateDelay(attempt);
        
        logger.info('retrying after delay', {
          attempt: attempt + 1,
          maxAttempts: this.config.maxAttempts,
          delayMs: delay,
          excludedBackends: Array.from(excludeBackends),
          error: lastError.message
        });

        await this.sleep(delay);
      }
    }

    // This should never be reached, but TypeScript needs it
    throw lastError || new Error('All retry attempts failed');
  }

  /**
   * Determine if an error is retryable based on configuration
   */
  private isRetryableError(error: RetryableError): boolean {
    // Check if explicitly marked as non-retryable
    if (error.retryable === false) {
      return false;
    }

    // Check HTTP status codes
    if (error.statusCode) {
      // Non-retryable status codes
      if (this.config.nonRetryableStatusCodes.includes(error.statusCode)) {
        return false;
      }
      
      // Retryable status codes
      if (this.config.retryableStatusCodes.includes(error.statusCode)) {
        return true;
      }
    }

    // Check network error codes
    if (error.code && this.config.retryableErrorCodes.includes(error.code)) {
      return true;
    }

    // Default: don't retry unknown errors
    return false;
  }

  /**
   * Calculate delay with exponential backoff and jitter
   * 
   * Formula: min(initialDelay * (multiplier ^ attempt), maxDelay) + jitter
   * Jitter: random value between -jitterFactor and +jitterFactor of the delay
   */
  private calculateDelay(attempt: number): number {
    // Calculate exponential delay
    const exponentialDelay = Math.min(
      this.config.initialDelayMs * Math.pow(this.config.backoffMultiplier, attempt),
      this.config.maxDelayMs
    );

    // Add jitter to prevent thundering herd problem
    // Jitter is a random value between -jitterFactor and +jitterFactor
    const jitterRange = exponentialDelay * this.config.jitterFactor;
    const jitter = jitterRange * (Math.random() * 2 - 1); // Random between -1 and 1
    
    const finalDelay = Math.max(0, Math.floor(exponentialDelay + jitter));
    
    return finalDelay;
  }

  /**
   * Sleep for specified milliseconds
   */
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Get retry statistics
   */
  getConfig(): RetryConfig {
    return { ...this.config };
  }
}
