import { CircuitBreakerConfig, CircuitState, CircuitStats } from '../config/circuitBreakerConfig';
import { logger } from '../observability/logger';

/**
 * Circuit Breaker Error - thrown when circuit is open
 */
export class CircuitBreakerOpenError extends Error {
  constructor(public readonly backendId: string, public readonly stats: CircuitStats) {
    super(`Circuit breaker is OPEN for backend ${backendId}`);
    this.name = 'CircuitBreakerOpenError';
  }
}

/**
 * Circuit Breaker - prevents cascade failures by failing fast when backend is unhealthy
 * 
 * States:
 * - CLOSED: Normal operation, all requests pass through
 * - OPEN: Circuit is open, all requests fail fast without hitting backend
 * - HALF_OPEN: Testing if backend recovered, limited requests pass through
 * 
 * State Transitions:
 * - CLOSED -> OPEN: When failure threshold exceeded
 * - OPEN -> HALF_OPEN: After open timeout expires
 * - HALF_OPEN -> CLOSED: When success threshold met
 * - HALF_OPEN -> OPEN: When any failure occurs
 */
export class CircuitBreaker {
  private state: CircuitState = CircuitState.CLOSED;
  private failures: number = 0;
  private successes: number = 0;
  private consecutiveFailures: number = 0;
  private consecutiveSuccesses: number = 0;
  private lastFailureTime: number | null = null;
  private lastSuccessTime: number | null = null;
  private lastStateChange: number = Date.now();
  private totalRequests: number = 0;
  private rejectedRequests: number = 0;
  private halfOpenRequests: number = 0;

  constructor(
    private readonly backendId: string,
    private readonly config: CircuitBreakerConfig
  ) {}

  /**
   * Check if request can proceed
   * @throws CircuitBreakerOpenError if circuit is open
   */
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    // Check circuit state before executing
    this.updateState();
    
    if (this.state === CircuitState.OPEN) {
      this.rejectedRequests++;
      throw new CircuitBreakerOpenError(this.backendId, this.getStats());
    }

    // In HALF_OPEN state, limit concurrent requests
    if (this.state === CircuitState.HALF_OPEN) {
      this.halfOpenRequests++;
      if (this.halfOpenRequests > 1) {
        // Only allow one request at a time in HALF_OPEN
        this.rejectedRequests++;
        throw new CircuitBreakerOpenError(this.backendId, this.getStats());
      }
    }

    this.totalRequests++;

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    } finally {
      if (this.state === CircuitState.HALF_OPEN) {
        this.halfOpenRequests--;
      }
    }
  }

  /**
   * Record successful request
   */
  private onSuccess(): void {
    this.successes++;
    this.consecutiveSuccesses++;
    this.consecutiveFailures = 0;
    this.lastSuccessTime = Date.now();

    if (this.state === CircuitState.HALF_OPEN) {
      logger.info('circuit breaker half-open success', {
        backendId: this.backendId,
        consecutiveSuccesses: this.consecutiveSuccesses,
        successThreshold: this.config.successThreshold
      });

      // Close circuit if success threshold met
      if (this.consecutiveSuccesses >= this.config.successThreshold) {
        this.transitionTo(CircuitState.CLOSED);
      }
    }
  }

  /**
   * Record failed request
   */
  private onFailure(): void {
    this.failures++;
    this.consecutiveFailures++;
    this.consecutiveSuccesses = 0;
    this.lastFailureTime = Date.now();

    if (this.state === CircuitState.HALF_OPEN) {
      // Any failure in HALF_OPEN immediately opens circuit
      logger.warn('circuit breaker half-open failure, reopening', {
        backendId: this.backendId
      });
      this.transitionTo(CircuitState.OPEN);
      return;
    }

    if (this.state === CircuitState.CLOSED) {
      // Check if we should open circuit
      const recentFailures = this.getRecentFailures();
      
      logger.info('circuit breaker failure recorded', {
        backendId: this.backendId,
        consecutiveFailures: this.consecutiveFailures,
        recentFailures,
        failureThreshold: this.config.failureThreshold,
        totalRequests: this.totalRequests,
        minimumRequests: this.config.minimumRequests
      });

      // Open circuit if failure threshold exceeded and minimum requests met
      if (
        this.totalRequests >= this.config.minimumRequests &&
        recentFailures >= this.config.failureThreshold
      ) {
        this.transitionTo(CircuitState.OPEN);
      }
    }
  }

  /**
   * Get number of failures in time window
   */
  private getRecentFailures(): number {
    if (!this.lastFailureTime) return 0;
    
    const now = Date.now();
    const windowStart = now - this.config.timeWindowMs;
    
    // If last failure is outside window, reset counter
    if (this.lastFailureTime < windowStart) {
      return 0;
    }
    
    // Return consecutive failures (simplified - in production, use sliding window)
    return this.consecutiveFailures;
  }

  /**
   * Update circuit state based on time
   */
  private updateState(): void {
    if (this.state === CircuitState.OPEN) {
      const now = Date.now();
      const timeSinceOpen = now - this.lastStateChange;
      
      // Transition to HALF_OPEN after timeout
      if (timeSinceOpen >= this.config.openTimeoutMs) {
        this.transitionTo(CircuitState.HALF_OPEN);
      }
    }
  }

  /**
   * Transition to new state
   */
  private transitionTo(newState: CircuitState): void {
    const oldState = this.state;
    this.state = newState;
    this.lastStateChange = Date.now();

    logger.info('circuit breaker state transition', {
      backendId: this.backendId,
      oldState,
      newState,
      stats: this.getStats()
    });

    // Reset counters on state change
    if (newState === CircuitState.CLOSED) {
      this.consecutiveFailures = 0;
      this.consecutiveSuccesses = 0;
      this.failures = 0;
      this.successes = 0;
      this.totalRequests = 0;
    } else if (newState === CircuitState.HALF_OPEN) {
      this.consecutiveSuccesses = 0;
      this.halfOpenRequests = 0;
    }
  }

  /**
   * Get current circuit breaker statistics
   */
  getStats(): CircuitStats {
    return {
      state: this.state,
      failures: this.failures,
      successes: this.successes,
      consecutiveFailures: this.consecutiveFailures,
      consecutiveSuccesses: this.consecutiveSuccesses,
      lastFailureTime: this.lastFailureTime,
      lastSuccessTime: this.lastSuccessTime,
      lastStateChange: this.lastStateChange,
      totalRequests: this.totalRequests,
      rejectedRequests: this.rejectedRequests
    };
  }

  /**
   * Get current state
   */
  getState(): CircuitState {
    this.updateState();
    return this.state;
  }

  /**
   * Check if circuit is open
   */
  isOpen(): boolean {
    this.updateState();
    return this.state === CircuitState.OPEN;
  }

  /**
   * Check if circuit is closed
   */
  isClosed(): boolean {
    this.updateState();
    return this.state === CircuitState.CLOSED;
  }

  /**
   * Check if circuit is half-open
   */
  isHalfOpen(): boolean {
    this.updateState();
    return this.state === CircuitState.HALF_OPEN;
  }

  /**
   * Manually reset circuit breaker (for testing/admin)
   */
  reset(): void {
    logger.info('circuit breaker manually reset', {
      backendId: this.backendId,
      oldState: this.state
    });

    this.state = CircuitState.CLOSED;
    this.failures = 0;
    this.successes = 0;
    this.consecutiveFailures = 0;
    this.consecutiveSuccesses = 0;
    this.lastFailureTime = null;
    this.lastSuccessTime = null;
    this.lastStateChange = Date.now();
    this.totalRequests = 0;
    this.rejectedRequests = 0;
    this.halfOpenRequests = 0;
  }
}
