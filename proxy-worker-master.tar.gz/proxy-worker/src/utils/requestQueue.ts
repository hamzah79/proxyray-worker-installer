import { RequestQueueConfig } from '../config/requestQueueConfig';
import { logger } from '../observability/logger';

/**
 * Request Queue Error - thrown when queue operations fail
 */
export class RequestQueueError extends Error {
  constructor(
    message: string,
    public readonly code: 'QUEUE_FULL' | 'TIMEOUT' | 'REJECTED'
  ) {
    super(message);
    this.name = 'RequestQueueError';
  }
}

/**
 * Queued Request
 */
interface QueuedRequest<T> {
  id: string;
  operation: () => Promise<T>;
  priority: number;
  resolve: (value: T) => void;
  reject: (error: Error) => void;
  enqueuedAt: number;
  timeoutHandle?: NodeJS.Timeout;
}

/**
 * Request Queue Statistics
 */
export interface QueueStats {
  queueSize: number;
  activeRequests: number;
  totalProcessed: number;
  totalRejected: number;
  totalTimeout: number;
  averageWaitTime: number;
  maxWaitTime: number;
  priorityDistribution: Record<number, number>;
}

/**
 * Request Queue Manager
 * Manages request queuing with priority and concurrency control
 */
export class RequestQueue {
  private readonly config: RequestQueueConfig;
  private readonly queues: Map<number, QueuedRequest<any>[]>;
  private activeRequests = 0;
  private totalProcessed = 0;
  private totalRejected = 0;
  private totalTimeout = 0;
  private waitTimes: number[] = [];
  private requestIdCounter = 0;

  constructor(config: RequestQueueConfig) {
    this.config = config;
    this.queues = new Map();

    // Initialize priority queues
    for (let i = 0; i < config.priorityLevels; i++) {
      this.queues.set(i, []);
    }
  }

  /**
   * Enqueue a request with optional priority
   * @param operation - Async operation to execute
   * @param priority - Priority level (0 = highest, priorityLevels-1 = lowest)
   */
  async enqueue<T>(operation: () => Promise<T>, priority: number = 0): Promise<T> {
    // Validate priority
    const normalizedPriority = this.config.enablePriority
      ? Math.min(this.config.priorityLevels - 1, Math.max(0, priority))
      : 0;

    // Check queue size
    const totalQueued = this.getTotalQueueSize();
    if (totalQueued >= this.config.maxQueueSize) {
      this.totalRejected++;
      throw new RequestQueueError(
        `Queue is full (${totalQueued}/${this.config.maxQueueSize})`,
        'QUEUE_FULL'
      );
    }

    return new Promise<T>((resolve, reject) => {
      const requestId = `req-${++this.requestIdCounter}`;
      const enqueuedAt = Date.now();

      const request: QueuedRequest<T> = {
        id: requestId,
        operation,
        priority: normalizedPriority,
        resolve,
        reject,
        enqueuedAt,
      };

      // Set timeout
      request.timeoutHandle = setTimeout(() => {
        this.removeRequest(request);
        this.totalTimeout++;
        reject(new RequestQueueError(
          `Request timeout after ${this.config.maxWaitTime}ms in queue`,
          'TIMEOUT'
        ));
      }, this.config.maxWaitTime);

      // Add to appropriate priority queue
      const queue = this.queues.get(normalizedPriority)!;
      queue.push(request);

      // Try to process immediately
      this.processNext();
    });
  }

  /**
   * Process next request from queue
   */
  private async processNext(): Promise<void> {
    // Check concurrency limit
    if (this.activeRequests >= this.config.concurrencyLimit) {
      return;
    }

    // Get next request (highest priority first)
    const request = this.dequeueNext();
    if (!request) {
      return;
    }

    // Clear timeout
    if (request.timeoutHandle) {
      clearTimeout(request.timeoutHandle);
    }

    // Track wait time
    const waitTime = Date.now() - request.enqueuedAt;
    this.waitTimes.push(waitTime);
    if (this.waitTimes.length > 100) {
      this.waitTimes.shift(); // Keep last 100 wait times
    }

    this.activeRequests++;

    try {
      const result = await request.operation();
      request.resolve(result);
      this.totalProcessed++;
    } catch (error) {
      request.reject(error as Error);
      this.totalRejected++;
    } finally {
      this.activeRequests--;
      
      // Process next request
      setImmediate(() => this.processNext());
    }
  }

  /**
   * Dequeue next request (highest priority first)
   */
  private dequeueNext(): QueuedRequest<any> | null {
    // Check priority queues from highest to lowest
    for (let priority = 0; priority < this.config.priorityLevels; priority++) {
      const queue = this.queues.get(priority)!;
      if (queue.length > 0) {
        return queue.shift()!;
      }
    }

    return null;
  }

  /**
   * Remove request from queue
   */
  private removeRequest(request: QueuedRequest<any>): void {
    const queue = this.queues.get(request.priority)!;
    const index = queue.findIndex(r => r.id === request.id);
    if (index !== -1) {
      queue.splice(index, 1);
    }

    if (request.timeoutHandle) {
      clearTimeout(request.timeoutHandle);
    }
  }

  /**
   * Get total queue size across all priorities
   */
  private getTotalQueueSize(): number {
    let total = 0;
    for (const queue of Array.from(this.queues.values())) {
      total += queue.length;
    }
    return total;
  }

  /**
   * Get queue statistics
   */
  getStats(): QueueStats {
    const priorityDistribution: Record<number, number> = {};
    let queueSize = 0;

    for (const [priority, queue] of Array.from(this.queues.entries())) {
      priorityDistribution[priority] = queue.length;
      queueSize += queue.length;
    }

    const averageWaitTime = this.waitTimes.length > 0
      ? this.waitTimes.reduce((sum, t) => sum + t, 0) / this.waitTimes.length
      : 0;

    const maxWaitTime = this.waitTimes.length > 0
      ? Math.max(...this.waitTimes)
      : 0;

    return {
      queueSize,
      activeRequests: this.activeRequests,
      totalProcessed: this.totalProcessed,
      totalRejected: this.totalRejected,
      totalTimeout: this.totalTimeout,
      averageWaitTime,
      maxWaitTime,
      priorityDistribution,
    };
  }

  /**
   * Clear all queued requests
   */
  clear(): void {
    for (const queue of Array.from(this.queues.values())) {
      for (const request of queue) {
        if (request.timeoutHandle) {
          clearTimeout(request.timeoutHandle);
        }
        request.reject(new RequestQueueError('Queue cleared', 'REJECTED'));
      }
      queue.length = 0;
    }

    logger.info('request queue cleared');
  }

  /**
   * Destroy queue and reject all pending requests
   */
  destroy(): void {
    this.clear();
    logger.info('request queue destroyed');
  }
}
