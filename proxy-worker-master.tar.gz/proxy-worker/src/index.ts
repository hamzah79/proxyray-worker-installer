﻿import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { createHash, randomBytes } from "node:crypto";

import { CredentialStore } from "./auth/credentialStore";
import { hashPassword, verifyPassword } from "./auth/password";
import { SessionStore, UserSession } from "./auth/sessionStore";
import { BillingService, CheckoutPaymentMethod } from "./billing/billingService";
import { ProxyAccessService } from "./billing/proxyAccessService";
import { PakasirProvider } from "./billing/pakasirProvider";
import { AppConfig, ServerMode, loadConfig } from "./config";
import { RuntimeStateStore } from "./config/runtimeStateStore";
import { AuditLogsRepository } from "./db/repositories/auditLogsRepository";
import { DatabaseClient, runPendingSqlMigrations } from "./db/client";
import { InvoicesRepository } from "./db/repositories/invoicesRepository";
import { PaymentEventsRepository } from "./db/repositories/paymentEventsRepository";
import { PaymentChannelsRepository } from "./db/repositories/paymentChannelsRepository";
import { PakasirTransactionsRepository } from "./db/repositories/pakasirTransactionsRepository";
import { PlansRepository } from "./db/repositories/plansRepository";
import {
  InAppNotificationAudience,
  InAppNotificationsRepository,
  InAppNotificationType
} from "./db/repositories/inAppNotificationsRepository";
import { VouchersRepository } from "./db/repositories/vouchersRepository";
import { VoucherRedemptionsRepository } from "./db/repositories/voucherRedemptionsRepository";
import { AffiliateCommissionsRepository } from "./db/repositories/affiliateCommissionsRepository";
import { SupportIntegrationsRepository, SupportIntegrationProvider } from "./db/repositories/supportIntegrationsRepository";
import {
  SupportTicketCategory,
  SupportTicketPriority,
  SupportTicketsRepository,
  SupportTicketStatus
} from "./db/repositories/supportTicketsRepository";
import { SubscriptionsRepository } from "./db/repositories/subscriptionsRepository";
import { UsagePeriodsRepository } from "./db/repositories/usagePeriodsRepository";
import { UsersRepository } from "./db/repositories/usersRepository";
import { RedisWorkerLeader, SingleNodeWorkerLeader } from "./distributed/workerLeader";
import { HealthMonitor } from "./health/healthMonitor";
import { FixedWindowRateLimiter, RateLimiter, RedisFixedWindowRateLimiter } from "./http/rateLimiter";
import { NotificationService } from "./notifications/notificationService";
import { OutboxWorker } from "./notifications/outboxWorker";
import { OutboxRepository } from "./notifications/outboxRepository";
import { GoogleWorkspaceSmtpProvider } from "./notifications/providers/googleWorkspaceSmtp";
import { NoopEmailProvider } from "./notifications/providers/noopEmailProvider";
import { logger } from "./observability/logger";
import { metricsCollector } from "./observability/metrics";
import { AlertManager } from "./observability/alerts";
import { HttpGateway } from "./proxy/httpGateway";
import { RotatingBalancer } from "./proxy/balancer";
import { SocksGateway } from "./proxy/socksGateway";
import { TorManager } from "./tor/torManager";
import { createRedisClient } from "./cache/redisClient";
import { WorkerAgent } from "./worker/workerAgent";
import { WorkerRegistry } from "./master/workerRegistry";
import { CommandDispatcher, CommandAction } from "./master/commandDispatcher";
import { SmartRouter } from "./master/smartRouter";
import { TorBackend } from "./types";
import { MetricsCollector } from "./observability/metricsCollector";
import { UsageTracker } from "./billing/usageTracker";
import { parseProxyHeaders, buildProxyResponseHeaders } from "./proxy/proxyHeaders";
import * as ApiController from "./api/v1/apiController";
import * as MonitoringController from "./api/v1/monitoringController";

async function readJsonBody(req: http.IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on("data", (chunk: Buffer) => chunks.push(chunk));
    req.on("end", () => {
      try {
        if (chunks.length === 0) {
          resolve({});
          return;
        }
        const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8")) as Record<string, unknown>;
        resolve(parsed);
      } catch (error) {
        reject(error);
      }
    });
    req.on("error", reject);
  });
}

function writeJson(res: http.ServerResponse, statusCode: number, body: unknown): void {
  res.writeHead(statusCode, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
}

function isAdminAuthorized(req: http.IncomingMessage, token: string): boolean {
  const headerToken = req.headers["x-admin-token"];
  if (typeof headerToken !== "string") return false;
  return headerToken === token;
}

function getBearerToken(req: http.IncomingMessage): string {
  const value = req.headers.authorization;
  if (!value || typeof value !== "string") return "";
  const [scheme, token] = value.split(" ");
  if (!scheme || !token || scheme.toLowerCase() !== "bearer") return "";
  return token.trim();
}

function getUserSession(req: http.IncomingMessage, sessions: SessionStore): UserSession | null {
  const token = getBearerToken(req);
  if (!token) return null;
  return sessions.getSession(token);
}

function isUniqueViolation(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  return "code" in error && (error as { code?: string }).code === "23505";
}

function isBillingEnabled(db: DatabaseClient | null, users: UsersRepository | null, plans: PlansRepository | null): boolean {
  return Boolean(db && users && plans);
}

function parseCheckoutPaymentMethod(value: unknown): CheckoutPaymentMethod | null {
  const valid: CheckoutPaymentMethod[] = [
    "paypal",
    "bank_transfer",
    "pakasir_qris",
    "pakasir_va_bni",
    "pakasir_va_bri",
    "pakasir_va_cimb",
    "pakasir_va_maybank",
    "pakasir_va_permata",
    "pakasir_va_bnc",
    "pakasir_va_atm",
    "pakasir_va_sampoerna",
    "pakasir_va_artha",
    "pakasir_paypal",
  ];

  if (!value || typeof value !== "string") {
    return null;
  }

  const normalizedValue = value.toLowerCase() as CheckoutPaymentMethod;
  return valid.includes(normalizedValue) ? normalizedValue : null;
}

function isPaypalWebhookAuthorized(req: http.IncomingMessage, expectedToken: string): boolean {
  if (!expectedToken) {
    return true;
  }

  const signature = req.headers["x-paypal-signature"];
  return typeof signature === "string" && signature === expectedToken;
}

function getClientIp(req: http.IncomingMessage): string | null {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.trim()) {
    return forwarded.split(",")[0].trim();
  }

  return req.socket.remoteAddress ?? null;
}

function normalizeIp(rawIp: string | null | undefined): string | null {
  if (!rawIp || typeof rawIp !== "string") {
    return null;
  }

  const value = rawIp.trim();
  if (!value) {
    return null;
  }

  return value.startsWith("::ffff:") ? value.slice(7) : value;
}

function buildTorCountryOptions(backends: TorBackend[]): Array<{ code: string; name: string; count: number }> {
  const countries = new Map<string, { code: string; name: string; count: number }>();

  for (const backend of backends) {
    const code = typeof backend.countryCode === "string" ? backend.countryCode.trim().toUpperCase() : "";
    if (!code || !/^[A-Z]{2,3}$/.test(code)) {
      continue;
    }

    const name = typeof backend.countryName === "string" && backend.countryName.trim() ? backend.countryName.trim() : code;
    const existing = countries.get(code);
    if (existing) {
      existing.count += 1;
      if (existing.name === existing.code && name !== code) {
        existing.name = name;
      }
      continue;
    }

    countries.set(code, { code, name, count: 1 });
  }

  return Array.from(countries.values()).sort((left, right) => left.name.localeCompare(right.name));
}

function getProxyHost(req: http.IncomingMessage, fallbackHost: string): string {
  const hostHeader = req.headers.host;
  if (!hostHeader || typeof hostHeader !== "string") {
    return fallbackHost;
  }

  const host = hostHeader.split(":")[0]?.trim();
  return host || fallbackHost;
}

function getRequestBaseUrl(req: http.IncomingMessage): string {
  const forwardedProto = req.headers["x-forwarded-proto"];
  const forwardedHost = req.headers["x-forwarded-host"];
  const hostHeader = req.headers.host;

  const protocol = typeof forwardedProto === "string" && forwardedProto.trim()
    ? forwardedProto.split(",")[0].trim()
    : "http";
  const host = typeof forwardedHost === "string" && forwardedHost.trim()
    ? forwardedHost.split(",")[0].trim()
    : typeof hostHeader === "string"
      ? hostHeader.trim()
      : "localhost:9090";

  return `${protocol}://${host}`;
}

function resolveCheckoutAppBaseUrl(config: AppConfig, req: http.IncomingMessage): string {
  const configured = (config.appBaseUrl || "").trim();
  if (configured && !configured.includes("localhost")) {
    return configured;
  }

  return getRequestBaseUrl(req);
}

const SUPPORT_TICKET_CATEGORIES: SupportTicketCategory[] = ["general", "billing", "technical", "account", "abuse", "other"];
const SUPPORT_TICKET_PRIORITIES: SupportTicketPriority[] = ["low", "medium", "high", "urgent"];
const SUPPORT_TICKET_STATUSES: SupportTicketStatus[] = ["open", "in_progress", "waiting_customer", "resolved", "closed"];
const IN_APP_NOTIFICATION_TYPES: InAppNotificationType[] = ["info", "success", "warn", "error"];
const IN_APP_NOTIFICATION_AUDIENCES: InAppNotificationAudience[] = ["all", "user", "admin"];

function parseSupportTicketCategory(value: unknown, fallback: SupportTicketCategory = "general"): SupportTicketCategory {
  if (typeof value !== "string") {
    return fallback;
  }

  const normalized = value.trim().toLowerCase();
  return SUPPORT_TICKET_CATEGORIES.includes(normalized as SupportTicketCategory)
    ? (normalized as SupportTicketCategory)
    : fallback;
}

function parseSupportTicketPriority(value: unknown, fallback: SupportTicketPriority = "medium"): SupportTicketPriority {
  if (typeof value !== "string") {
    return fallback;
  }

  const normalized = value.trim().toLowerCase();
  return SUPPORT_TICKET_PRIORITIES.includes(normalized as SupportTicketPriority)
    ? (normalized as SupportTicketPriority)
    : fallback;
}

function parseSupportTicketStatus(value: unknown): SupportTicketStatus | null {
  if (typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toLowerCase();
  return SUPPORT_TICKET_STATUSES.includes(normalized as SupportTicketStatus)
    ? (normalized as SupportTicketStatus)
    : null;
}

function parseInAppNotificationType(value: unknown, fallback: InAppNotificationType = "info"): InAppNotificationType {
  if (typeof value !== "string") {
    return fallback;
  }

  const normalized = value.trim().toLowerCase() as InAppNotificationType;
  return IN_APP_NOTIFICATION_TYPES.includes(normalized) ? normalized : fallback;
}

function parseInAppNotificationAudience(
  value: unknown,
  fallback: InAppNotificationAudience = "all"
): InAppNotificationAudience {
  if (typeof value !== "string") {
    return fallback;
  }

  const normalized = value.trim().toLowerCase() as InAppNotificationAudience;
  return IN_APP_NOTIFICATION_AUDIENCES.includes(normalized) ? normalized : fallback;
}

function parseBooleanInput(value: unknown, fallback: boolean): boolean {
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    if (normalized === "true") {
      return true;
    }
    if (normalized === "false") {
      return false;
    }
  }
  return fallback;
}

function parseTorRoutingMode(value: unknown): "random" | "sticky" | "pinned-country" {
  if (typeof value !== "string") {
    return "random";
  }

  const normalized = value.trim().toLowerCase();
  return normalized === "sticky" || normalized === "pinned-country" ? normalized : "random";
}

function parseCountryCodeInput(value: unknown): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toUpperCase();
  return /^[A-Z]{2,3}$/.test(normalized) ? normalized : null;
}

function parseWeightPercent(value: unknown, fallback = 70): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }

  const rounded = Math.round(parsed);
  if (rounded < 1) {
    return 1;
  }

  if (rounded > 100) {
    return 100;
  }

  return rounded;
}

function sanitizeTicketText(value: unknown, maxLength: number): string {
  if (typeof value !== "string") {
    return "";
  }

  const normalized = value.replace(/\r\n/g, "\n").trim();
  return normalized.length > maxLength ? normalized.slice(0, maxLength) : normalized;
}

function parseStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return Array.from(
    new Set(
      value
        .map((item) => (typeof item === "string" ? item.trim() : ""))
        .filter((item) => item.length > 0)
    )
  );
}

function parseWhitelistIpLimit(value: unknown): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) {
    return 0;
  }

  return parsed;
}

function normalizeProxyDomain(value: unknown): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toLowerCase();
  if (!normalized || !normalized.includes(".")) {
    return null;
  }

  if (!/^[a-z0-9.-]+$/.test(normalized)) {
    return null;
  }

  if (normalized.startsWith(".") || normalized.endsWith(".")) {
    return null;
  }

  return normalized;
}

function normalizeProxyIpHost(value: unknown): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const normalized = value.trim().toLowerCase();
  if (!normalized) {
    return null;
  }

  if (!/^[a-z0-9.-]+$/.test(normalized)) {
    return null;
  }

  return normalized;
}

function parseDateInputToUtcIso(value: unknown, kind: "start" | "end"): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return trimmed;
  }

  return kind === "start"
    ? `${trimmed}T00:00:00.000Z`
    : `${trimmed}T23:59:59.999Z`;
}

function renderSupportTemplate(template: string | null, payload: Record<string, string>): string {
  const baseTemplate = template && template.trim()
    ? template
    : "[Ticket {{ticketId}}] {{subject}}\nKategori: {{category}}\nPrioritas: {{priority}}\nStatus: {{status}}\nUser: {{username}}\nPesan: {{message}}";

  return baseTemplate.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_match, key: string) => payload[key] ?? "");
}

function normalizeWhatsappPhoneNumber(phoneNumber: string): string {
  const digits = phoneNumber.replace(/\D/g, "");
  if (!digits) {
    return "";
  }

  if (digits.startsWith("0")) {
    return `62${digits.slice(1)}`;
  }

  return digits;
}

function buildWhatsappClickToChatUrl(phoneNumber: string, message: string): string | null {
  const normalizedPhone = normalizeWhatsappPhoneNumber(phoneNumber);
  if (!normalizedPhone) {
    return null;
  }

  return `https://wa.me/${normalizedPhone}?text=${encodeURIComponent(message)}`;
}

function normalizeReferralCode(value: unknown): string {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 24);
}

function buildReferralCode(username: string): string {
  const base = username
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 8) || "USER";
  const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${base}${suffix}`;
}

function isValidEmail(value: string): boolean {
  return /^\S+@\S+\.\S+$/.test(value);
}

function hashToken(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

function generateEmailVerificationToken(): string {
  return randomBytes(32).toString("hex");
}

function buildEmailVerificationUrl(config: AppConfig, req: http.IncomingMessage, token: string): string {
  const configured = (config.appBaseUrl || "").trim();
  const baseUrl = configured || getRequestBaseUrl(req);
  return `${baseUrl}/public/api/auth/verify-email?token=${encodeURIComponent(token)}`;
}

async function verifyTurnstileToken(config: AppConfig, token: string, remoteIp: string | null): Promise<boolean> {
  if (!config.turnstileEnabled || !config.turnstileSecretKey) {
    return true;
  }

  if (!token.trim()) {
    return false;
  }

  try {
    const payload = new URLSearchParams();
    payload.set("secret", config.turnstileSecretKey);
    payload.set("response", token.trim());
    if (remoteIp) {
      payload.set("remoteip", remoteIp);
    }

    const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: payload.toString()
    });

    if (!response.ok) {
      return false;
    }

    const data = await response.json() as { success?: boolean };
    return Boolean(data.success);
  } catch {
    return false;
  }
}

async function sendTelegramMessage(botToken: string, chatId: string, text: string): Promise<void> {
  const response = await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/sendMessage`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      disable_web_page_preview: true
    })
  });

  if (!response.ok) {
    const responseText = await response.text();
    throw new Error(`telegram_send_failed:${response.status}:${responseText}`);
  }
}

async function dispatchSupportIntegrations(params: {
  integrationsRepo: SupportIntegrationsRepository | null;
  loggerContext: { ticketId: string; eventType: string };
  ticket: {
    id: string;
    category: SupportTicketCategory;
    priority: SupportTicketPriority;
    status: SupportTicketStatus;
    subject: string;
  };
  username: string;
  message: string;
}): Promise<{ telegramSent: number; whatsappLinks: Array<{ integrationId: string; name: string; url: string }> }> {
  if (!params.integrationsRepo) {
    return { telegramSent: 0, whatsappLinks: [] };
  }

  const matches = await params.integrationsRepo.listActiveMatching({
    category: params.ticket.category,
    priority: params.ticket.priority,
    status: params.ticket.status
  });

  let telegramSent = 0;
  const whatsappLinks: Array<{ integrationId: string; name: string; url: string }> = [];

  for (const integration of matches) {
    const renderedMessage = renderSupportTemplate(integration.message_template, {
      ticketId: params.ticket.id,
      subject: params.ticket.subject,
      category: params.ticket.category,
      priority: params.ticket.priority,
      status: params.ticket.status,
      username: params.username,
      message: params.message
    });

    if (integration.provider === "telegram" && integration.telegram_bot_token && integration.telegram_chat_id) {
      try {
        await sendTelegramMessage(integration.telegram_bot_token, integration.telegram_chat_id, renderedMessage);
        telegramSent += 1;
      } catch (error) {
        logger.warn("failed to send support telegram notification", {
          error: String(error),
          integrationId: integration.id,
          ...params.loggerContext
        });
      }
    }

    if (integration.provider === "whatsapp_click_to_chat" && integration.whatsapp_phone_number) {
      const url = buildWhatsappClickToChatUrl(integration.whatsapp_phone_number, renderedMessage);
      if (url) {
        whatsappLinks.push({
          integrationId: integration.id,
          name: integration.name,
          url
        });
      }
    }
  }

  return { telegramSent, whatsappLinks };
}

type PublicPaymentMethod = {
  code: CheckoutPaymentMethod;
  label: string;
  provider: "bank_transfer" | "paypal" | "pakasir";
  enabled: boolean;
  icon: string;
  group: "bank" | "wallet" | "paypal";
};

function buildPublicPaymentMethods(config: AppConfig): { methods: PublicPaymentMethod[]; pakasirReady: boolean } {
  const pakasirReady = config.pakasirEnabled && Boolean(config.pakasirSlug) && Boolean(config.pakasirApikey);
  const methodEnabled = (methodCode: CheckoutPaymentMethod): boolean => {
    if (!pakasirReady) {
      return false;
    }
    return config.pakasirEnabledMethods.has(methodCode);
  };

  const methods: PublicPaymentMethod[] = [
    { code: "bank_transfer", label: "Bank Transfer", provider: "bank_transfer", enabled: true, icon: "BT", group: "bank" },
    { code: "paypal", label: "PayPal", provider: "paypal", enabled: true, icon: "PP", group: "paypal" },
    { code: "pakasir_qris", label: "QRIS", provider: "pakasir", enabled: methodEnabled("pakasir_qris"), icon: "QR", group: "wallet" },
    { code: "pakasir_va_bni", label: "VA BNI", provider: "pakasir", enabled: methodEnabled("pakasir_va_bni"), icon: "BNI", group: "bank" },
    { code: "pakasir_va_bri", label: "VA BRI", provider: "pakasir", enabled: methodEnabled("pakasir_va_bri"), icon: "BRI", group: "bank" },
    { code: "pakasir_va_cimb", label: "VA CIMB Niaga", provider: "pakasir", enabled: methodEnabled("pakasir_va_cimb"), icon: "CIMB", group: "bank" },
    { code: "pakasir_va_maybank", label: "VA Maybank", provider: "pakasir", enabled: methodEnabled("pakasir_va_maybank"), icon: "MAY", group: "bank" },
    { code: "pakasir_va_permata", label: "VA Permata", provider: "pakasir", enabled: methodEnabled("pakasir_va_permata"), icon: "PRM", group: "bank" },
    { code: "pakasir_va_bnc", label: "VA BNC", provider: "pakasir", enabled: methodEnabled("pakasir_va_bnc"), icon: "BNC", group: "bank" },
    { code: "pakasir_va_atm", label: "VA ATM Bersama", provider: "pakasir", enabled: methodEnabled("pakasir_va_atm"), icon: "ATM", group: "bank" },
    { code: "pakasir_va_sampoerna", label: "VA Sampoerna", provider: "pakasir", enabled: methodEnabled("pakasir_va_sampoerna"), icon: "SMP", group: "bank" },
    { code: "pakasir_va_artha", label: "VA Artha Graha", provider: "pakasir", enabled: methodEnabled("pakasir_va_artha"), icon: "ART", group: "bank" },
    { code: "pakasir_paypal", label: "PayPal", provider: "pakasir", enabled: false, icon: "PP", group: "paypal" }
  ];

  return { methods, pakasirReady };
}

function estimateFeeCents(methodCode: CheckoutPaymentMethod, amountCents: number): number {
  if (methodCode === "bank_transfer") {
    return 0;
  }

  if (methodCode === "paypal" || methodCode === "pakasir_paypal") {
    return Math.max(0, Math.ceil(amountCents * 0.039) + 3000);
  }

  if (methodCode === "pakasir_qris") {
    return Math.max(0, Math.ceil(amountCents * 0.007));
  }

  if (methodCode.startsWith("pakasir_va_")) {
    return Math.max(0, Math.ceil(amountCents * 0.0045) + 450);
  }

  return Math.max(0, Math.ceil(amountCents * 0.01));
}

function buildRelayConnectivitySummary(backends: TorBackend[]): {
  totalRelays: number;
  connectedRelays: number;
  disconnectedRelays: number;
  connectedCountries: number;
  updatedAt: string;
  countries: Array<{ countryCode: string; countryName: string; relayCount: number; healthyCount: number }>;
} {
  const countryMap = new Map<string, { countryCode: string; countryName: string; relayCount: number; healthyCount: number }>();

  for (const backend of backends) {
    const countryCode = (backend.countryCode || "XX").toUpperCase();
    const countryName = backend.countryName || (countryCode === "XX" ? "Unknown" : countryCode);
    const existing = countryMap.get(countryCode) || {
      countryCode,
      countryName,
      relayCount: 0,
      healthyCount: 0
    };

    existing.relayCount += 1;
    if (backend.healthy) {
      existing.healthyCount += 1;
    }

    countryMap.set(countryCode, existing);
  }

  const countries = Array.from(countryMap.values()).sort((a, b) => {
    if (b.healthyCount !== a.healthyCount) {
      return b.healthyCount - a.healthyCount;
    }
    return b.relayCount - a.relayCount;
  });

  const connectedRelays = backends.filter((backend) => backend.healthy).length;

  return {
    totalRelays: backends.length,
    connectedRelays,
    disconnectedRelays: Math.max(0, backends.length - connectedRelays),
    connectedCountries: countries.filter((item) => item.healthyCount > 0).length,
    updatedAt: new Date().toISOString(),
    countries
  };
}

async function start(): Promise<void> {
  const config = loadConfig();
  const isWorkerMode = config.serverMode === "worker";
  const isMasterMode = config.serverMode === "master";

  logger.info("server starting", {
    serverMode: config.serverMode,
    serverId: config.serverId,
    serverRegion: config.serverRegion || "(not set)",
    publicHost: config.publicHost || "(not set)"
  });

  if (isWorkerMode) {
    if (!config.masterDatabaseUrl && !config.databaseUrl) {
      logger.warn("worker mode: no MASTER_DATABASE_URL or DATABASE_URL set, database features disabled");
    }
    if (!config.masterRedisUrl && !config.redisUrl) {
      logger.warn("worker mode: no MASTER_REDIS_URL or REDIS_URL set, shared state disabled");
    }
  }

  // In worker mode, prefer master URLs; in master/standalone, use local URLs
  const effectiveDatabaseUrl = isWorkerMode
    ? (config.masterDatabaseUrl || config.databaseUrl)
    : config.databaseUrl;
  const effectiveRedisUrl = isWorkerMode
    ? (config.masterRedisUrl || config.redisUrl)
    : config.redisUrl;

  if (config.enforceStrongSecrets && !isWorkerMode) {
    const weakAdminToken = config.adminToken === "change-me-admin-token";
    const weakPaypalToken = !config.paypalWebhookToken;
    if (weakAdminToken || weakPaypalToken) {
      throw new Error("strong secret enforcement failed: set ADMIN_TOKEN and PAYPAL_WEBHOOK_TOKEN");
    }
  } else if (!isWorkerMode) {
    if (config.adminToken === "change-me-admin-token") {
      logger.warn("ADMIN_TOKEN still uses default value");
    }
  }

  const redis = await createRedisClient(effectiveRedisUrl);
  const useRedisLimiter = Boolean(redis && config.enableRedisRateLimiter);
  const publicLimiter: RateLimiter = useRedisLimiter
    ? new RedisFixedWindowRateLimiter(redis!, config.apiRateLimitWindowMs, config.apiRateLimitPublicMax, config.redisKeyPrefix)
    : new FixedWindowRateLimiter(config.apiRateLimitWindowMs, config.apiRateLimitPublicMax);
  const userLimiter: RateLimiter = useRedisLimiter
    ? new RedisFixedWindowRateLimiter(redis!, config.apiRateLimitWindowMs, config.apiRateLimitUserMax, config.redisKeyPrefix)
    : new FixedWindowRateLimiter(config.apiRateLimitWindowMs, config.apiRateLimitUserMax);
  const adminLimiter: RateLimiter = useRedisLimiter
    ? new RedisFixedWindowRateLimiter(redis!, config.apiRateLimitWindowMs, config.apiRateLimitAdminMax, config.redisKeyPrefix)
    : new FixedWindowRateLimiter(config.apiRateLimitWindowMs, config.apiRateLimitAdminMax);
  const metrics = {
    requests: 0,
    rateLimitHits: {
      public: 0,
      user: 0,
      admin: 0
    }
  };
  const sessionSecret = (config as { authSessionSecret?: string; adminToken: string }).authSessionSecret ?? config.adminToken;
  const sessions = new SessionStore(config.authSessionTtlHours * 60 * 60 * 1000, sessionSecret);

  let db: DatabaseClient | null = null;
  let usersRepo: UsersRepository | null = null;
  let plansRepo: PlansRepository | null = null;
  let subscriptionsRepo: SubscriptionsRepository | null = null;
  let invoicesRepo: InvoicesRepository | null = null;
  let paymentEventsRepo: PaymentEventsRepository | null = null;
  let paymentChannelsRepo: PaymentChannelsRepository | null = null;
  let vouchersRepo: VouchersRepository | null = null;
  let voucherRedemptionsRepo: VoucherRedemptionsRepository | null = null;
  let affiliateCommissionsRepo: AffiliateCommissionsRepository | null = null;
  let pakasirTransactionsRepo: PakasirTransactionsRepository | null = null;
  let supportTicketsRepo: SupportTicketsRepository | null = null;
  let supportIntegrationsRepo: SupportIntegrationsRepository | null = null;
  let usagePeriodsRepo: UsagePeriodsRepository | null = null;
  let auditLogsRepo: AuditLogsRepository | null = null;
  let inAppNotificationsRepo: InAppNotificationsRepository | null = null;
  let billingService: BillingService | null = null;
  let proxyAccessService: ProxyAccessService | null = null;
  let notificationService: NotificationService | null = null;
  let outboxWorker: OutboxWorker | null = null;
  let pakasirProvider: PakasirProvider | null = null;
  let canRunDistributedWorker: () => Promise<boolean> = async () => true;

  const dbUrl = effectiveDatabaseUrl || config.databaseUrl;
  if (dbUrl) {
    db = new DatabaseClient(dbUrl, { readOnly: isWorkerMode });
    if (config.autoMigrate && !isWorkerMode) {
      await runPendingSqlMigrations(db, [
        "src/db/migrations/001_core.sql",
        "src/db/migrations/002_ops.sql",
        "src/db/migrations/003_notifications.sql",
        "src/db/migrations/004_payment_channels.sql",
        "src/db/migrations/005_pakasir_transactions.sql",
        "src/db/migrations/006_support_chat.sql",
        "src/db/migrations/007_voucher_trial_affiliate.sql",
        "src/db/migrations/008_plan_ip_whitelist.sql",
        "src/db/migrations/009_plan_whitelist_ip_limit_fix.sql",
        "src/db/migrations/010_user_profile_payout.sql",
        "src/db/migrations/011_email_verification.sql",
        "src/db/migrations/011_plan_billing_period_weekly.sql",
        "src/db/migrations/012_in_app_notifications.sql"
      ]);
    }

    usersRepo = new UsersRepository(db);
    plansRepo = new PlansRepository(db);
    subscriptionsRepo = new SubscriptionsRepository(db);
    invoicesRepo = new InvoicesRepository(db);
    paymentEventsRepo = new PaymentEventsRepository(db);
    paymentChannelsRepo = new PaymentChannelsRepository(db);
    vouchersRepo = new VouchersRepository(db);
    voucherRedemptionsRepo = new VoucherRedemptionsRepository(db);
    affiliateCommissionsRepo = new AffiliateCommissionsRepository(db);
    pakasirTransactionsRepo = new PakasirTransactionsRepository(db);
    supportTicketsRepo = new SupportTicketsRepository(db);
    supportIntegrationsRepo = new SupportIntegrationsRepository(db);
    usagePeriodsRepo = new UsagePeriodsRepository(db);
    auditLogsRepo = new AuditLogsRepository(db);
    inAppNotificationsRepo = new InAppNotificationsRepository(db);

    // Initialize Pakasir provider
    if (config.pakasirEnabled && config.pakasirSlug && config.pakasirApikey) {
      pakasirProvider = new PakasirProvider({
        slug: config.pakasirSlug,
        apikey: config.pakasirApikey,
        enabled: true,
      });
    }

    billingService = new BillingService(
      config,
      plansRepo,
      subscriptionsRepo,
      invoicesRepo,
      paymentEventsRepo,
      paymentChannelsRepo,
      vouchersRepo,
      voucherRedemptionsRepo,
      usersRepo,
      affiliateCommissionsRepo,
      pakasirProvider,
      pakasirTransactionsRepo
    );
    proxyAccessService = new ProxyAccessService(usersRepo);

    const smtpConfigured = Boolean(config.smtpHost && config.smtpUser && config.smtpPass);
    const emailProvider = smtpConfigured
      ? new GoogleWorkspaceSmtpProvider({
          host: config.smtpHost,
          port: config.smtpPort,
          secure: config.smtpSecure,
          user: config.smtpUser,
          pass: config.smtpPass,
          fromEmail: config.emailFromAddress,
          fromName: config.emailFromName
        })
      : new NoopEmailProvider();

    notificationService = new NotificationService(new OutboxRepository(db), emailProvider);
    const workerLeader = redis
      ? new RedisWorkerLeader(redis, config.workerLeaderLockKey, config.workerLeaderLockTtlMs)
      : new SingleNodeWorkerLeader();
    canRunDistributedWorker = () => workerLeader.canRun();

    if (!isWorkerMode) {
      outboxWorker = new OutboxWorker(notificationService, config.notificationWorkerIntervalMs, config.notificationWorkerBatchSize, () =>
        workerLeader.canRun()
      );
      outboxWorker.start();

      await plansRepo.ensureDefaults();
      await paymentChannelsRepo.ensureDefaults();
    }
    logger.info("database mode enabled", { autoMigrate: config.autoMigrate, readOnly: isWorkerMode });
  } else {
    logger.warn("DATABASE_URL is empty, billing and user auth APIs are disabled");
  }

  const runtimeStateStore = new RuntimeStateStore(config);

  // Attach Redis backend for multi-server shared state
  if (redis) {
    runtimeStateStore.attachRedis(redis, config.redisKeyPrefix || "proxy");
    logger.info("multi-server shared state enabled via redis");
  }

  await runtimeStateStore.init();

  // Periodic sync from Redis — ensures workers pick up whitelist/user changes
  // made on master without neding a restart
  if (redis && runtimeStateStore.hasRedis()) {
    const SYNC_INTERVAL_MS = 10_000; // every 10 seconds
    setInterval(async () => {
      try {
        const synced = await runtimeStateStore.syncFromRedis();
        if (synced) {
          logger.info("runtime state synced from redis");
        }
      } catch (error) {
        logger.warn("runtime state redis sync failed", { error: String(error) });
      }
    }, SYNC_INTERVAL_MS);
    logger.info("runtime state periodic redis sync enabled", { intervalMs: SYNC_INTERVAL_MS });
  }

  const torManager = new TorManager(config);
  await torManager.start();

  const balancer = new RotatingBalancer(
    torManager.getBackends(),
    () => runtimeStateStore.getTorRoutingSnapshot(),
    (instanceId) => runtimeStateStore.getTorRoutingConfig(instanceId)
  );
  const credentials = new CredentialStore(runtimeStateStore, usersRepo);

  // Initialize metrics collector
  const metricsCollector = new MetricsCollector(
    10000, // maxRecords
    3600000 // windowMs (1 hour)
  );
  logger.info("metrics collector initialized");

  // Initialize usage tracker (requires database)
  const usageTracker = db ? new UsageTracker(db, 100, 30000) : null;
  if (usageTracker) {
    logger.info("usage tracker initialized");
  } else {
    logger.warn("usage tracker disabled (database not configured)");
  }

  const persistTrafficSample = async (sample: {
    username: string;
    requestsCountDelta: number;
    bytesInDelta: number;
    bytesOutDelta: number;
    peakConcurrent: number;
  }): Promise<void> => {
    if (!usersRepo || !usagePeriodsRepo) {
      return;
    }

    try {
      const profile = await usersRepo.findProxyAccessProfile(sample.username);
      if (!profile) {
        return;
      }

      await usagePeriodsRepo.upsertUsageSample({
        userId: profile.user_id,
        subscriptionId: profile.subscription_id,
        requestsCountDelta: sample.requestsCountDelta,
        bytesInDelta: sample.bytesInDelta,
        bytesOutDelta: sample.bytesOutDelta,
        peakConcurrent: sample.peakConcurrent
      });
    } catch (error) {
      logger.warn("failed to persist traffic sample", { error: String(error), username: sample.username });
    }
  };

  const resolveUserRoutingPreference = (username: string) => runtimeStateStore.getUserTorRoutingPreference(username);

  // Phase 8: resolveWorker callback — routes user to remote worker via SmartRouter
  const resolveWorkerForUser = async (username: string) => {
    if (!smartRouter) return null;
    try {
      const assignment = await smartRouter.resolve(username);
      if (!assignment) return null;
      if (assignment.workerId === config.serverId) return null;
      return {
        publicHost: assignment.publicHost,
        httpProxyPort: assignment.httpProxyPort,
        socksProxyPort: assignment.socksProxyPort,
      };
    } catch (err) {
      logger.warn("smart router resolve failed, falling back to local", { username, error: String(err) });
      return null;
    }
  };

  const httpGateway = new HttpGateway(config, credentials, balancer, proxyAccessService, resolveUserRoutingPreference, persistTrafficSample, resolveWorkerForUser, metricsCollector, usageTracker);
  const socksGateway = new SocksGateway(config, credentials, balancer, proxyAccessService, resolveUserRoutingPreference, persistTrafficSample, resolveWorkerForUser, metricsCollector, usageTracker);
  const healthMonitor = new HealthMonitor(config, torManager);
  const alertManager = new AlertManager(config);

  await Promise.all([httpGateway.listen(), socksGateway.listen()]);
  healthMonitor.start();
  alertManager.start();

  // --- Worker Agent & Registry (Multi-Server Phase 3) ---
  let workerAgent: WorkerAgent | null = null;
  let workerRegistry: WorkerRegistry | null = null;
  let commandDispatcher: CommandDispatcher | null = null;
  let smartRouter: SmartRouter | null = null;

  if (redis) {
    workerAgent = new WorkerAgent({
      redis,
      config,
      getBackends: () => torManager.getBackends(),
      getActiveConnections: () => {
        const state = runtimeStateStore.getSnapshot();
        let total = 0;
        for (const username of Object.keys(state.users)) {
          total += credentials.getActiveSessionCount(username);
        }
        return total;
      },
      heartbeatIntervalMs: 10_000,
      ttlSeconds: 30,
    });
    // --- Command handlers (Phase 7) ---
    workerAgent.onCommand("ping", async () => ({ ok: true, message: `pong from ${config.serverId}` }));
    workerAgent.onCommand("rotate_all", async () => {
      const backends = torManager.getBackends();
      let rotated = 0;
      for (const b of backends) { try { await torManager.signalNewnym(b); rotated++; } catch {} }
      return { ok: true, message: `rotated ${rotated}/${backends.length}` };
    });
    workerAgent.onCommand("update_config", async (cmd) => {
      const results: string[] = [];
      logger.info("update_config payload received", { payload: JSON.stringify(cmd.payload) });
      if (typeof cmd.payload.maxConcurrentPerUser === "number") {
        await runtimeStateStore.setMaxConcurrentPerUser(cmd.payload.maxConcurrentPerUser);
        results.push(`maxConcurrent=${cmd.payload.maxConcurrentPerUser}`);
      }
      // Exit node reconfiguration (only if exitNodes is explicitly provided)
      if (cmd.payload.exitNodes !== undefined) {
        const exitNodes: string | null | undefined = cmd.payload.exitNodes !== undefined ? (String(cmd.payload.exitNodes || "") || null) : undefined;
        const strictNodes = cmd.payload.strictNodes !== undefined ? Boolean(cmd.payload.strictNodes) : undefined;
        if (typeof cmd.payload.backendId === "number") {
          const ok = await torManager.reconfigureInstance(cmd.payload.backendId, { exitNodes, strictNodes });
          results.push(ok ? `reconfigured instance ${cmd.payload.backendId}` : `failed to reconfigure instance ${cmd.payload.backendId}`);
        } else {
          logger.info("reconfiguring all tor instances", { exitNodes, strictNodes });
          const count = await torManager.reconfigureAll({ exitNodes, strictNodes });
          results.push(`reconfigured ${count}/${torManager.getBackends().length} instances (exitNodes=${exitNodes ?? "default"}, strictNodes=${strictNodes ?? "default"})`);
        }
      }
      // Scale tor instances
      logger.info("scale check", { torInstanceCount: cmd.payload.torInstanceCount, type: typeof cmd.payload.torInstanceCount });
      if (typeof cmd.payload.torInstanceCount === "number" && cmd.payload.torInstanceCount > 0) {
        const target = cmd.payload.torInstanceCount;
        const exitNodes = cmd.payload.exitNodes !== undefined ? (String(cmd.payload.exitNodes || "") || null) : undefined;
        const strictNodes = cmd.payload.strictNodes !== undefined ? Boolean(cmd.payload.strictNodes) : undefined;
        const { added, removed } = await torManager.scaleInstances(target, exitNodes, strictNodes);
        results.push(`scaled tor: added=${added} removed=${removed} total=${torManager.getBackends().length}`);
      }
      return { ok: true, message: results.length > 0 ? results.join("; ") : "no changes" };
    });
    workerAgent.onCommand("shutdown", async () => {
      setTimeout(() => process.exit(0), 2000);
      return { ok: true, message: "shuting down" };
    });

    await workerAgent.register();
    workerAgent.startHeartbeat();

    if (!isWorkerMode) {
      workerRegistry = new WorkerRegistry(redis, config.redisKeyPrefix || "proxy");
      commandDispatcher = new CommandDispatcher(redis, config.redisKeyPrefix || "proxy");
      smartRouter = new SmartRouter({ redis, keyPrefix: config.redisKeyPrefix || "proxy", registry: workerRegistry });
      logger.info("phase 7: smart router + command dispatcher initialized");
      setInterval(() => {
        workerRegistry!.cleanupStaleWorkers().catch((err) => {
          logger.warn("worker registry cleanup failed", { error: String(err) });
        });
      }, 60_000);
    }
  }

  if (pakasirProvider && pakasirTransactionsRepo && invoicesRepo && subscriptionsRepo && billingService) {
    let pakasirPollingInFlight = false;

    const syncPakasirPaymentStatuses = async (): Promise<void> => {
      if (pakasirPollingInFlight) {
        return;
      }

      pakasirPollingInFlight = true;
      try {
        const canRun = await canRunDistributedWorker();
        if (!canRun) {
          return;
        }

        const pendingRows = await pakasirTransactionsRepo.listPending(50);
        for (const tx of pendingRows) {
          try {
            const status = await pakasirProvider.getPaymentStatus(tx.pakasir_order_id, tx.amount_cents);

            if (status.status === "pending") {
              await pakasirTransactionsRepo.updateLastChecked(tx.invoice_id);
              continue;
            }

            const completedAt = status.status === "paid" ? new Date() : undefined;
            await pakasirTransactionsRepo.updateStatus({
              invoiceId: tx.invoice_id,
              status: status.status,
              completedAt
            });

            const invoice = await invoicesRepo.findById(tx.invoice_id);
            if (!invoice) {
              continue;
            }

            if (status.status === "paid") {
              if (invoice.status !== "paid") {
                await billingService.markInvoicePaid(invoice.id, tx.pakasir_order_id);
              }
              continue;
            }

            if (status.status === "failed") {
              if (invoice.status !== "paid") {
                await invoicesRepo.setStatus(invoice.id, "failed");
              }
              continue;
            }

            if (status.status === "expired") {
              if (invoice.status !== "paid") {
                await invoicesRepo.setStatus(invoice.id, "expired");
              }
            }
          } catch (error) {
            logger.warn("pakasir status sync failed for transaction", {
              invoiceId: tx.invoice_id,
              orderId: tx.pakasir_order_id,
              error: String(error)
            });
          }
        }
      } catch (error) {
        logger.warn("pakasir status sync iteration failed", { error: String(error) });
      } finally {
        pakasirPollingInFlight = false;
      }
    };

    setInterval(() => {
      syncPakasirPaymentStatuses().catch((error) => {
        logger.warn("pakasir status polling loop failed", { error: String(error) });
      });
    }, Math.max(2000, config.pakasirPollingIntervalMs));

    syncPakasirPaymentStatuses().catch((error) => {
      logger.warn("initial pakasir status sync failed", { error: String(error) });
    });
  }

  const writeAdminAudit = async (params: {
    req: http.IncomingMessage;
    action: string;
    entityType: string;
    entityId?: string | null;
    beforeState?: unknown;
    afterState?: unknown;
  }): Promise<void> => {
    if (!auditLogsRepo) {
      return;
    }

    try {
      await auditLogsRepo.create({
        actorUserId: null,
        action: params.action,
        entityType: params.entityType,
        entityId: params.entityId ?? null,
        beforeState: params.beforeState,
        afterState: params.afterState,
        ipAddress: getClientIp(params.req)
      });
    } catch (error) {
      logger.warn("failed to write admin audit log", { error: String(error), action: params.action });
    }
  };

  const adminServer = http.createServer(async (req, res) => {
    metrics.requests += 1;
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("X-Frame-Options", "DENY");

    const method = req.method ?? "GET";
    const url = new URL(req.url ?? "/", `http://${req.headers.host || "localhost"}`);
    const clientIp = getClientIp(req) ?? "unknown";
    
    logger.info("admin request", { method, pathname: url.pathname, clientIp });

    if (url.pathname === "/healthz") {
      writeJson(res, 200, { status: "ok", backends: torManager.getBackends() });
      return;
    }

    if (url.pathname === "/readyz") {
      const dbReady = Boolean(db);
      const torBackends = torManager.getBackends();
      const healthyBackends = torBackends.filter((item) => item.healthy).length;
      const ready = dbReady && healthyBackends > 0;

      writeJson(res, ready ? 200 : 503, {
        status: ready ? "ready" : "not_ready",
        checks: {
          database: dbReady ? "up" : "down",
          torHealthyBackends: healthyBackends,
          torTotalBackends: torBackends.length
        }
      });
      return;
    }

    if (url.pathname === "/metrics" && method === "GET") {
      writeJson(res, 200, {
        requests: metrics.requests,
        rateLimitHits: metrics.rateLimitHits,
        uptimeSeconds: Math.floor(process.uptime())
      });
      return;
    }

    // Public monitoring endpoints for Grafana (no auth required)
    if (url.pathname === "/public/api/monitoring/summary" && method === "GET") {
      const apiContext = {
        backends: torManager.getBackends(),
        usageTracker,
        metricsCollector,
        circuitBreaker: httpGateway.getCircuitBreaker(),
        connectionPool: httpGateway.getConnectionPool(),
        requestQueue: httpGateway.getRequestQueue(),
        alertManager,
        userId: "",
        username: "",
      };
      const result = await MonitoringController.getMonitoringSummary(apiContext);
      writeJson(res, 200, result);
      return;
    }

    if (url.pathname === "/public/api/monitoring/backends" && method === "GET") {
      const apiContext = {
        backends: torManager.getBackends(),
        usageTracker,
        metricsCollector,
        circuitBreaker: httpGateway.getCircuitBreaker(),
        connectionPool: httpGateway.getConnectionPool(),
        requestQueue: httpGateway.getRequestQueue(),
        alertManager,
        userId: "",
        username: "",
      };
      const result = await MonitoringController.getBackendStatus(apiContext);
      writeJson(res, 200, result);
      return;
    }

    if (url.pathname === "/public/api/monitoring/alerts" && method === "GET") {
      const apiContext = {
        backends: torManager.getBackends(),
        usageTracker,
        metricsCollector,
        circuitBreaker: httpGateway.getCircuitBreaker(),
        connectionPool: httpGateway.getConnectionPool(),
        requestQueue: httpGateway.getRequestQueue(),
        alertManager,
        userId: "",
        username: "",
      };
      const result = await MonitoringController.getActiveAlerts(apiContext);
      writeJson(res, 200, result);
      return;
    }

    if (url.pathname === "/") {
      try {
        const landingPath = path.resolve(process.cwd(), "dashboard", "landing.html");
        const html = await fs.readFile(landingPath, "utf8");
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(html);
      } catch {
        writeJson(res, 500, { error: "landing_not_available" });
      }
      return;
    }

    if (url.pathname === "/dashboard") {
      try {
        const dashboardPath = path.resolve(process.cwd(), "dashboard", "index.html");
        const html = await fs.readFile(dashboardPath, "utf8");
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(html);
      } catch {
        writeJson(res, 500, { error: "dashboard_not_available" });
      }
      return;
    }

    if (url.pathname === "/app") {
      try {
        const userAppPath = path.resolve(process.cwd(), "dashboard", "user-app.html");
        const html = await fs.readFile(userAppPath, "utf8");
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(html);
      } catch {
        writeJson(res, 500, { error: "user_app_not_available" });
      }
      return;
    }

    if (url.pathname === "/admin-ui") {
      try {
        const adminPortalPath = path.resolve(process.cwd(), "dashboard", "admin-portal.html");
        const html = await fs.readFile(adminPortalPath, "utf8");
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(html);
      } catch {
        writeJson(res, 500, { error: "admin_ui_not_available" });
      }
      return;
    }

    // ── Static file downloads dari /downloads/ ──
    if (url.pathname.startsWith("/downloads/") && method === "GET") {
      const fileName = path.basename(url.pathname);
      // Hanya izinkan karakter aman (huruf, angka, titik, dash, underscore)
      if (!/^[\w\-\.]+$/.test(fileName)) {
        writeJson(res, 400, { error: "invalid_filename" });
        return;
      }
      const filePath = path.resolve(process.cwd(), "dashboard", "downloads", fileName);
      // Cegah path traversal
      const downloadsDir = path.resolve(process.cwd(), "dashboard", "downloads");
      if (!filePath.startsWith(downloadsDir)) {
        writeJson(res, 403, { error: "forbidden" });
        return;
      }
      try {
        const stat = await fs.stat(filePath);
        const mimeTypes: Record<string, string> = {
          ".zip": "application/zip",
          ".gz": "application/gzip",
          ".tar": "application/x-tar",
          ".sh": "text/x-shellscript",
          ".txt": "text/plain",
          ".json": "application/json",
        };
        const ext = path.extname(fileName).toLowerCase();
        const contentType = mimeTypes[ext] || "application/octet-stream";
        res.writeHead(200, {
          "Content-Type": contentType,
          "Content-Length": stat.size.toString(),
          "Content-Disposition": `attachment; filename="${fileName}"`,
        });
        const { createReadStream } = await import("node:fs");
        createReadStream(filePath).pipe(res);
      } catch {
        writeJson(res, 404, { error: "file_not_found" });
      }
      return;
    }

    if (url.pathname === "/public/api/plans" && method === "GET") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !plansRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const plans = (await plansRepo.listActive()).filter((plan) => plan.is_public);
      writeJson(res, 200, {
        plans: plans.map((plan) => ({
          id: plan.id,
          code: plan.code,
          name: plan.name,
          billingPeriod: plan.billing_period,
          priceCents: plan.price_cents,
          currency: plan.currency,
          concurrentLimit: plan.concurrent_limit,
          bandwidthLimitBytes: plan.bandwidth_limit_bytes ? Number(plan.bandwidth_limit_bytes) : null,
          description: plan.description,
          trialDays: plan.trial_days,
          whitelistIpLimit: plan.whitelist_ip_limit
        }))
      });
      return;
    }

    if (url.pathname === "/public/api/payment-channels" && method === "GET") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !paymentChannelsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const channels = await paymentChannelsRepo.listActive();
      writeJson(res, 200, {
        channels: channels.map((item) => ({
          id: item.id,
          code: item.code,
          name: item.name,
          provider: item.provider,
          accountName: item.account_name,
          accountNumber: item.account_number,
          instructions: item.instructions,
          sortOrder: item.sort_order
        }))
      });
      return;
    }

    if (url.pathname === "/public/api/payment-methods" && method === "GET") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      const { methods, pakasirReady } = buildPublicPaymentMethods(config);

      writeJson(res, 200, {
        methods,
        pakasir: {
          enabled: pakasirReady
        }
      });
      return;
    }

    if (url.pathname === "/public/api/billing/preview" && method === "GET") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !plansRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const planCode = (url.searchParams.get("planCode") || "").trim();
      if (!planCode) {
        writeJson(res, 400, { error: "planCode_required" });
        return;
      }

      const plan = await plansRepo.findByCode(planCode);
      if (!plan || !plan.is_active) {
        writeJson(res, 404, { error: "plan_not_found" });
        return;
      }

      const { methods, pakasirReady } = buildPublicPaymentMethods(config);
      const methodsWithEstimate = methods.map((method) => {
        const estimatedFeeCents = estimateFeeCents(method.code, plan.price_cents);
        const estimatedTotalCents = plan.price_cents + estimatedFeeCents;

        return {
          ...method,
          estimatedFeeCents,
          estimatedTotalCents,
          estimationNote: "Estimasi biaya berdasarkan profil gateway. Nominal final ditentukan saat invoice dibuat."
        };
      });

      writeJson(res, 200, {
        plan: {
          code: plan.code,
          name: plan.name,
          amountCents: plan.price_cents,
          currency: plan.currency
        },
        methods: methodsWithEstimate,
        pakasir: {
          enabled: pakasirReady
        },
        generatedAt: new Date().toISOString()
      });
      return;
    }

    if (url.pathname === "/public/api/security-config" && method === "GET") {
      writeJson(res, 200, {
        security: {
          turnstileEnabled: config.turnstileEnabled && Boolean(config.turnstileSecretKey && config.turnstileSiteKey),
          turnstileSiteKey: config.turnstileSiteKey || "",
          requireEmailVerification: config.requireEmailVerification
        }
      });
      return;
    }

    if (url.pathname === "/public/api/auth/register" && method === "POST") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const username = typeof body.username === "string" ? body.username.trim() : "";
        const password = typeof body.password === "string" ? body.password : "";
        const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
        const turnstileToken = typeof body.turnstileToken === "string" ? body.turnstileToken : "";
        const referralCodeInput = normalizeReferralCode(body.referralCode);

        const turnstileVerified = await verifyTurnstileToken(config, turnstileToken, clientIp);
        if (!turnstileVerified) {
          writeJson(res, 400, { error: "turnstile_failed" });
          return;
        }

        if (username.length < 3 || password.length < 8) {
          writeJson(res, 400, { error: "username_min_3_and_password_min_8" });
          return;
        }

        if (!email || !isValidEmail(email)) {
          writeJson(res, 400, { error: "valid_email_required" });
          return;
        }

        let referredByUserId: string | null = null;
        if (referralCodeInput) {
          const referrer = await usersRepo.findByReferralCode(referralCodeInput);
          if (!referrer) {
            writeJson(res, 400, { error: "referral_code_not_found" });
            return;
          }

          referredByUserId = referrer.id;
        }

        const passwordHash = await hashPassword(password);
  const verificationToken = generateEmailVerificationToken();
  const verificationTokenHash = hashToken(verificationToken);
  const verificationExpiresAt = new Date(Date.now() + config.emailVerificationTtlMinutes * 60 * 1000).toISOString();
        let created: Awaited<ReturnType<typeof usersRepo.create>> | null = null;
        let assignedReferralCode = "";

        for (let attempt = 0; attempt < 5; attempt += 1) {
          assignedReferralCode = buildReferralCode(username);
          try {
            created = await usersRepo.create({
              username,
              email,
              passwordHash,
              emailVerified: !config.requireEmailVerification,
              emailVerificationTokenHash: config.requireEmailVerification ? verificationTokenHash : null,
              emailVerificationExpiresAt: config.requireEmailVerification ? verificationExpiresAt : null,
              referredByUserId,
              referralCode: assignedReferralCode
            });
            break;
          } catch (error) {
            if (isUniqueViolation(error) && attempt < 4) {
              continue;
            }
            throw error;
          }
        }

        if (!created) {
          throw new Error("create_user_failed");
        }

        await runtimeStateStore.upsertUser(username, password);
        if (notificationService && created.email) {
          await notificationService.enqueueEmail({
            userId: created.id,
            email: created.email,
            templateCode: config.requireEmailVerification ? "email_verification" : "register_welcome",
            payload: {
              username: created.username,
              verifyUrl: buildEmailVerificationUrl(config, req, verificationToken)
            },
            idempotencyKey: config.requireEmailVerification
              ? `email_verification:${created.id}:${verificationTokenHash}`
              : `register_welcome:${created.id}`
          });
        }

        writeJson(res, 201, {
          status: "ok",
          requiresEmailVerification: config.requireEmailVerification,
          user: {
            id: created.id,
            username: created.username,
            email: created.email,
            emailVerified: created.email_verified,
            role: created.role,
            status: created.status,
            referralCode: created.referral_code
          }
        });
      } catch (error) {
        if (isUniqueViolation(error)) {
          writeJson(res, 409, { error: "username_or_email_already_exists" });
          return;
        }

        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/public/api/auth/verify-email" && method === "GET") {
      const token = (url.searchParams.get("token") || "").trim();
      if (!token) {
        writeJson(res, 400, { error: "verification_token_required" });
        return;
      }

      if (!usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const user = await usersRepo.findByEmailVerificationTokenHash(hashToken(token));
      if (!user) {
        writeJson(res, 400, { error: "verification_token_invalid" });
        return;
      }

      const expiresAt = user.email_verification_expires_at ? new Date(user.email_verification_expires_at).getTime() : 0;
      if (!expiresAt || expiresAt < Date.now()) {
        writeJson(res, 400, { error: "verification_token_expired" });
        return;
      }

      await usersRepo.markEmailVerified(user.id);
      writeJson(res, 200, { status: "ok", verified: true });
      return;
    }

    if (url.pathname === "/public/api/auth/resend-verification" && method === "POST") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
        const turnstileToken = typeof body.turnstileToken === "string" ? body.turnstileToken : "";

        const turnstileVerified = await verifyTurnstileToken(config, turnstileToken, clientIp);
        if (!turnstileVerified) {
          writeJson(res, 400, { error: "turnstile_failed" });
          return;
        }

        if (!email || !isValidEmail(email)) {
          writeJson(res, 400, { error: "valid_email_required" });
          return;
        }

        const user = await usersRepo.findByEmail(email);
        if (!user || user.email_verified) {
          writeJson(res, 200, { status: "ok" });
          return;
        }

        const verificationToken = generateEmailVerificationToken();
        const verificationTokenHash = hashToken(verificationToken);
        const verificationExpiresAt = new Date(Date.now() + config.emailVerificationTtlMinutes * 60 * 1000).toISOString();
        await usersRepo.setEmailVerification(user.id, verificationTokenHash, verificationExpiresAt);

        if (notificationService && user.email) {
          await notificationService.enqueueEmail({
            userId: user.id,
            email: user.email,
            templateCode: "email_verification",
            payload: {
              username: user.username,
              verifyUrl: buildEmailVerificationUrl(config, req, verificationToken)
            },
            idempotencyKey: `email_verification_resend:${user.id}:${verificationTokenHash}`
          });
        }

        writeJson(res, 200, { status: "ok" });
      } catch {
        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/public/api/auth/login" && method === "POST") {
      logger.info("login attempt", { clientIp });
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const username = typeof body.username === "string" ? body.username.trim() : "";
        const password = typeof body.password === "string" ? body.password : "";
        const turnstileToken = typeof body.turnstileToken === "string" ? body.turnstileToken : "";

        const turnstileVerified = await verifyTurnstileToken(config, turnstileToken, clientIp);
        if (!turnstileVerified) {
          writeJson(res, 400, { error: "turnstile_failed" });
          return;
        }

        if (!username || !password) {
          writeJson(res, 400, { error: "username_and_password_required" });
          return;
        }

        const user = await usersRepo.findByUsername(username);
        if (!user) {
          writeJson(res, 401, { error: "invalid_credentials" });
          return;
        }

        if (user.status !== "active") {
          writeJson(res, 403, { error: "user_not_active" });
          return;
        }

        if (config.requireEmailVerification && !user.email_verified) {
          writeJson(res, 403, { error: "email_not_verified" });
          return;
        }

        const validPassword = await verifyPassword(password, user.password_hash);
        if (!validPassword) {
          writeJson(res, 401, { error: "invalid_credentials" });
          return;
        }

        // Store password in runtime state for proxy authentication
        await runtimeStateStore.upsertUser(user.username, password);

        const { token, session } = sessions.createSession({
          userId: user.id,
          username: user.username,
          role: user.role
        });
        await usersRepo.updateLastLogin(user.id);

        writeJson(res, 200, {
          status: "ok",
          token,
          session: {
            username: session.username,
            role: session.role,
          expiresAt: new Date(session.expiresAt).toISOString()
          }
        });
      } catch (error) {
        logger.error("login failed", { error: String(error), stack: error instanceof Error ? error.stack : undefined });
        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/public/api/auth/logout" && method === "POST") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      const token = getBearerToken(req);
      if (!token) {
        writeJson(res, 400, { error: "bearer_token_required" });
        return;
      }

      sessions.revokeSession(token);
      writeJson(res, 200, { status: "ok" });
      return;
    }

    if (url.pathname === "/public/api/billing/checkout" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !billingService) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const planCode = typeof body.planCode === "string" ? body.planCode.trim() : "";
        const paymentMethod = parseCheckoutPaymentMethod(body.paymentMethod);
        const paymentChannelCode = typeof body.paymentChannelCode === "string" ? body.paymentChannelCode.trim() : "";
        const voucherCode = typeof body.voucherCode === "string" ? body.voucherCode.trim().toUpperCase() : "";

        if (!planCode || !paymentMethod) {
          writeJson(res, 400, { error: "planCode_and_valid_paymentMethod_required" });
          return;
        }

        const result = await billingService.createCheckout({
          userId: session.userId,
          planCode,
          paymentMethod,
          paymentChannelCode: paymentChannelCode || null,
          voucherCode: voucherCode || null,
          appBaseUrl: resolveCheckoutAppBaseUrl(config, req)
        });

        if (notificationService && usersRepo) {
          const user = await usersRepo.findById(session.userId);
          if (user?.email) {
            await notificationService.enqueueEmail({
              userId: user.id,
              email: user.email,
              templateCode: "invoice_pending",
              payload: {
                username: user.username,
                invoiceNumber: result.invoice.invoice_number,
                provider: result.invoice.provider,
                amount: `${result.invoice.currency} ${result.invoice.final_amount_cents}`,
                dueAt: result.invoice.due_at
              },
              idempotencyKey: `invoice_pending:${result.invoice.id}`
            });

            if (result.invoice.provider === "bank_transfer") {
              await notificationService.enqueueEmail({
                userId: user.id,
                email: user.email,
                templateCode: "bank_transfer_instruction",
                payload: {
                  username: user.username,
                  invoiceNumber: result.invoice.invoice_number,
                  bankName: config.bankTransferBankName,
                  accountName: config.bankTransferAccountName,
                  accountNumber: config.bankTransferAccountNumber,
                  amount: `${result.invoice.currency} ${result.invoice.final_amount_cents}`,
                  dueAt: result.invoice.due_at
                },
                idempotencyKey: `bank_transfer_instruction:${result.invoice.id}`
              });
            }
          }
        }

        writeJson(res, 201, {
          status: "ok",
          invoice: {
            id: result.invoice.id,
            invoiceNumber: result.invoice.invoice_number,
            status: result.invoice.status,
            amountCents: result.invoice.final_amount_cents,
            subtotalCents: result.invoice.amount_cents,
            discountCents: result.invoice.discount_cents,
            voucherCode: result.invoice.voucher_code,
            currency: result.invoice.currency,
            dueAt: result.invoice.due_at,
            provider: result.invoice.provider,
            metadata: result.invoice.metadata
          },
          checkout: result.checkout
        });
      } catch (error) {
        const message = String(error);
        if (message.includes("plan_not_found")) {
          writeJson(res, 404, { error: "plan_not_found" });
          return;
        }

        if (message.includes("payment_channel_not_found")) {
          writeJson(res, 400, { error: "payment_channel_not_found" });
          return;
        }

        if (message.includes("voucher_not_available")) {
          writeJson(res, 503, { error: "voucher_not_available" });
          return;
        }

        if (message.includes("voucher_not_found")) {
          writeJson(res, 400, { error: "voucher_not_found" });
          return;
        }

        if (message.includes("voucher_not_started")) {
          writeJson(res, 400, { error: "voucher_not_started" });
          return;
        }

        if (message.includes("voucher_expired")) {
          writeJson(res, 400, { error: "voucher_expired" });
          return;
        }

        if (message.includes("voucher_not_applicable_plan")) {
          writeJson(res, 400, { error: "voucher_not_applicable_plan" });
          return;
        }

        if (message.includes("voucher_usage_limit_reached")) {
          writeJson(res, 400, { error: "voucher_usage_limit_reached" });
          return;
        }

        if (message.includes("voucher_user_limit_reached")) {
          writeJson(res, 400, { error: "voucher_user_limit_reached" });
          return;
        }

        if (message.includes("pakasir_not_enabled")) {
          writeJson(res, 400, { error: "pakasir_not_enabled" });
          return;
        }

        if (message.includes("pakasir_method_not_enabled")) {
          writeJson(res, 400, { error: "pakasir_method_not_enabled" });
          return;
        }

        if (message.includes("unsupported_payment_method")) {
          writeJson(res, 400, { error: "unsupported_payment_method" });
          return;
        }

        writeJson(res, 400, { error: "checkout_failed" });
      }
      return;
    }

    if (url.pathname === "/public/api/billing/webhook/paypal" && method === "POST") {
      const rate = await publicLimiter.consume(`public:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.public += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_public" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !billingService) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      if (!isPaypalWebhookAuthorized(req, config.paypalWebhookToken)) {
        writeJson(res, 401, { error: "invalid_paypal_signature" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const providerEventId = typeof body.id === "string" ? body.id : typeof body.eventId === "string" ? body.eventId : "";
        const eventType = typeof body.event_type === "string" ? body.event_type : typeof body.eventType === "string" ? body.eventType : "";
        const invoiceId =
          typeof body.invoiceId === "string"
            ? body.invoiceId
            : typeof body.resource === "object" && body.resource && typeof (body.resource as { invoice_id?: unknown }).invoice_id === "string"
              ? ((body.resource as { invoice_id?: string }).invoice_id ?? "")
              : "";
        const providerRef =
          typeof body.resource === "object" && body.resource && typeof (body.resource as { id?: unknown }).id === "string"
            ? ((body.resource as { id?: string }).id ?? null)
            : null;

        if (!providerEventId || !eventType || !invoiceId) {
          writeJson(res, 400, { error: "providerEventId_eventType_invoiceId_required" });
          return;
        }

        const result = await billingService.processPaypalWebhook({
          providerEventId,
          eventType,
          invoiceId,
          providerRef,
          payload: body
        });

        if (notificationService && usersRepo && result.justPaid && result.userId) {
          const user = await usersRepo.findById(result.userId);
          if (user?.email) {
            await notificationService.enqueueEmail({
              userId: user.id,
              email: user.email,
              templateCode: "invoice_paid",
              payload: {
                username: user.username,
                invoiceNumber: result.invoiceNumber ?? invoiceId
              },
              idempotencyKey: `invoice_paid:${invoiceId}`
            });
          }
        }

        writeJson(res, 200, {
          status: "ok",
          processed: result.processed,
          invoiceStatus: result.invoiceStatus
        });
      } catch (error) {
        const message = String(error);
        if (message.includes("invoice_not_found")) {
          writeJson(res, 404, { error: "invoice_not_found" });
          return;
        }

        writeJson(res, 400, { error: "webhook_processing_failed" });
      }
      return;
    }

    if (url.pathname === "/user/api/me" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const user = await usersRepo.findById(session.userId);
      if (!user) {
        writeJson(res, 404, { error: "user_not_found" });
        return;
      }

      writeJson(res, 200, {
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          status: user.status,
          email: user.email,
          bankName: user.bank_name,
          bankAccountName: user.bank_account_name,
          bankAccountNumber: user.bank_account_number,
          profileAddress: user.profile_address,
          referralCode: user.referral_code,
          referredByUserId: user.referred_by_user_id,
          expiresAt: new Date(session.expiresAt).toISOString(),
          profileComplete: Boolean(user.email && user.bank_name && user.bank_account_name && user.bank_account_number),
          affiliateReady: Boolean(user.bank_name && user.bank_account_name && user.bank_account_number)
        }
      });
      return;
    }

    if (url.pathname === "/user/api/profile" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const user = await usersRepo.findById(session.userId);
      if (!user) {
        writeJson(res, 404, { error: "user_not_found" });
        return;
      }

      writeJson(res, 200, {
        profile: {
          id: user.id,
          username: user.username,
          email: user.email,
          bankName: user.bank_name,
          bankAccountName: user.bank_account_name,
          bankAccountNumber: user.bank_account_number,
          profileAddress: user.profile_address,
          referralCode: user.referral_code,
          referredByUserId: user.referred_by_user_id,
          completion: {
            email: Boolean(user.email),
            bankName: Boolean(user.bank_name),
            bankAccountName: Boolean(user.bank_account_name),
            bankAccountNumber: Boolean(user.bank_account_number),
            profileAddress: Boolean(user.profile_address),
            allComplete: Boolean(user.email && user.bank_name && user.bank_account_name && user.bank_account_number)
          }
        }
      });
      return;
    }

    if (url.pathname === "/user/api/profile" && method === "PATCH") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : undefined;
        const bankName = typeof body.bankName === "string" ? body.bankName.trim() : undefined;
        const bankAccountName = typeof body.bankAccountName === "string" ? body.bankAccountName.trim() : undefined;
        const bankAccountNumber = typeof body.bankAccountNumber === "string" ? body.bankAccountNumber.trim() : undefined;
        const profileAddress = typeof body.profileAddress === "string" ? body.profileAddress.trim() : undefined;

        if (email !== undefined && email !== null && email !== "" && !/^\S+@\S+\.\S+$/.test(email)) {
          writeJson(res, 400, { error: "invalid_email" });
          return;
        }

        await usersRepo.updateProfile(session.userId, {
          email: email === undefined ? undefined : email || null,
          bankName: bankName === undefined ? undefined : bankName || null,
          bankAccountName: bankAccountName === undefined ? undefined : bankAccountName || null,
          bankAccountNumber: bankAccountNumber === undefined ? undefined : bankAccountNumber || null,
          profileAddress: profileAddress === undefined ? undefined : profileAddress || null
        });

        const updated = await usersRepo.findById(session.userId);
        await writeAdminAudit({
          req,
          action: "user_profile_update",
          entityType: "user",
          entityId: session.userId,
          afterState: {
            email: updated?.email ?? null,
            bankName: updated?.bank_name ?? null,
            bankAccountName: updated?.bank_account_name ?? null,
            bankAccountNumber: updated?.bank_account_number ?? null,
            profileAddress: updated?.profile_address ?? null
          }
        });

        writeJson(res, 200, {
          status: "ok",
          profile: {
            id: updated?.id,
            email: updated?.email,
            bankName: updated?.bank_name,
            bankAccountName: updated?.bank_account_name,
            bankAccountNumber: updated?.bank_account_number,
            profileAddress: updated?.profile_address,
            completion: {
              email: Boolean(updated?.email),
              bankName: Boolean(updated?.bank_name),
              bankAccountName: Boolean(updated?.bank_account_name),
              bankAccountNumber: Boolean(updated?.bank_account_number),
              profileAddress: Boolean(updated?.profile_address),
              allComplete: Boolean(updated?.email && updated?.bank_name && updated?.bank_account_name && updated?.bank_account_number)
            }
          }
        });
      } catch (error) {
        if (isUniqueViolation(error)) {
          writeJson(res, 409, { error: "email_exists" });
          return;
        }

        writeJson(res, 400, { error: "profile_update_failed" });
      }
      return;
    }

    if (url.pathname === "/user/api/password" && method === "PATCH") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
        const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
        const confirmPassword = typeof body.confirmPassword === "string" ? body.confirmPassword : "";

        if (!currentPassword || !newPassword || !confirmPassword) {
          writeJson(res, 400, { error: "password_fields_required" });
          return;
        }

        if (newPassword.length < 8) {
          writeJson(res, 400, { error: "password_too_short" });
          return;
        }

        if (newPassword !== confirmPassword) {
          writeJson(res, 400, { error: "password_mismatch" });
          return;
        }

        const user = await usersRepo.findById(session.userId);
        if (!user) {
          writeJson(res, 404, { error: "user_not_found" });
          return;
        }

        const currentValid = await verifyPassword(currentPassword, user.password_hash);
        if (!currentValid) {
          writeJson(res, 400, { error: "current_password_invalid" });
          return;
        }

        const newHash = await hashPassword(newPassword);
        await usersRepo.updatePassword(session.userId, newHash);

        await writeAdminAudit({
          req,
          action: "user_password_update",
          entityType: "user",
          entityId: session.userId,
          afterState: { changed: true }
        });

        writeJson(res, 200, { status: "ok" });
      } catch {
        writeJson(res, 400, { error: "password_update_failed" });
      }
      return;
    }

    if (url.pathname === "/user/api/trial/start" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !billingService || !config.enableTrialSelfService) {
        writeJson(res, 503, { error: "trial_not_available" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const planCode = typeof body.planCode === "string" && body.planCode.trim() ? body.planCode.trim() : null;
        const result = await billingService.startTrial({
          userId: session.userId,
          planCode
        });

        writeJson(res, 201, {
          status: "ok",
          trial: {
            subscriptionId: result.subscriptionId,
            planCode: result.planCode,
            startsAt: result.startsAt,
            endsAt: result.endsAt
          }
        });
      } catch (error) {
        const message = String(error);
        if (message.includes("trial_already_used")) {
          writeJson(res, 400, { error: "trial_already_used" });
          return;
        }

        if (message.includes("active_subscription_exists")) {
          writeJson(res, 400, { error: "active_subscription_exists" });
          return;
        }

        if (message.includes("trial_plan_not_found")) {
          writeJson(res, 404, { error: "trial_plan_not_found" });
          return;
        }

        if (message.includes("trial_disabled")) {
          writeJson(res, 400, { error: "trial_disabled" });
          return;
        }

        writeJson(res, 400, { error: "trial_start_failed" });
      }
      return;
    }

    if (url.pathname === "/user/api/trial/status" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !billingService) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const trial = await billingService.getTrialStatus(session.userId);
      writeJson(res, 200, { trial });
      return;
    }

    if (url.pathname === "/user/api/affiliate" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!usersRepo || !affiliateCommissionsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const user = await usersRepo.findById(session.userId);
      if (!user) {
        writeJson(res, 404, { error: "user_not_found" });
        return;
      }

      const profileComplete = Boolean(user.email && user.bank_name && user.bank_account_name && user.bank_account_number);

      let referralCode = user.referral_code;
      if (!referralCode) {
        for (let attempt = 0; attempt < 5; attempt += 1) {
          const candidate = buildReferralCode(user.username);
          try {
            await usersRepo.setReferralCode(user.id, candidate);
            referralCode = candidate;
            break;
          } catch (error) {
            if (isUniqueViolation(error) && attempt < 4) {
              continue;
            }
            throw error;
          }
        }
      }

      const commissions = await affiliateCommissionsRepo.listByReferrerUserId(session.userId, 100);
      const summary = await affiliateCommissionsRepo.summarizeByReferrerUserId(session.userId);

      writeJson(res, 200, {
        affiliate: {
          referralCode,
          referredByUserId: user.referred_by_user_id,
          profileComplete,
          canUseAffiliate: profileComplete,
          requirements: {
            bankName: Boolean(user.bank_name),
            bankAccountName: Boolean(user.bank_account_name),
            bankAccountNumber: Boolean(user.bank_account_number)
          },
          summary: {
            pendingCents: summary.pending_cents,
            approvedCents: summary.approved_cents,
            paidCents: summary.paid_cents
          },
          commissions: commissions.map((item) => ({
            id: item.id,
            referredUserId: item.referred_user_id,
            invoiceId: item.invoice_id,
            commissionCents: item.commission_cents,
            status: item.status,
            createdAt: item.created_at,
            approvedAt: item.approved_at,
            paidAt: item.paid_at
          }))
        }
      });
      return;
    }

    if (url.pathname === "/user/api/invoices" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !invoicesRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const invoices = await invoicesRepo.listByUser(session.userId);
      writeJson(res, 200, {
        invoices: invoices.map((invoice) => ({
          id: invoice.id,
          invoiceNumber: invoice.invoice_number,
          status: invoice.status,
          amountCents: invoice.final_amount_cents,
          subtotalCents: invoice.amount_cents,
          discountCents: invoice.discount_cents,
          voucherCode: invoice.voucher_code,
          currency: invoice.currency,
          dueAt: invoice.due_at,
          paidAt: invoice.paid_at,
          provider: invoice.provider,
          createdAt: invoice.created_at,
          metadata: invoice.metadata
        }))
      });
      return;
    }

    if (url.pathname === "/user/api/subscription" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !subscriptionsRepo || !plansRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const subscription = await subscriptionsRepo.findLatestByUserId(session.userId);
      if (!subscription) {
        writeJson(res, 200, { subscription: null });
        return;
      }

      const plan = await plansRepo.findById(subscription.plan_id);
      writeJson(res, 200, {
        subscription: {
          id: subscription.id,
          status: subscription.status,
          startsAt: subscription.starts_at,
          endsAt: subscription.ends_at,
          graceUntil: subscription.grace_until,
          autoRenew: subscription.auto_renew,
          plan: plan
            ? {
                id: plan.id,
                code: plan.code,
                name: plan.name,
                billingPeriod: plan.billing_period,
                priceCents: plan.price_cents,
                currency: plan.currency,
                concurrentLimit: plan.concurrent_limit
              }
            : null
        }
      });
      return;
    }

    if (url.pathname === "/user/api/proxy-access" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const username = session.username;
      const whitelistedIps = runtimeStateStore.getWhitelistedIps(username);
      const detectedIp = normalizeIp(clientIp);
      const access = proxyAccessService ? await proxyAccessService.getAccess(username, detectedIp ?? undefined) : { allowed: true, reason: "ok", concurrentLimit: null };
      const headerProxyHost = getProxyHost(req, "127.0.0.1");
      const proxyIpHost = runtimeStateStore.getProxyIpHost() || headerProxyHost;
      const proxyDomains = runtimeStateStore.getProxyDomains();
      const preferredHost = proxyDomains[0] || proxyIpHost;
      const password = runtimeStateStore.getSnapshot().users[username] ?? null;
      const activeConnections = credentials.getActiveSessionCount(username);

      let totalBytes = 0;
      let totalRequests = 0;
      let latestPeriodPeakConcurrent = 0;
      if (usagePeriodsRepo) {
        const usageRecords = await usagePeriodsRepo.listByUser(session.userId);
        for (const record of usageRecords) {
          totalBytes += Number(record.bytes_in) + Number(record.bytes_out);
          totalRequests += Number(record.requests_count);
        }
        if (usageRecords.length > 0) {
          latestPeriodPeakConcurrent = usageRecords[0].peak_concurrent;
        }
      }

      const totalGbUsed = Number((totalBytes / 1024 / 1024 / 1024).toFixed(3));

      writeJson(res, 200, {
        access: {
          allowed: access.allowed,
          reason: access.reason,
          concurrentLimit: access.concurrentLimit
        },
        routing: {
          preference: runtimeStateStore.getUserTorRoutingPreference(session.username),
          countries: buildTorCountryOptions(torManager.getBackends().filter((backend) => backend.healthy))
        },
        runtime: {
          activeConnections,
          connectionLimit: access.concurrentLimit,
          latestPeriodPeakConcurrent
        },
        usage: {
          totalBytes,
          totalGbUsed,
          totalRequests
        },
        credentials: {
          username,
          password
        },
        endpoints: {
          host: preferredHost,
          ipHost: proxyIpHost,
          domains: proxyDomains,
          httpPort: config.httpProxyPort,
          socksPort: config.socksProxyPort,
          httpProxyUrl: password ? `http://${username}:${password}@${preferredHost}:${config.httpProxyPort}` : null,
          socksProxyUrl: password ? `socks5://${username}:${password}@${preferredHost}:${config.socksProxyPort}` : null
        },
        whitelist: {
          detectedIp,
          ips: whitelistedIps,
          required: true,
          currentIpAllowed: detectedIp ? whitelistedIps.includes(detectedIp) : false
        }
      });
      return;
    }

    if (url.pathname === "/user/api/tor-routing" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      writeJson(res, 200, {
        preference: runtimeStateStore.getUserTorRoutingPreference(session.username),
        countries: buildTorCountryOptions(torManager.getBackends().filter((backend) => backend.healthy))
      });
      return;
    }

    if (url.pathname === "/user/api/tor-routing" && method === "PATCH") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const mode = typeof body.mode === "string" ? body.mode.trim().toLowerCase() : "random";
        const countryCode = typeof body.countryCode === "string" ? body.countryCode.trim().toUpperCase() : null;
        const availableCountries = buildTorCountryOptions(torManager.getBackends().filter((backend) => backend.healthy)).map((item) => item.code);

        if (mode !== "random" && mode !== "sticky") {
          writeJson(res, 400, { error: "invalid_mode" });
          return;
        }

        if (mode === "sticky") {
          if (!countryCode) {
            writeJson(res, 400, { error: "country_required_for_sticky" });
            return;
          }

          if (!availableCountries.includes(countryCode)) {
            writeJson(res, 400, { error: "country_not_available" });
            return;
          }
        }

        const preference = await runtimeStateStore.setUserTorRoutingPreference(session.username, {
          mode: mode === "sticky" ? "sticky" : "random",
          countryCode: mode === "sticky" ? countryCode : null
        });

        writeJson(res, 200, {
          status: "ok",
          preference,
          countries: buildTorCountryOptions(torManager.getBackends().filter((backend) => backend.healthy))
        });
      } catch {
        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/user/api/proxy-access/test" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const username = session.username;
      const detectedIp = normalizeIp(clientIp);
      const access = proxyAccessService ? await proxyAccessService.getAccess(username, detectedIp ?? undefined) : { allowed: true, reason: "ok", concurrentLimit: null };
      const currentIpAllowed = runtimeStateStore.isIpWhitelisted(username, detectedIp);
      const backends = torManager.getBackends();
      const healthyBackends = backends.filter((backend) => backend.healthy).length;

      const ok = Boolean(access.allowed && currentIpAllowed && healthyBackends > 0);

      writeJson(res, 200, {
        ok,
        checks: {
          subscriptionAccess: access.allowed,
          whitelistCurrentIpAllowed: currentIpAllowed,
          healthyTorBackends: healthyBackends,
          totalTorBackends: backends.length
        },
        reason: !access.allowed
          ? access.reason
          : !currentIpAllowed
            ? "current_ip_not_whitelisted"
            : healthyBackends <= 0
              ? "no_healthy_tor_backend"
              : "ok"
      });
      return;
    }

    if (url.pathname === "/user/api/whitelist-ips" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      let whitelistIpLimit: number | null = null;
      if (usersRepo) {
        const profile = await usersRepo.findProxyAccessProfile(session.username);
        whitelistIpLimit = typeof profile?.plan_whitelist_ip_limit === "number"
          ? profile.plan_whitelist_ip_limit
          : null;
      }

      writeJson(res, 200, {
        ips: runtimeStateStore.getWhitelistedIps(session.username),
        detectedIp: normalizeIp(clientIp),
        whitelistIpLimit
      });
      return;
    }

    if (url.pathname === "/user/api/whitelist-ips" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const currentIps = runtimeStateStore.getWhitelistedIps(session.username);
        let whitelistIpLimit: number | null = null;
        if (usersRepo) {
          const profile = await usersRepo.findProxyAccessProfile(session.username);
          whitelistIpLimit = typeof profile?.plan_whitelist_ip_limit === "number"
            ? profile.plan_whitelist_ip_limit
            : null;

          if (whitelistIpLimit !== null && whitelistIpLimit > 0 && currentIps.length >= whitelistIpLimit) {
            writeJson(res, 400, {
              error: "whitelist_ip_limit_reached",
              limit: whitelistIpLimit,
              current: currentIps.length
            });
            return;
          }
        }

        const body = await readJsonBody(req);
        const ip = typeof body.ip === "string" ? body.ip : "";
        const ips = await runtimeStateStore.addWhitelistedIp(session.username, ip);
        writeJson(res, 200, { status: "ok", ips, whitelistIpLimit });
      } catch (error) {
        writeJson(res, 400, { error: "invalid_ip" });
      }
      return;
    }

    if (url.pathname.startsWith("/user/api/whitelist-ips/") && method === "DELETE") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const rawIp = decodeURIComponent(url.pathname.replace("/user/api/whitelist-ips/", "")).trim();
        const ips = await runtimeStateStore.removeWhitelistedIp(session.username, rawIp);
        writeJson(res, 200, { status: "ok", ips });
      } catch {
        writeJson(res, 400, { error: "invalid_ip" });
      }
      return;
    }

    if (url.pathname === "/user/api/usage" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usagePeriodsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const records = await usagePeriodsRepo.listByUser(session.userId);
      writeJson(res, 200, {
        usage: records.map((record) => ({
          id: record.id,
          periodStart: record.period_start,
          periodEnd: record.period_end,
          requestsCount: Number(record.requests_count),
          bytesIn: Number(record.bytes_in),
          bytesOut: Number(record.bytes_out),
          peakConcurrent: record.peak_concurrent,
          subscriptionId: record.subscription_id
        }))
      });
      return;
    }

    if (url.pathname === "/user/api/support/channels" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!supportIntegrationsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const integrations = await supportIntegrationsRepo.listAll();
      const activeIntegrations = integrations.filter((item) => item.is_active);
      writeJson(res, 200, {
        channels: activeIntegrations.map((item) => {
          const previewMessage = renderSupportTemplate(item.message_template, {
            ticketId: "new-ticket",
            subject: "Bantuan pengguna",
            category: "general",
            priority: "medium",
            status: "open",
            username: session.username,
            message: "Halo, saya membutuhkan bantuan."
          });

          return {
            id: item.id,
            provider: item.provider,
            name: item.name,
            categories: item.categories,
            priorities: item.priorities,
            statuses: item.statuses,
            whatsappUrl:
              item.provider === "whatsapp_click_to_chat" && item.whatsapp_phone_number
                ? buildWhatsappClickToChatUrl(item.whatsapp_phone_number, previewMessage)
                : null
          };
        })
      });
      return;
    }

    if (url.pathname === "/user/api/tickets" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!supportTicketsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const subject = sanitizeTicketText(body.subject, 180);
        const message = sanitizeTicketText(body.message, 4000);
        const category = parseSupportTicketCategory(body.category, "general");
        const priority = parseSupportTicketPriority(body.priority, "medium");

        if (!subject || !message) {
          writeJson(res, 400, { error: "subject_and_message_required" });
          return;
        }

        const ticket = await supportTicketsRepo.createTicket({
          userId: session.userId,
          subject,
          category,
          priority,
          initialMessage: message
        });

        const dispatchResult = await dispatchSupportIntegrations({
          integrationsRepo: supportIntegrationsRepo,
          loggerContext: {
            ticketId: ticket.id,
            eventType: "ticket_created"
          },
          ticket: {
            id: ticket.id,
            category,
            priority,
            status: ticket.status,
            subject: ticket.subject
          },
          username: session.username,
          message
        });

        writeJson(res, 201, {
          status: "ok",
          ticket: {
            id: ticket.id,
            subject: ticket.subject,
            category: ticket.category,
            priority: ticket.priority,
            status: ticket.status,
            createdAt: ticket.created_at,
            updatedAt: ticket.updated_at
          },
          integrations: dispatchResult
        });
      } catch {
        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/user/api/tickets" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!supportTicketsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const statusFilter = parseSupportTicketStatus(url.searchParams.get("status"));
      const limit = Number.parseInt(url.searchParams.get("limit") ?? "50", 10);
      const offset = Number.parseInt(url.searchParams.get("offset") ?? "0", 10);
      const tickets = await supportTicketsRepo.listByUser(session.userId, limit, offset);
      const filteredTickets = statusFilter ? tickets.filter((item) => item.status === statusFilter) : tickets;

      writeJson(res, 200, {
        tickets: filteredTickets.map((item) => ({
          id: item.id,
          subject: item.subject,
          category: item.category,
          priority: item.priority,
          status: item.status,
          assignedAdminUserId: item.assigned_admin_user_id,
          messageCount: item.message_count,
          lastMessageAt: item.last_message_at,
          updatedAt: item.updated_at,
          createdAt: item.created_at
        }))
      });
      return;
    }

    if (url.pathname.startsWith("/user/api/tickets/") && url.pathname.endsWith("/messages") && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!supportTicketsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const ticketId = decodeURIComponent(url.pathname.replace("/user/api/tickets/", "").replace("/messages", "")).trim();
      if (!ticketId || ticketId.includes("/")) {
        writeJson(res, 400, { error: "ticket_id_required" });
        return;
      }

      const ticket = await supportTicketsRepo.findByIdForUser(ticketId, session.userId);
      if (!ticket) {
        writeJson(res, 404, { error: "ticket_not_found" });
        return;
      }

      const messages = await supportTicketsRepo.listMessages(ticketId, false);
      writeJson(res, 200, {
        ticket: {
          id: ticket.id,
          subject: ticket.subject,
          category: ticket.category,
          priority: ticket.priority,
          status: ticket.status,
          assignedAdminUserId: ticket.assigned_admin_user_id,
          updatedAt: ticket.updated_at,
          createdAt: ticket.created_at
        },
        messages: messages.map((item) => ({
          id: item.id,
          senderRole: item.sender_role,
          senderUserId: item.sender_user_id,
          senderUsername: item.sender_username,
          channel: item.channel,
          message: item.message_text,
          createdAt: item.created_at
        }))
      });
      return;
    }

    if (url.pathname.startsWith("/user/api/tickets/") && url.pathname.endsWith("/messages") && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!supportTicketsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const ticketId = decodeURIComponent(url.pathname.replace("/user/api/tickets/", "").replace("/messages", "")).trim();
      if (!ticketId || ticketId.includes("/")) {
        writeJson(res, 400, { error: "ticket_id_required" });
        return;
      }

      const ticket = await supportTicketsRepo.findByIdForUser(ticketId, session.userId);
      if (!ticket) {
        writeJson(res, 404, { error: "ticket_not_found" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const message = sanitizeTicketText(body.message, 4000);
        if (!message) {
          writeJson(res, 400, { error: "message_required" });
          return;
        }

        const createdMessage = await supportTicketsRepo.addMessage({
          ticketId,
          senderUserId: session.userId,
          senderRole: "user",
          messageText: message,
          channel: "app"
        });

        await supportTicketsRepo.updateTicketById(ticketId, {
          status: "open"
        });

        const updatedTicket = await supportTicketsRepo.findByIdForUser(ticketId, session.userId);
        if (updatedTicket) {
          await dispatchSupportIntegrations({
            integrationsRepo: supportIntegrationsRepo,
            loggerContext: {
              ticketId,
              eventType: "ticket_reply_user"
            },
            ticket: {
              id: updatedTicket.id,
              category: updatedTicket.category,
              priority: updatedTicket.priority,
              status: updatedTicket.status,
              subject: updatedTicket.subject
            },
            username: session.username,
            message
          });
        }

        writeJson(res, 201, {
          status: "ok",
          message: {
            id: createdMessage.id,
            senderRole: createdMessage.sender_role,
            senderUserId: createdMessage.sender_user_id,
            senderUsername: createdMessage.sender_username,
            channel: createdMessage.channel,
            message: createdMessage.message_text,
            createdAt: createdMessage.created_at
          }
        });
      } catch {
        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/user/api/credentials/reset" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
        const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
        if (!currentPassword || newPassword.length < 8) {
          writeJson(res, 400, { error: "currentPassword_and_newPassword_min_8_required" });
          return;
        }

        const user = await usersRepo.findById(session.userId);
        if (!user) {
          writeJson(res, 404, { error: "user_not_found" });
          return;
        }

        const validCurrent = await verifyPassword(currentPassword, user.password_hash);
        if (!validCurrent) {
          writeJson(res, 401, { error: "invalid_current_password" });
          return;
        }

        const newPasswordHash = await hashPassword(newPassword);
        await usersRepo.updatePassword(user.id, newPasswordHash);
        await runtimeStateStore.upsertUser(user.username, newPassword);
        if (notificationService && user.email) {
          await notificationService.enqueueEmail({
            userId: user.id,
            email: user.email,
            templateCode: "security_password_changed",
            payload: {
              username: user.username
            },
            idempotencyKey: `security_password_changed:${user.id}:${Date.now()}`
          });
        }
        writeJson(res, 200, { status: "ok" });
      } catch {
        writeJson(res, 400, { error: "invalid_request" });
      }
      return;
    }

    if (url.pathname === "/user/api/notifications" && method === "GET") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!inAppNotificationsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const readerKey = `user:${session.userId}`;
      const [items, unreadCount] = await Promise.all([
        inAppNotificationsRepo.listFeed({ readerKey, audience: "user", limit: 80 }),
        inAppNotificationsRepo.countUnread({ readerKey, audience: "user" })
      ]);

      writeJson(res, 200, {
        notifications: items.map((item) => ({
          id: item.id,
          title: item.title,
          message: item.message,
          type: item.type,
          audience: item.audience,
          isActive: item.is_active,
          startsAt: item.starts_at,
          endsAt: item.ends_at,
          createdAt: item.created_at,
          updatedAt: item.updated_at,
          isRead: item.is_read
        })),
        unreadCount
      });
      return;
    }

    if (url.pathname === "/user/api/notifications/read-all" && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!inAppNotificationsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const readerKey = `user:${session.userId}`;
      const markedCount = await inAppNotificationsRepo.markAllRead({ readerKey, audience: "user" });
      writeJson(res, 200, { status: "ok", markedCount });
      return;
    }

    if (url.pathname.startsWith("/user/api/notifications/") && url.pathname.endsWith("/read") && method === "POST") {
      const rate = await userLimiter.consume(`user:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.user += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_user" });
        return;
      }

      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (!inAppNotificationsRepo) {
        writeJson(res, 503, { error: "billing_not_configured" });
        return;
      }

      const idPath = decodeURIComponent(url.pathname.replace("/user/api/notifications/", "").replace("/read", "")).trim();
      if (!idPath || idPath.includes("/")) {
        writeJson(res, 400, { error: "notification_id_required" });
        return;
      }

      const existing = await inAppNotificationsRepo.findById(idPath);
      if (!existing) {
        writeJson(res, 404, { error: "notification_not_found" });
        return;
      }

      const readerKey = `user:${session.userId}`;
      await inAppNotificationsRepo.markRead(idPath, readerKey);
      writeJson(res, 200, { status: "ok" });
      return;
    }

    // API v1 - Developer API
    if (url.pathname.startsWith("/api/v1/")) {
      const session = getUserSession(req, sessions);
      if (!session) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      const apiContext: ApiController.ApiContext = {
        backends: torManager.getBackends(),
        usageTracker,
        metricsCollector,
        circuitBreaker: httpGateway.getCircuitBreaker(),
        connectionPool: httpGateway.getConnectionPool(),
        requestQueue: httpGateway.getRequestQueue(),
        alertManager,
        userId: session.userId,
        username: session.username,
      };

      // GET /api/v1/health
      if (url.pathname === "/api/v1/health" && method === "GET") {
        const result = await ApiController.getHealth(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/ip/current
      if (url.pathname === "/api/v1/ip/current" && method === "GET") {
        const result = await ApiController.getCurrentIp(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // POST /api/v1/ip/rotate
      if (url.pathname === "/api/v1/ip/rotate" && method === "POST") {
        const body = await readJsonBody(req);
        const sessionId = typeof body.sessionId === "string" ? body.sessionId : null;
        const result = await ApiController.rotateIp(sessionId);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/countries
      if (url.pathname === "/api/v1/countries" && method === "GET") {
        const result = await ApiController.getAvailableCountries(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/usage
      if (url.pathname === "/api/v1/usage" && method === "GET") {
        const result = await ApiController.getUsageStats(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/metrics
      if (url.pathname === "/api/v1/metrics" && method === "GET") {
        const result = await ApiController.getMetrics(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/circuit-breaker/stats
      if (url.pathname === "/api/v1/circuit-breaker/stats" && method === "GET") {
        const result = await ApiController.getCircuitBreakerStatus(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // POST /api/v1/circuit-breaker/reset
      if (url.pathname === "/api/v1/circuit-breaker/reset" && method === "POST") {
        const body = await readJsonBody(req);
        const backendId = typeof body.backendId === "string" ? body.backendId : null;
        const result = await ApiController.resetCircuitBreaker(backendId, apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/connection-pool/stats
      if (url.pathname === "/api/v1/connection-pool/stats" && method === "GET") {
        const result = await ApiController.getConnectionPoolStats(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/request-queue/stats
      if (url.pathname === "/api/v1/request-queue/stats" && method === "GET") {
        const result = await ApiController.getRequestQueueStats(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/monitoring/summary
      if (url.pathname === "/api/v1/monitoring/summary" && method === "GET") {
        const result = await MonitoringController.getMonitoringSummary(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/monitoring/backends
      if (url.pathname === "/api/v1/monitoring/backends" && method === "GET") {
        const result = await MonitoringController.getBackendStatus(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // GET /api/v1/monitoring/alerts
      if (url.pathname === "/api/v1/monitoring/alerts" && method === "GET") {
        const result = await MonitoringController.getActiveAlerts(apiContext);
        writeJson(res, 200, result);
        return;
      }

      // POST /api/v1/monitoring/metrics/reset
      if (url.pathname === "/api/v1/monitoring/metrics/reset" && method === "POST") {
        const result = await MonitoringController.resetMetrics();
        writeJson(res, 200, result);
        return;
      }

      writeJson(res, 404, { error: "not_found" });
      return;
    }

    if (url.pathname.startsWith("/admin/api/")) {
      const rate = await adminLimiter.consume(`admin:${clientIp}`);
      if (!rate.allowed) {
        metrics.rateLimitHits.admin += 1;
        res.setHeader("Retry-After", Math.max(1, Math.ceil((rate.resetAt - Date.now()) / 1000)).toString());
        writeJson(res, 429, { error: "rate_limited_admin" });
        return;
      }

      if (!isAdminAuthorized(req, config.adminToken)) {
        writeJson(res, 401, { error: "unauthorized" });
        return;
      }

      if (url.pathname === "/admin/api/state" && method === "GET") {
        const state = runtimeStateStore.getSnapshot();
        writeJson(res, 200, {
          app: {
            httpProxyPort: config.httpProxyPort,
            socksProxyPort: config.socksProxyPort,
            adminPort: config.adminPort,
            torInstances: config.torInstances
          },
          runtime: {
            users: Object.keys(state.users).map((username) => ({ username })),
            maxConcurrentPerUser: state.maxConcurrentPerUser,
            proxyIpHost: state.proxyIpHost,
            proxyDomains: state.proxyDomains,
            torRouting: state.torRouting,
            updatedAt: state.updatedAt
          },
          backends: torManager.getBackends()
        });
        return;
      }

      if (url.pathname === "/admin/api/tor-routing" && method === "GET") {
        const backends = torManager.getBackends();
        const snapshot = runtimeStateStore.getTorRoutingSnapshot();
        const availableCountries = new Map<string, { countryCode: string; countryName: string; count: number }>();

        const instances = backends.map((backend) => {
          const routing = snapshot[String(backend.id)] ?? runtimeStateStore.getTorRoutingConfig(backend.id);

          if (backend.countryCode) {
            const countryCode = backend.countryCode.toUpperCase();
            const countryName = backend.countryName || countryCode;
            const existing = availableCountries.get(countryCode) || { countryCode, countryName, count: 0 };
            existing.count += 1;
            availableCountries.set(countryCode, existing);
          }

          return {
            id: backend.id,
            socksPort: backend.socksPort,
            controlPort: backend.controlPort,
            dnsPort: backend.dnsPort,
            healthy: backend.healthy,
            exitIp: backend.exitIp ?? null,
            countryCode: backend.countryCode ?? null,
            countryName: backend.countryName ?? null,
            lastCheckedAt: backend.lastCheckedAt ?? null,
            routing: {
              mode: routing.mode,
              targetCountryCode: routing.targetCountryCode,
              weightPercent: routing.weightPercent,
              strict: routing.strict,
              fallbackCountryCode: routing.fallbackCountryCode,
              updatedAt: routing.updatedAt
            }
          };
        });

        writeJson(res, 200, {
          instances,
          countries: [...availableCountries.values()].sort((a, b) => a.countryName.localeCompare(b.countryName)),
          updatedAt: new Date().toISOString()
        });
        return;
      }

      if (url.pathname === "/admin/api/tor-routing/all" && method === "PATCH") {
        const backends = torManager.getBackends();
        if (backends.length === 0) {
          writeJson(res, 404, { error: "instance_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const mode = parseTorRoutingMode(body.mode);
          const targetCountryCode = parseCountryCodeInput(body.targetCountryCode);
          const fallbackCountryCode = parseCountryCodeInput(body.fallbackCountryCode);
          const weightPercent = parseWeightPercent(body.weightPercent, 70);
          const strict = parseBooleanInput(body.strict, false);

          if (mode !== "random" && !targetCountryCode) {
            writeJson(res, 400, { error: "targetCountryCode_required" });
            return;
          }

          const updates = await Promise.all(
            backends.map((backend) =>
              runtimeStateStore.setTorRoutingConfig(backend.id, {
                mode,
                targetCountryCode,
                fallbackCountryCode,
                weightPercent,
                strict
              })
            )
          );

          await writeAdminAudit({
            req,
            action: "admin_tor_routing_update_all",
            entityType: "tor_instance",
            entityId: "all",
            afterState: {
              mode,
              targetCountryCode,
              fallbackCountryCode,
              weightPercent,
              strict,
              updatedCount: updates.length
            }
          });

          writeJson(res, 200, {
            status: "ok",
            updatedCount: updates.length,
            routing: {
              mode,
              targetCountryCode,
              fallbackCountryCode,
              weightPercent,
              strict,
              updatedAt: new Date().toISOString()
            }
          });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname === "/admin/api/tor-routing/all/reset" && method === "POST") {
        const backends = torManager.getBackends();
        await Promise.all(backends.map((backend) => runtimeStateStore.resetTorRoutingConfig(backend.id)));

        await writeAdminAudit({
          req,
          action: "admin_tor_routing_reset_all",
          entityType: "tor_instance",
          entityId: "all",
          afterState: {
            updatedCount: backends.length
          }
        });

        writeJson(res, 200, { status: "ok", updatedCount: backends.length });
        return;
      }

      if (url.pathname === "/admin/api/tor-routing/bulk" && method === "PATCH") {
        try {
          const body = await readJsonBody(req);
          const rawInstanceIds = Array.isArray(body.instanceIds) ? body.instanceIds : [];
          const instanceIds = rawInstanceIds
            .map((value) => Number.parseInt(String(value), 10))
            .filter((value) => Number.isInteger(value) && value >= 0);

          if (instanceIds.length === 0) {
            writeJson(res, 400, { error: "instance_ids_required" });
            return;
          }

          const backends = torManager.getBackends();
          const allowedIds = new Set(backends.map((backend) => backend.id));
          const validIds = instanceIds.filter((instanceId) => allowedIds.has(instanceId));

          if (validIds.length === 0) {
            writeJson(res, 404, { error: "instance_not_found" });
            return;
          }

          const mode = parseTorRoutingMode(body.mode);
          const targetCountryCode = parseCountryCodeInput(body.targetCountryCode);
          const fallbackCountryCode = parseCountryCodeInput(body.fallbackCountryCode);
          const weightPercent = parseWeightPercent(body.weightPercent, 70);
          const strict = parseBooleanInput(body.strict, false);

          if (mode !== "random" && !targetCountryCode) {
            writeJson(res, 400, { error: "targetCountryCode_required" });
            return;
          }

          const updates = await Promise.all(
            validIds.map((instanceId) =>
              runtimeStateStore.setTorRoutingConfig(instanceId, {
                mode,
                targetCountryCode,
                fallbackCountryCode,
                weightPercent,
                strict
              })
            )
          );

          await writeAdminAudit({
            req,
            action: "admin_tor_routing_update_bulk",
            entityType: "tor_instance",
            entityId: validIds.map((value) => String(value)).join(","),
            afterState: {
              mode,
              targetCountryCode,
              fallbackCountryCode,
              weightPercent,
              strict,
              updatedCount: updates.length
            }
          });

          writeJson(res, 200, {
            status: "ok",
            updatedCount: updates.length,
            instanceIds: validIds,
            routing: {
              mode,
              targetCountryCode,
              fallbackCountryCode,
              weightPercent,
              strict,
              updatedAt: new Date().toISOString()
            }
          });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/tor-routing/") && method === "PATCH") {
        const instanceIdPath = decodeURIComponent(url.pathname.replace("/admin/api/tor-routing/", "")).trim();
        if (!instanceIdPath || instanceIdPath.includes("/")) {
          writeJson(res, 400, { error: "instance_id_required" });
          return;
        }

        const instanceId = Number.parseInt(instanceIdPath, 10);
        if (!Number.isInteger(instanceId) || instanceId < 0) {
          writeJson(res, 400, { error: "invalid_instance_id" });
          return;
        }

        const backend = torManager.getBackends().find((item) => item.id === instanceId);
        if (!backend) {
          writeJson(res, 404, { error: "instance_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const mode = parseTorRoutingMode(body.mode);
          const targetCountryCode = parseCountryCodeInput(body.targetCountryCode);
          const fallbackCountryCode = parseCountryCodeInput(body.fallbackCountryCode);
          const weightPercent = parseWeightPercent(body.weightPercent, 70);
          const strict = parseBooleanInput(body.strict, false);

          if (mode !== "random" && !targetCountryCode) {
            writeJson(res, 400, { error: "targetCountryCode_required" });
            return;
          }

          const updated = await runtimeStateStore.setTorRoutingConfig(instanceId, {
            mode,
            targetCountryCode,
            fallbackCountryCode,
            weightPercent,
            strict
          });

          await writeAdminAudit({
            req,
            action: "admin_tor_routing_update",
            entityType: "tor_instance",
            entityId: String(instanceId),
            afterState: {
              mode: updated.mode,
              targetCountryCode: updated.targetCountryCode,
              fallbackCountryCode: updated.fallbackCountryCode,
              weightPercent: updated.weightPercent,
              strict: updated.strict
            }
          });

          writeJson(res, 200, {
            status: "ok",
            routing: {
              instanceId,
              mode: updated.mode,
              targetCountryCode: updated.targetCountryCode,
              fallbackCountryCode: updated.fallbackCountryCode,
              weightPercent: updated.weightPercent,
              strict: updated.strict,
              updatedAt: updated.updatedAt
            }
          });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/tor-routing/") && url.pathname.endsWith("/reset") && method === "POST") {
        const instanceIdPath = decodeURIComponent(url.pathname.replace("/admin/api/tor-routing/", "").replace("/reset", "")).trim();
        if (!instanceIdPath || instanceIdPath.includes("/")) {
          writeJson(res, 400, { error: "instance_id_required" });
          return;
        }

        const instanceId = Number.parseInt(instanceIdPath, 10);
        if (!Number.isInteger(instanceId) || instanceId < 0) {
          writeJson(res, 400, { error: "invalid_instance_id" });
          return;
        }

        const existing = runtimeStateStore.getTorRoutingConfig(instanceId);
        await runtimeStateStore.resetTorRoutingConfig(instanceId);

        await writeAdminAudit({
          req,
          action: "admin_tor_routing_reset",
          entityType: "tor_instance",
          entityId: String(instanceId),
          beforeState: {
            mode: existing.mode,
            targetCountryCode: existing.targetCountryCode,
            fallbackCountryCode: existing.fallbackCountryCode,
            weightPercent: existing.weightPercent,
            strict: existing.strict
          }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname === "/admin/api/notifications/feed" && method === "GET") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const readerKey = "admin:global";
        const [items, unreadCount] = await Promise.all([
          inAppNotificationsRepo.listFeed({ readerKey, audience: "admin", limit: 80 }),
          inAppNotificationsRepo.countUnread({ readerKey, audience: "admin" })
        ]);

        writeJson(res, 200, {
          notifications: items.map((item) => ({
            id: item.id,
            title: item.title,
            message: item.message,
            type: item.type,
            audience: item.audience,
            isActive: item.is_active,
            startsAt: item.starts_at,
            endsAt: item.ends_at,
            createdAt: item.created_at,
            updatedAt: item.updated_at,
            isRead: item.is_read
          })),
          unreadCount
        });
        return;
      }

      if (url.pathname === "/admin/api/notifications/read-all" && method === "POST") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const markedCount = await inAppNotificationsRepo.markAllRead({
          readerKey: "admin:global",
          audience: "admin"
        });
        writeJson(res, 200, { status: "ok", markedCount });
        return;
      }

      if (url.pathname.startsWith("/admin/api/notifications/") && url.pathname.endsWith("/read") && method === "POST") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const idPath = decodeURIComponent(url.pathname.replace("/admin/api/notifications/", "").replace("/read", "")).trim();
        if (!idPath || idPath.includes("/")) {
          writeJson(res, 400, { error: "notification_id_required" });
          return;
        }

        const existing = await inAppNotificationsRepo.findById(idPath);
        if (!existing) {
          writeJson(res, 404, { error: "notification_not_found" });
          return;
        }

        await inAppNotificationsRepo.markRead(idPath, "admin:global");
        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname === "/admin/api/notifications" && method === "GET") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const rows = await inAppNotificationsRepo.listAll(200);
        writeJson(res, 200, {
          notifications: rows.map((row) => ({
            id: row.id,
            title: row.title,
            message: row.message,
            type: row.type,
            audience: row.audience,
            isActive: row.is_active,
            startsAt: row.starts_at,
            endsAt: row.ends_at,
            createdBy: row.created_by,
            createdAt: row.created_at,
            updatedAt: row.updated_at
          }))
        });
        return;
      }

      if (url.pathname === "/admin/api/notifications" && method === "POST") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const title = sanitizeTicketText(body.title, 120);
          const message = sanitizeTicketText(body.message, 4000);
          const type = parseInAppNotificationType(body.type, "info");
          const audience = parseInAppNotificationAudience(body.audience, "all");
          const isActive = parseBooleanInput(body.isActive, true);
          const startsAt = body.startsAt === null ? null : parseDateInputToUtcIso(body.startsAt, "start");
          const endsAt = body.endsAt === null ? null : parseDateInputToUtcIso(body.endsAt, "end");

          if (!title || !message) {
            writeJson(res, 400, { error: "title_and_message_required" });
            return;
          }

          if (startsAt && endsAt && Date.parse(endsAt) < Date.parse(startsAt)) {
            writeJson(res, 400, { error: "endsAt_must_be_after_startsAt" });
            return;
          }

          const created = await inAppNotificationsRepo.create({
            title,
            message,
            type,
            audience,
            isActive,
            startsAt,
            endsAt,
            createdBy: "admin"
          });

          await writeAdminAudit({
            req,
            action: "admin_notification_create",
            entityType: "in_app_notification",
            entityId: created.id,
            afterState: {
              title: created.title,
              audience: created.audience,
              type: created.type,
              isActive: created.is_active
            }
          });

          writeJson(res, 201, {
            status: "ok",
            notification: {
              id: created.id,
              title: created.title,
              message: created.message,
              type: created.type,
              audience: created.audience,
              isActive: created.is_active,
              startsAt: created.starts_at,
              endsAt: created.ends_at,
              createdAt: created.created_at,
              updatedAt: created.updated_at
            }
          });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/notifications/") && method === "PATCH") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const idPath = decodeURIComponent(url.pathname.replace("/admin/api/notifications/", "")).trim();
        if (!idPath || idPath.includes("/")) {
          writeJson(res, 400, { error: "notification_id_required" });
          return;
        }

        const existing = await inAppNotificationsRepo.findById(idPath);
        if (!existing) {
          writeJson(res, 404, { error: "notification_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const title = typeof body.title === "string" ? sanitizeTicketText(body.title, 120) : existing.title;
          const message = typeof body.message === "string" ? sanitizeTicketText(body.message, 4000) : existing.message;
          const type = parseInAppNotificationType(body.type, existing.type);
          const audience = parseInAppNotificationAudience(body.audience, existing.audience);
          const isActive = parseBooleanInput(body.isActive, existing.is_active);
          const startsAt = Object.prototype.hasOwnProperty.call(body, "startsAt")
            ? (body.startsAt === null ? null : parseDateInputToUtcIso(body.startsAt, "start"))
            : existing.starts_at;
          const endsAt = Object.prototype.hasOwnProperty.call(body, "endsAt")
            ? (body.endsAt === null ? null : parseDateInputToUtcIso(body.endsAt, "end"))
            : existing.ends_at;

          if (!title || !message) {
            writeJson(res, 400, { error: "title_and_message_required" });
            return;
          }

          if (startsAt && endsAt && Date.parse(endsAt) < Date.parse(startsAt)) {
            writeJson(res, 400, { error: "endsAt_must_be_after_startsAt" });
            return;
          }

          const updated = await inAppNotificationsRepo.updateById(idPath, {
            title,
            message,
            type,
            audience,
            isActive,
            startsAt,
            endsAt
          });

          if (!updated) {
            writeJson(res, 404, { error: "notification_not_found" });
            return;
          }

          await writeAdminAudit({
            req,
            action: "admin_notification_update",
            entityType: "in_app_notification",
            entityId: updated.id,
            beforeState: {
              title: existing.title,
              audience: existing.audience,
              type: existing.type,
              isActive: existing.is_active
            },
            afterState: {
              title: updated.title,
              audience: updated.audience,
              type: updated.type,
              isActive: updated.is_active
            }
          });

          writeJson(res, 200, {
            status: "ok",
            notification: {
              id: updated.id,
              title: updated.title,
              message: updated.message,
              type: updated.type,
              audience: updated.audience,
              isActive: updated.is_active,
              startsAt: updated.starts_at,
              endsAt: updated.ends_at,
              createdAt: updated.created_at,
              updatedAt: updated.updated_at
            }
          });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/notifications/") && method === "DELETE") {
        if (!inAppNotificationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const idPath = decodeURIComponent(url.pathname.replace("/admin/api/notifications/", "")).trim();
        if (!idPath || idPath.includes("/")) {
          writeJson(res, 400, { error: "notification_id_required" });
          return;
        }

        const existing = await inAppNotificationsRepo.findById(idPath);
        if (!existing) {
          writeJson(res, 404, { error: "notification_not_found" });
          return;
        }

        const deleted = await inAppNotificationsRepo.deleteById(idPath);
        if (!deleted) {
          writeJson(res, 404, { error: "notification_not_found" });
          return;
        }

        await writeAdminAudit({
          req,
          action: "admin_notification_delete",
          entityType: "in_app_notification",
          entityId: idPath,
          beforeState: {
            title: existing.title,
            audience: existing.audience,
            type: existing.type,
            isActive: existing.is_active
          }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname === "/admin/api/users" && method === "POST") {
        try {
          const body = await readJsonBody(req);
          const username = typeof body.username === "string" ? body.username.trim() : "";
          const password = typeof body.password === "string" ? body.password : "";

          if (!username || !password) {
            writeJson(res, 400, { error: "username_and_password_required" });
            return;
          }

          await runtimeStateStore.upsertUser(username, password);
          await writeAdminAudit({
            req,
            action: "admin_user_upsert_runtime",
            entityType: "runtime_user",
            entityId: username,
            afterState: { username }
          });
          writeJson(res, 201, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_json_body" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/users/") && method === "DELETE") {
        const usernamePath = decodeURIComponent(url.pathname.replace("/admin/api/users/", "")).trim();
        if (usernamePath.includes("/")) {
          writeJson(res, 404, { error: "not_found" });
          return;
        }

        const username = usernamePath;
        if (!username) {
          writeJson(res, 400, { error: "username_required" });
          return;
        }

        const deleted = await runtimeStateStore.deleteUser(username);
        if (!deleted) {
          writeJson(res, 404, { error: "user_not_found" });
          return;
        }

        await writeAdminAudit({
          req,
          action: "admin_user_delete_runtime",
          entityType: "runtime_user",
          entityId: username,
          beforeState: { username }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname === "/admin/api/config" && method === "PATCH") {
        try {
          const body = await readJsonBody(req);
          const maxConcurrent = Number(body.maxConcurrentPerUser);
          if (!Number.isInteger(maxConcurrent) || maxConcurrent < 1) {
            writeJson(res, 400, { error: "maxConcurrentPerUser_must_be_positive_integer" });
            return;
          }

          await runtimeStateStore.setMaxConcurrentPerUser(maxConcurrent);
          await writeAdminAudit({
            req,
            action: "admin_config_update_max_concurrent",
            entityType: "runtime_config",
            entityId: "maxConcurrentPerUser",
            afterState: { maxConcurrentPerUser: maxConcurrent }
          });
          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_json_body" });
        }
        return;
      }

      if (url.pathname === "/admin/api/proxy-hosts" && method === "GET") {
        writeJson(res, 200, {
          ipHost: runtimeStateStore.getProxyIpHost(),
          domains: runtimeStateStore.getProxyDomains()
        });
        return;
      }

      if (url.pathname === "/admin/api/proxy-hosts/ip" && method === "PATCH") {
        try {
          const body = await readJsonBody(req);
          const ipHost = normalizeProxyIpHost(body.ipHost);
          if (!ipHost) {
            writeJson(res, 400, { error: "invalid_proxy_ip_host" });
            return;
          }

          await runtimeStateStore.setProxyIpHost(ipHost);
          await writeAdminAudit({
            req,
            action: "admin_proxy_ip_host_update",
            entityType: "runtime_proxy_host",
            entityId: "ipHost",
            afterState: { ipHost }
          });

          writeJson(res, 200, {
            status: "ok",
            ipHost,
            domains: runtimeStateStore.getProxyDomains()
          });
        } catch {
          writeJson(res, 400, { error: "invalid_json_body" });
        }
        return;
      }

      if (url.pathname === "/admin/api/proxy-hosts/domain" && method === "POST") {
        try {
          const body = await readJsonBody(req);
          const domain = normalizeProxyDomain(body.domain);
          if (!domain) {
            writeJson(res, 400, { error: "invalid_domain" });
            return;
          }

          const domains = await runtimeStateStore.addProxyDomain(domain);
          await writeAdminAudit({
            req,
            action: "admin_proxy_domain_add",
            entityType: "runtime_proxy_domain",
            entityId: domain,
            afterState: { domain }
          });

          writeJson(res, 201, {
            status: "ok",
            ipHost: runtimeStateStore.getProxyIpHost(),
            domains
          });
        } catch (error) {
          const code = String(error instanceof Error ? error.message : "");
          if (code === "invalid_domain") {
            writeJson(res, 400, { error: "invalid_domain" });
            return;
          }

          writeJson(res, 400, { error: "invalid_json_body" });
        }
        return;
      }

      if (url.pathname === "/admin/api/proxy-hosts/domain" && method === "PATCH") {
        try {
          const body = await readJsonBody(req);
          const oldDomain = normalizeProxyDomain(body.oldDomain);
          const newDomain = normalizeProxyDomain(body.newDomain);
          if (!oldDomain || !newDomain) {
            writeJson(res, 400, { error: "invalid_domain" });
            return;
          }

          const domains = await runtimeStateStore.updateProxyDomain(oldDomain, newDomain);
          await writeAdminAudit({
            req,
            action: "admin_proxy_domain_update",
            entityType: "runtime_proxy_domain",
            entityId: oldDomain,
            beforeState: { domain: oldDomain },
            afterState: { domain: newDomain }
          });

          writeJson(res, 200, {
            status: "ok",
            ipHost: runtimeStateStore.getProxyIpHost(),
            domains
          });
        } catch (error) {
          const code = String(error instanceof Error ? error.message : "");
          if (code === "domain_not_found") {
            writeJson(res, 404, { error: "domain_not_found" });
            return;
          }

          if (code === "invalid_domain") {
            writeJson(res, 400, { error: "invalid_domain" });
            return;
          }

          writeJson(res, 400, { error: "invalid_json_body" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/proxy-hosts/domain/") && method === "DELETE") {
        const rawDomain = decodeURIComponent(url.pathname.replace("/admin/api/proxy-hosts/domain/", "")).trim();
        const domain = normalizeProxyDomain(rawDomain);
        if (!domain) {
          writeJson(res, 400, { error: "invalid_domain" });
          return;
        }

        try {
          const domains = await runtimeStateStore.removeProxyDomain(domain);
          await writeAdminAudit({
            req,
            action: "admin_proxy_domain_delete",
            entityType: "runtime_proxy_domain",
            entityId: domain,
            beforeState: { domain }
          });

          writeJson(res, 200, {
            status: "ok",
            ipHost: runtimeStateStore.getProxyIpHost(),
            domains
          });
        } catch (error) {
          const code = String(error instanceof Error ? error.message : "");
          if (code === "domain_not_found") {
            writeJson(res, 404, { error: "domain_not_found" });
            return;
          }

          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname === "/admin/api/plans" && method === "GET") {
        if (!plansRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const plans = await plansRepo.listAll();
        writeJson(res, 200, {
          plans: plans.map((plan) => ({
            id: plan.id,
            code: plan.code,
            name: plan.name,
            billingPeriod: plan.billing_period,
            priceCents: plan.price_cents,
            currency: plan.currency,
            concurrentLimit: plan.concurrent_limit,
            bandwidthLimitBytes: plan.bandwidth_limit_bytes ? Number(plan.bandwidth_limit_bytes) : null,
            description: plan.description,
            isPublic: plan.is_public,
            sortOrder: plan.sort_order,
            trialDays: plan.trial_days,
            whitelistIpLimit: plan.whitelist_ip_limit,
            isActive: plan.is_active
          }))
        });
        return;
      }

      if (url.pathname === "/admin/api/support-integrations" && method === "GET") {
        if (!supportIntegrationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const integrations = await supportIntegrationsRepo.listAll();
        writeJson(res, 200, {
          integrations: integrations.map((item) => ({
            id: item.id,
            provider: item.provider,
            name: item.name,
            isActive: item.is_active,
            telegramChatId: item.telegram_chat_id,
            hasTelegramBotToken: Boolean(item.telegram_bot_token),
            whatsappPhoneNumber: item.whatsapp_phone_number,
            messageTemplate: item.message_template,
            categories: item.categories,
            priorities: item.priorities,
            statuses: item.statuses,
            operatingHours: item.operating_hours,
            metadata: item.metadata,
            createdAt: item.created_at,
            updatedAt: item.updated_at
          }))
        });
        return;
      }

      if (url.pathname === "/admin/api/support-integrations" && method === "POST") {
        if (!supportIntegrationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const providerRaw = typeof body.provider === "string" ? body.provider.trim().toLowerCase() : "";
          const provider: SupportIntegrationProvider | null =
            providerRaw === "telegram" || providerRaw === "whatsapp_click_to_chat"
              ? (providerRaw as SupportIntegrationProvider)
              : null;
          const name = sanitizeTicketText(body.name, 120);
          const telegramBotToken = typeof body.telegramBotToken === "string" ? body.telegramBotToken.trim() : null;
          const telegramChatId = typeof body.telegramChatId === "string" ? body.telegramChatId.trim() : null;
          const whatsappPhoneNumber = typeof body.whatsappPhoneNumber === "string" ? body.whatsappPhoneNumber.trim() : null;

          if (!provider || !name) {
            writeJson(res, 400, { error: "provider_and_name_required" });
            return;
          }

          if (provider === "telegram" && (!telegramBotToken || !telegramChatId)) {
            writeJson(res, 400, { error: "telegram_token_and_chat_id_required" });
            return;
          }

          if (provider === "whatsapp_click_to_chat" && !whatsappPhoneNumber) {
            writeJson(res, 400, { error: "whatsapp_phone_number_required" });
            return;
          }

          const created = await supportIntegrationsRepo.create({
            provider,
            name,
            isActive: typeof body.isActive === "boolean" ? body.isActive : true,
            telegramBotToken,
            telegramChatId,
            whatsappPhoneNumber,
            messageTemplate: typeof body.messageTemplate === "string" ? body.messageTemplate : null,
            categories: parseStringArray(body.categories),
            priorities: parseStringArray(body.priorities),
            statuses: parseStringArray(body.statuses),
            operatingHours: typeof body.operatingHours === "object" && body.operatingHours ? body.operatingHours : {},
            metadata: typeof body.metadata === "object" && body.metadata ? body.metadata : {}
          });

          await writeAdminAudit({
            req,
            action: "admin_support_integration_create",
            entityType: "support_integration",
            entityId: created.id,
            afterState: {
              provider: created.provider,
              name: created.name,
              isActive: created.is_active
            }
          });

          writeJson(res, 201, { status: "ok", integrationId: created.id });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/support-integrations/") && method === "PATCH") {
        if (!supportIntegrationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const integrationId = decodeURIComponent(url.pathname.replace("/admin/api/support-integrations/", "")).trim();
        if (!integrationId || integrationId.includes("/")) {
          writeJson(res, 400, { error: "integration_id_required" });
          return;
        }

        const existing = await supportIntegrationsRepo.findById(integrationId);
        if (!existing) {
          writeJson(res, 404, { error: "support_integration_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          await supportIntegrationsRepo.updateById(integrationId, {
            name: typeof body.name === "string" ? sanitizeTicketText(body.name, 120) : undefined,
            isActive: typeof body.isActive === "boolean" ? body.isActive : undefined,
            telegramBotToken: body.telegramBotToken === undefined ? undefined : typeof body.telegramBotToken === "string" ? body.telegramBotToken.trim() : null,
            telegramChatId: body.telegramChatId === undefined ? undefined : typeof body.telegramChatId === "string" ? body.telegramChatId.trim() : null,
            whatsappPhoneNumber:
              body.whatsappPhoneNumber === undefined
                ? undefined
                : typeof body.whatsappPhoneNumber === "string"
                  ? body.whatsappPhoneNumber.trim()
                  : null,
            messageTemplate:
              body.messageTemplate === undefined
                ? undefined
                : body.messageTemplate === null
                  ? null
                  : typeof body.messageTemplate === "string"
                    ? body.messageTemplate
                    : undefined,
            categories: body.categories === undefined ? undefined : parseStringArray(body.categories),
            priorities: body.priorities === undefined ? undefined : parseStringArray(body.priorities),
            statuses: body.statuses === undefined ? undefined : parseStringArray(body.statuses),
            operatingHours: body.operatingHours === undefined ? undefined : body.operatingHours,
            metadata: body.metadata === undefined ? undefined : body.metadata
          });

          await writeAdminAudit({
            req,
            action: "admin_support_integration_update",
            entityType: "support_integration",
            entityId: integrationId,
            beforeState: {
              provider: existing.provider,
              name: existing.name,
              isActive: existing.is_active
            },
            afterState: body
          });

          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/support-integrations/") && url.pathname.endsWith("/test") && method === "POST") {
        if (!supportIntegrationsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const integrationId = decodeURIComponent(url.pathname.replace("/admin/api/support-integrations/", "").replace("/test", "")).trim();
        if (!integrationId || integrationId.includes("/")) {
          writeJson(res, 400, { error: "integration_id_required" });
          return;
        }

        const integration = await supportIntegrationsRepo.findById(integrationId);
        if (!integration) {
          writeJson(res, 404, { error: "support_integration_not_found" });
          return;
        }

        const testMessage = renderSupportTemplate(integration.message_template, {
          ticketId: "TEST-001",
          subject: "Testing support integration",
          category: "general",
          priority: "medium",
          status: "open",
          username: "admin",
          message: "Pesan uji dari panel admin"
        });

        if (integration.provider === "telegram") {
          if (!integration.telegram_bot_token || !integration.telegram_chat_id) {
            writeJson(res, 400, { error: "telegram_not_fully_configured" });
            return;
          }

          try {
            await sendTelegramMessage(integration.telegram_bot_token, integration.telegram_chat_id, testMessage);
            writeJson(res, 200, { status: "ok", provider: "telegram" });
          } catch {
            writeJson(res, 502, { error: "telegram_send_failed" });
          }
          return;
        }

        if (!integration.whatsapp_phone_number) {
          writeJson(res, 400, { error: "whatsapp_not_fully_configured" });
          return;
        }

        writeJson(res, 200, {
          status: "ok",
          provider: "whatsapp_click_to_chat",
          previewUrl: buildWhatsappClickToChatUrl(integration.whatsapp_phone_number, testMessage)
        });
        return;
      }

      if (url.pathname === "/admin/api/tickets" && method === "GET") {
        if (!supportTicketsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const status = parseSupportTicketStatus(url.searchParams.get("status"));
        const priority = parseSupportTicketPriority(url.searchParams.get("priority"), "medium");
        const category = parseSupportTicketCategory(url.searchParams.get("category"), "general");
        const hasPriorityFilter = typeof url.searchParams.get("priority") === "string";
        const hasCategoryFilter = typeof url.searchParams.get("category") === "string";
        const assignedAdminUserId = (url.searchParams.get("assignedAdminUserId") || "").trim() || undefined;
        const limit = Number.parseInt(url.searchParams.get("limit") ?? "100", 10);
        const offset = Number.parseInt(url.searchParams.get("offset") ?? "0", 10);

        const tickets = await supportTicketsRepo.listForAdmin({
          status: status ?? undefined,
          priority: hasPriorityFilter ? priority : undefined,
          category: hasCategoryFilter ? category : undefined,
          assignedAdminUserId,
          limit,
          offset
        });

        writeJson(res, 200, {
          tickets: tickets.map((item) => ({
            id: item.id,
            userId: item.user_id,
            username: item.username,
            userEmail: item.user_email,
            subject: item.subject,
            category: item.category,
            priority: item.priority,
            status: item.status,
            assignedAdminUserId: item.assigned_admin_user_id,
            messageCount: item.message_count,
            lastMessageAt: item.last_message_at,
            updatedAt: item.updated_at,
            createdAt: item.created_at
          }))
        });
        return;
      }

      if (url.pathname.startsWith("/admin/api/tickets/") && url.pathname.endsWith("/messages") && method === "GET") {
        if (!supportTicketsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const ticketId = decodeURIComponent(url.pathname.replace("/admin/api/tickets/", "").replace("/messages", "")).trim();
        if (!ticketId || ticketId.includes("/")) {
          writeJson(res, 400, { error: "ticket_id_required" });
          return;
        }

        const ticket = await supportTicketsRepo.findById(ticketId);
        if (!ticket) {
          writeJson(res, 404, { error: "ticket_not_found" });
          return;
        }

        const messages = await supportTicketsRepo.listMessages(ticketId, true);
        writeJson(res, 200, {
          ticket: {
            id: ticket.id,
            userId: ticket.user_id,
            subject: ticket.subject,
            category: ticket.category,
            priority: ticket.priority,
            status: ticket.status,
            assignedAdminUserId: ticket.assigned_admin_user_id,
            updatedAt: ticket.updated_at,
            createdAt: ticket.created_at
          },
          messages: messages.map((item) => ({
            id: item.id,
            senderRole: item.sender_role,
            senderUserId: item.sender_user_id,
            senderUsername: item.sender_username,
            channel: item.channel,
            isInternal: item.is_internal,
            message: item.message_text,
            createdAt: item.created_at
          }))
        });
        return;
      }

      if (url.pathname.startsWith("/admin/api/tickets/") && url.pathname.endsWith("/messages") && method === "POST") {
        if (!supportTicketsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const ticketId = decodeURIComponent(url.pathname.replace("/admin/api/tickets/", "").replace("/messages", "")).trim();
        if (!ticketId || ticketId.includes("/")) {
          writeJson(res, 400, { error: "ticket_id_required" });
          return;
        }

        const ticket = await supportTicketsRepo.findById(ticketId);
        if (!ticket) {
          writeJson(res, 404, { error: "ticket_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const message = sanitizeTicketText(body.message, 4000);
          const isInternal = typeof body.isInternal === "boolean" ? body.isInternal : false;
          if (!message) {
            writeJson(res, 400, { error: "message_required" });
            return;
          }

          const createdMessage = await supportTicketsRepo.addMessage({
            ticketId,
            senderUserId: null,
            senderRole: "admin",
            messageText: message,
            channel: "app",
            isInternal
          });

          if (!isInternal) {
            await supportTicketsRepo.updateTicketById(ticketId, {
              status: "waiting_customer"
            });
          }

          await writeAdminAudit({
            req,
            action: "admin_support_ticket_reply",
            entityType: "support_ticket",
            entityId: ticketId,
            afterState: {
              isInternal,
              messageLength: message.length
            }
          });

          writeJson(res, 201, {
            status: "ok",
            message: {
              id: createdMessage.id,
              senderRole: createdMessage.sender_role,
              message: createdMessage.message_text,
              isInternal: createdMessage.is_internal,
              createdAt: createdMessage.created_at
            }
          });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/tickets/") && method === "PATCH") {
        if (!supportTicketsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const ticketId = decodeURIComponent(url.pathname.replace("/admin/api/tickets/", "")).trim();
        if (!ticketId || ticketId.includes("/")) {
          writeJson(res, 400, { error: "ticket_id_required" });
          return;
        }

        const existing = await supportTicketsRepo.findById(ticketId);
        if (!existing) {
          writeJson(res, 404, { error: "ticket_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const parsedStatus = body.status === undefined ? undefined : parseSupportTicketStatus(body.status);
          if (body.status !== undefined && !parsedStatus) {
            writeJson(res, 400, { error: "invalid_ticket_status" });
            return;
          }
          const status = parsedStatus ?? undefined;

          const priority = body.priority === undefined ? undefined : parseSupportTicketPriority(body.priority);
          const category = body.category === undefined ? undefined : parseSupportTicketCategory(body.category);
          const assignedAdminUserId =
            body.assignedAdminUserId === undefined
              ? undefined
              : body.assignedAdminUserId === null
                ? null
                : typeof body.assignedAdminUserId === "string"
                  ? body.assignedAdminUserId.trim() || null
                  : undefined;

          await supportTicketsRepo.updateTicketById(ticketId, {
            status,
            priority,
            category,
            assignedAdminUserId
          });

          await writeAdminAudit({
            req,
            action: "admin_support_ticket_update",
            entityType: "support_ticket",
            entityId: ticketId,
            beforeState: {
              status: existing.status,
              priority: existing.priority,
              category: existing.category,
              assignedAdminUserId: existing.assigned_admin_user_id
            },
            afterState: {
              status,
              priority,
              category,
              assignedAdminUserId
            }
          });

          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname === "/admin/api/payment-channels" && method === "GET") {
        if (!paymentChannelsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const channels = await paymentChannelsRepo.listAll();
        writeJson(res, 200, {
          channels: channels.map((item) => ({
            id: item.id,
            code: item.code,
            name: item.name,
            provider: item.provider,
            accountName: item.account_name,
            accountNumber: item.account_number,
            instructions: item.instructions,
            isActive: item.is_active,
            sortOrder: item.sort_order,
            createdAt: item.created_at
          }))
        });
        return;
      }

      if (url.pathname === "/admin/api/payment-channels" && method === "POST") {
        if (!paymentChannelsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const code = typeof body.code === "string" ? body.code.trim().toLowerCase() : "";
          const name = typeof body.name === "string" ? body.name.trim() : "";
          const provider = typeof body.provider === "string" ? body.provider.trim() : "bank_transfer";
          const accountName = typeof body.accountName === "string" ? body.accountName.trim() : "";
          const accountNumber = typeof body.accountNumber === "string" ? body.accountNumber.trim() : "";
          const instructions = typeof body.instructions === "string" ? body.instructions.trim() : null;
          const isActive = typeof body.isActive === "boolean" ? body.isActive : true;
          const sortOrder = Number.isInteger(Number(body.sortOrder)) ? Number(body.sortOrder) : 100;

          if (!code || !name || !accountName || !accountNumber) {
            writeJson(res, 400, { error: "invalid_payment_channel_payload" });
            return;
          }

          const created = await paymentChannelsRepo.create({
            code,
            name,
            provider,
            accountName,
            accountNumber,
            instructions,
            isActive,
            sortOrder
          });

          await writeAdminAudit({
            req,
            action: "admin_payment_channel_create",
            entityType: "payment_channel",
            entityId: created.id,
            afterState: { code: created.code, name: created.name, provider: created.provider }
          });

          writeJson(res, 201, { status: "ok" });
        } catch (error) {
          if (isUniqueViolation(error)) {
            writeJson(res, 409, { error: "payment_channel_code_exists" });
            return;
          }

          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/payment-channels/") && method === "PATCH") {
        if (!paymentChannelsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const channelId = decodeURIComponent(url.pathname.replace("/admin/api/payment-channels/", "")).trim();
        if (!channelId) {
          writeJson(res, 400, { error: "payment_channel_id_required" });
          return;
        }

        const existing = await paymentChannelsRepo.findById(channelId);
        if (!existing) {
          writeJson(res, 404, { error: "payment_channel_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          await paymentChannelsRepo.updateById(channelId, {
            name: typeof body.name === "string" ? body.name.trim() : undefined,
            provider: typeof body.provider === "string" ? body.provider.trim() : undefined,
            accountName: typeof body.accountName === "string" ? body.accountName.trim() : undefined,
            accountNumber: typeof body.accountNumber === "string" ? body.accountNumber.trim() : undefined,
            instructions:
              body.instructions === undefined
                ? undefined
                : body.instructions === null
                  ? null
                  : typeof body.instructions === "string"
                    ? body.instructions.trim()
                    : undefined,
            isActive: typeof body.isActive === "boolean" ? body.isActive : undefined,
            sortOrder: Number.isInteger(Number(body.sortOrder)) ? Number(body.sortOrder) : undefined
          });

          await writeAdminAudit({
            req,
            action: "admin_payment_channel_update",
            entityType: "payment_channel",
            entityId: channelId,
            beforeState: {
              code: existing.code,
              name: existing.name,
              provider: existing.provider,
              isActive: existing.is_active
            },
            afterState: body
          });

          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/payment-channels/") && method === "DELETE") {
        if (!paymentChannelsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const channelId = decodeURIComponent(url.pathname.replace("/admin/api/payment-channels/", "")).trim();
        if (!channelId) {
          writeJson(res, 400, { error: "payment_channel_id_required" });
          return;
        }

        const existing = await paymentChannelsRepo.findById(channelId);
        if (!existing) {
          writeJson(res, 404, { error: "payment_channel_not_found" });
          return;
        }

        await paymentChannelsRepo.deleteById(channelId);
        await writeAdminAudit({
          req,
          action: "admin_payment_channel_delete",
          entityType: "payment_channel",
          entityId: channelId,
          beforeState: { code: existing.code, name: existing.name }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname === "/admin/api/vouchers" && method === "GET") {
        if (!vouchersRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const vouchers = await vouchersRepo.listAll();
        writeJson(res, 200, {
          vouchers: vouchers.map((item) => ({
            id: item.id,
            code: item.code,
            name: item.name,
            discountType: item.discount_type,
            discountValue: item.discount_value,
            maxRedemptions: item.max_redemptions,
            maxRedemptionsPerUser: item.max_redemptions_per_user,
            startsAt: item.starts_at,
            endsAt: item.ends_at,
            planCode: item.plan_code,
            isActive: item.is_active,
            createdAt: item.created_at,
            updatedAt: item.updated_at
          }))
        });
        return;
      }

      if (url.pathname === "/admin/api/vouchers" && method === "POST") {
        if (!vouchersRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const code = typeof body.code === "string" ? body.code.trim().toUpperCase() : "";
          const name = typeof body.name === "string" ? body.name.trim() : "";
          const discountType = body.discountType === "percent" || body.discountType === "fixed" ? body.discountType : null;
          const discountValue = Number(body.discountValue);
          const maxRedemptions =
            body.maxRedemptions === null || body.maxRedemptions === undefined
              ? null
              : Number.isInteger(Number(body.maxRedemptions))
                ? Number(body.maxRedemptions)
                : NaN;
          const maxRedemptionsPerUser = Number.isInteger(Number(body.maxRedemptionsPerUser))
            ? Number(body.maxRedemptionsPerUser)
            : 1;
          const startsAtIso = parseDateInputToUtcIso(body.startsAt, "start");
          const endsAtIso = parseDateInputToUtcIso(body.endsAt, "end");
          const planCode = typeof body.planCode === "string" && body.planCode.trim() ? body.planCode.trim() : null;
          const isActive = typeof body.isActive === "boolean" ? body.isActive : true;

          if (!code || !name || !discountType || !Number.isInteger(discountValue) || discountValue < 0) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          if ((discountType === "percent" && discountValue > 100) || maxRedemptionsPerUser < 1) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          if (maxRedemptions !== null && (!Number.isInteger(maxRedemptions) || maxRedemptions < 1)) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          const created = await vouchersRepo.create({
            code,
            name,
            discountType,
            discountValue,
            maxRedemptions,
            maxRedemptionsPerUser,
            startsAtIso,
            endsAtIso,
            planCode,
            isActive
          });

          await writeAdminAudit({
            req,
            action: "admin_voucher_create",
            entityType: "voucher",
            entityId: created.id,
            afterState: {
              code: created.code,
              discountType: created.discount_type,
              discountValue: created.discount_value,
              maxRedemptions: created.max_redemptions
            }
          });

          writeJson(res, 201, { status: "ok", voucherId: created.id });
        } catch (error) {
          if (isUniqueViolation(error)) {
            writeJson(res, 409, { error: "voucher_code_exists" });
            return;
          }

          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/vouchers/") && method === "PATCH") {
        if (!vouchersRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const voucherId = decodeURIComponent(url.pathname.replace("/admin/api/vouchers/", "")).trim();
        if (!voucherId) {
          writeJson(res, 400, { error: "voucher_id_required" });
          return;
        }

        const existing = await vouchersRepo.findById(voucherId);
        if (!existing) {
          writeJson(res, 404, { error: "voucher_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const discountType = body.discountType === "percent" || body.discountType === "fixed" ? body.discountType : undefined;
          const discountValue = Number.isInteger(Number(body.discountValue)) ? Number(body.discountValue) : undefined;
          const maxRedemptions =
            body.maxRedemptions === undefined
              ? undefined
              : body.maxRedemptions === null
                ? null
                : Number.isInteger(Number(body.maxRedemptions))
                  ? Number(body.maxRedemptions)
                  : undefined;
          const maxRedemptionsPerUser = Number.isInteger(Number(body.maxRedemptionsPerUser))
            ? Number(body.maxRedemptionsPerUser)
            : undefined;

          if (discountType === "percent" && discountValue !== undefined && discountValue > 100) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          if (discountValue !== undefined && discountValue < 0) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          if (maxRedemptions !== undefined && maxRedemptions !== null && maxRedemptions < 1) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          if (maxRedemptionsPerUser !== undefined && maxRedemptionsPerUser < 1) {
            writeJson(res, 400, { error: "invalid_voucher_payload" });
            return;
          }

          await vouchersRepo.updateById(voucherId, {
            name: typeof body.name === "string" ? body.name.trim() : undefined,
            discountType,
            discountValue,
            maxRedemptions,
            maxRedemptionsPerUser,
            startsAtIso:
              body.startsAt === undefined
                ? undefined
                : body.startsAt === null
                  ? null
                  : parseDateInputToUtcIso(body.startsAt, "start") ?? undefined,
            endsAtIso:
              body.endsAt === undefined
                ? undefined
                : body.endsAt === null
                  ? null
                  : parseDateInputToUtcIso(body.endsAt, "end") ?? undefined,
            planCode:
              body.planCode === undefined
                ? undefined
                : body.planCode === null
                  ? null
                  : typeof body.planCode === "string"
                    ? body.planCode.trim()
                    : undefined,
            isActive: typeof body.isActive === "boolean" ? body.isActive : undefined,
            metadata: body.metadata === undefined ? undefined : body.metadata
          });

          await writeAdminAudit({
            req,
            action: "admin_voucher_update",
            entityType: "voucher",
            entityId: voucherId,
            beforeState: {
              code: existing.code,
              name: existing.name,
              discountType: existing.discount_type,
              discountValue: existing.discount_value,
              isActive: existing.is_active
            },
            afterState: body
          });

          writeJson(res, 200, { status: "ok" });
        } catch (error) {
          if (isUniqueViolation(error)) {
            writeJson(res, 409, { error: "voucher_code_exists" });
            return;
          }

          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/vouchers/") && url.pathname.endsWith("/disable") && method === "POST") {
        if (!vouchersRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const voucherId = decodeURIComponent(
          url.pathname
            .replace("/admin/api/vouchers/", "")
            .replace("/disable", "")
            .replace(/\/$/, "")
        ).trim();

        if (!voucherId) {
          writeJson(res, 400, { error: "voucher_id_required" });
          return;
        }

        const existing = await vouchersRepo.findById(voucherId);
        if (!existing) {
          writeJson(res, 404, { error: "voucher_not_found" });
          return;
        }

        await vouchersRepo.disableById(voucherId);
        await writeAdminAudit({
          req,
          action: "admin_voucher_disable",
          entityType: "voucher",
          entityId: voucherId,
          beforeState: { isActive: existing.is_active },
          afterState: { isActive: false }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname === "/admin/api/affiliates/commissions" && method === "GET") {
        if (!affiliateCommissionsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const commissions = await affiliateCommissionsRepo.listAll(300);
        writeJson(res, 200, {
          commissions: commissions.map((item) => ({
            id: item.id,
            referrerUserId: item.referrer_user_id,
            referredUserId: item.referred_user_id,
            invoiceId: item.invoice_id,
            commissionCents: item.commission_cents,
            status: item.status,
            approvedAt: item.approved_at,
            paidAt: item.paid_at,
            notes: item.notes,
            createdAt: item.created_at,
            updatedAt: item.updated_at
          }))
        });
        return;
      }

      if (url.pathname.startsWith("/admin/api/affiliates/commissions/") && method === "PATCH") {
        if (!affiliateCommissionsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const commissionId = decodeURIComponent(url.pathname.replace("/admin/api/affiliates/commissions/", "")).trim();
        if (!commissionId) {
          writeJson(res, 400, { error: "commission_id_required" });
          return;
        }

        const existing = await affiliateCommissionsRepo.findById(commissionId);
        if (!existing) {
          writeJson(res, 404, { error: "commission_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const status =
            body.status === "pending" ||
            body.status === "approved" ||
            body.status === "paid" ||
            body.status === "rejected"
              ? body.status
              : null;

          if (!status) {
            writeJson(res, 400, { error: "invalid_commission_status" });
            return;
          }

          await affiliateCommissionsRepo.updateStatus(
            commissionId,
            status,
            typeof body.notes === "string" ? body.notes.trim() : undefined
          );

          await writeAdminAudit({
            req,
            action: "admin_affiliate_commission_update",
            entityType: "affiliate_commission",
            entityId: commissionId,
            beforeState: { status: existing.status, notes: existing.notes },
            afterState: { status, notes: body.notes }
          });

          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname === "/admin/api/plans" && method === "POST") {
        if (!plansRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const code = typeof body.code === "string" ? body.code.trim() : "";
          const name = typeof body.name === "string" ? body.name.trim() : "";
          const billingPeriod =
            body.billingPeriod === "weekly" || body.billingPeriod === "monthly" || body.billingPeriod === "yearly"
              ? body.billingPeriod
              : null;
          const priceCents = Number(body.priceCents);
          const concurrentLimit = Number(body.concurrentLimit);
          const isPublic = typeof body.isPublic === "boolean" ? body.isPublic : true;
          const sortOrder = Number.isInteger(Number(body.sortOrder)) ? Number(body.sortOrder) : 100;
          const trialDays = Number.isInteger(Number(body.trialDays)) ? Number(body.trialDays) : 0;
          const whitelistIpLimit = parseWhitelistIpLimit(body.whitelistIpLimit);

          if (!code || !name || !billingPeriod || !Number.isInteger(priceCents) || !Number.isInteger(concurrentLimit)) {
            writeJson(res, 400, { error: "invalid_plan_payload" });
            return;
          }

          if (priceCents < 0 || concurrentLimit < 1 || sortOrder < 0 || trialDays < 0 || whitelistIpLimit < 0) {
            writeJson(res, 400, { error: "invalid_plan_payload" });
            return;
          }

          const created = await plansRepo.create({
            code,
            name,
            billingPeriod,
            priceCents,
            currency: typeof body.currency === "string" && body.currency.trim() ? body.currency.trim() : "IDR",
            concurrentLimit,
            bandwidthLimitBytes:
              body.bandwidthLimitBytes === null || body.bandwidthLimitBytes === undefined
                ? null
                : Number(body.bandwidthLimitBytes),
            description: typeof body.description === "string" ? body.description : null,
            isPublic,
            sortOrder,
            trialDays,
            whitelistIpLimit,
            isActive: typeof body.isActive === "boolean" ? body.isActive : true
          });

          await writeAdminAudit({
            req,
            action: "admin_plan_create",
            entityType: "plan",
            entityId: created.id,
            afterState: { code: created.code, name: created.name }
          });

          writeJson(res, 201, {
            status: "ok",
            plan: {
              id: created.id,
              code: created.code,
              name: created.name,
              billingPeriod: created.billing_period,
              priceCents: created.price_cents,
              currency: created.currency,
              concurrentLimit: created.concurrent_limit,
              isPublic: created.is_public,
              sortOrder: created.sort_order,
              trialDays: created.trial_days,
              whitelistIpLimit: created.whitelist_ip_limit,
              isActive: created.is_active
            }
          });
        } catch (error) {
          if (isUniqueViolation(error)) {
            writeJson(res, 409, { error: "plan_code_exists" });
            return;
          }

          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/plans/") && method === "PATCH") {
        if (!plansRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const planId = decodeURIComponent(url.pathname.replace("/admin/api/plans/", "")).trim();
        if (!planId) {
          writeJson(res, 400, { error: "plan_id_required" });
          return;
        }

        const existing = await plansRepo.findById(planId);
        if (!existing) {
          writeJson(res, 404, { error: "plan_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          await plansRepo.updateById(planId, {
            name: typeof body.name === "string" ? body.name : undefined,
            priceCents: Number.isInteger(Number(body.priceCents)) ? Number(body.priceCents) : undefined,
            concurrentLimit: Number.isInteger(Number(body.concurrentLimit)) ? Number(body.concurrentLimit) : undefined,
            bandwidthLimitBytes:
              body.bandwidthLimitBytes === undefined
                ? undefined
                : body.bandwidthLimitBytes === null
                  ? null
                  : Number(body.bandwidthLimitBytes),
            description:
              body.description === undefined
                ? undefined
                : body.description === null
                  ? null
                  : typeof body.description === "string"
                    ? body.description
                    : undefined,
            isPublic: typeof body.isPublic === "boolean" ? body.isPublic : undefined,
            sortOrder: Number.isInteger(Number(body.sortOrder)) ? Number(body.sortOrder) : undefined,
            trialDays: Number.isInteger(Number(body.trialDays)) ? Number(body.trialDays) : undefined,
            whitelistIpLimit: body.whitelistIpLimit === undefined ? undefined : parseWhitelistIpLimit(body.whitelistIpLimit),
            isActive: typeof body.isActive === "boolean" ? body.isActive : undefined
          });

          await writeAdminAudit({
            req,
            action: "admin_plan_update",
            entityType: "plan",
            entityId: planId,
            beforeState: {
              name: existing.name,
              priceCents: existing.price_cents,
              concurrentLimit: existing.concurrent_limit,
              isActive: existing.is_active
            },
            afterState: body
          });

          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname === "/admin/api/subscriptions" && method === "GET") {
        if (!subscriptionsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const subscriptions = await subscriptionsRepo.listAll();
        const staleCutoff = Date.now() - 24 * 60 * 60 * 1000;
        const visibleSubscriptions = subscriptions.filter((sub) => {
          if (sub.status !== "pending") {
            return true;
          }

          const createdAtMs = new Date(sub.starts_at).getTime();
          return Number.isFinite(createdAtMs) && createdAtMs >= staleCutoff;
        });

        writeJson(res, 200, {
          subscriptions: visibleSubscriptions.map((sub) => ({
            id: sub.id,
            userId: sub.user_id,
            planId: sub.plan_id,
            status: sub.status,
            startsAt: sub.starts_at,
            endsAt: sub.ends_at,
            graceUntil: sub.grace_until,
            autoRenew: sub.auto_renew,
            externalRef: sub.external_ref
          }))
        });
        return;
      }

      if (url.pathname.startsWith("/admin/api/subscriptions/") && method === "PATCH") {
        if (!subscriptionsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const subscriptionId = decodeURIComponent(url.pathname.replace("/admin/api/subscriptions/", "")).trim();
        if (!subscriptionId) {
          writeJson(res, 400, { error: "subscription_id_required" });
          return;
        }

        const current = await subscriptionsRepo.findById(subscriptionId);
        if (!current) {
          writeJson(res, 404, { error: "subscription_not_found" });
          return;
        }

        try {
          const body = await readJsonBody(req);
          const status =
            body.status === "pending" ||
            body.status === "active" ||
            body.status === "past_due" ||
            body.status === "grace" ||
            body.status === "expired" ||
            body.status === "canceled" ||
            body.status === "trial"
              ? body.status
              : null;

          if (!status) {
            writeJson(res, 400, { error: "invalid_subscription_status" });
            return;
          }

          await subscriptionsRepo.setStatus(subscriptionId, status);
          await writeAdminAudit({
            req,
            action: "admin_subscription_status_update",
            entityType: "subscription",
            entityId: subscriptionId,
            beforeState: { status: current.status },
            afterState: { status }
          });

          writeJson(res, 200, { status: "ok" });
        } catch {
          writeJson(res, 400, { error: "invalid_request" });
        }
        return;
      }

      if (url.pathname === "/admin/api/invoices" && method === "GET") {
        if (!invoicesRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const invoices = await invoicesRepo.listAll();
        const staleCutoff = Date.now() - 24 * 60 * 60 * 1000;
        const visibleInvoices = invoices.filter((invoice) => {
          if (invoice.status !== "pending" && invoice.status !== "awaiting_payment") {
            return true;
          }

          const createdAtMs = new Date(invoice.created_at).getTime();
          return Number.isFinite(createdAtMs) && createdAtMs >= staleCutoff;
        });

        writeJson(res, 200, {
          invoices: visibleInvoices.map((invoice) => ({
            id: invoice.id,
            invoiceNumber: invoice.invoice_number,
            userId: invoice.user_id,
            subscriptionId: invoice.subscription_id,
            status: invoice.status,
            amountCents: invoice.final_amount_cents,
            subtotalCents: invoice.amount_cents,
            discountCents: invoice.discount_cents,
            voucherCode: invoice.voucher_code,
            currency: invoice.currency,
            dueAt: invoice.due_at,
            paidAt: invoice.paid_at,
            provider: invoice.provider,
            providerRef: invoice.provider_ref,
            createdAt: invoice.created_at
          }))
        });
        return;
      }

      if (url.pathname.startsWith("/admin/api/invoices/") && url.pathname.endsWith("/verify-bank-transfer") && method === "POST") {
        if (!billingService) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const invoiceId = decodeURIComponent(
          url.pathname
            .replace("/admin/api/invoices/", "")
            .replace("/verify-bank-transfer", "")
            .replace(/\/$/, "")
        ).trim();

        if (!invoiceId) {
          writeJson(res, 400, { error: "invoice_id_required" });
          return;
        }

        try {
          const verifyResult = await billingService.verifyBankTransfer(invoiceId);
          await writeAdminAudit({
            req,
            action: "admin_verify_bank_transfer",
            entityType: "invoice",
            entityId: invoiceId,
            afterState: { status: "paid" }
          });

          if (notificationService && usersRepo && verifyResult.justPaid) {
            const user = await usersRepo.findById(verifyResult.userId);
            if (user?.email) {
              await notificationService.enqueueEmail({
                userId: user.id,
                email: user.email,
                templateCode: "invoice_paid",
                payload: {
                  username: user.username,
                  invoiceNumber: verifyResult.invoiceNumber
                },
                idempotencyKey: `invoice_paid:${invoiceId}`
              });
            }
          }

          writeJson(res, 200, { status: "ok" });
        } catch (error) {
          const message = String(error);
          if (message.includes("invoice_not_found")) {
            writeJson(res, 404, { error: "invoice_not_found" });
            return;
          }

          if (message.includes("invoice_provider_not_bank_transfer")) {
            writeJson(res, 400, { error: "invoice_not_bank_transfer" });
            return;
          }

          writeJson(res, 400, { error: "verify_bank_transfer_failed" });
        }
        return;
      }

      if (url.pathname === "/admin/api/audit-logs" && method === "GET") {
        if (!auditLogsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const limit = Number.parseInt(url.searchParams.get("limit") ?? "100", 10);
        const logs = await auditLogsRepo.listRecent(Number.isInteger(limit) && limit > 0 ? Math.min(limit, 500) : 100);
        writeJson(res, 200, {
          logs: logs.map((log) => ({
            id: log.id,
            action: log.action,
            entityType: log.entity_type,
            entityId: log.entity_id,
            beforeState: log.before_state,
            afterState: log.after_state,
            ipAddress: log.ip_address,
            createdAt: log.created_at
          }))
        });
        return;
      }

      if (url.pathname === "/admin/api/dashboard" && method === "GET") {
        if (!isBillingEnabled(db, usersRepo, plansRepo)) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const userStats = await db!.query<{ count: number }>(
            `SELECT COUNT(*) AS count FROM users`
          );
          const subStats = await db!.query<{ count: number }>(
            `SELECT COUNT(*) AS count FROM subscriptions WHERE status = 'active'`
          );
          const invoiceStats = await db!.query<{ count: number }>(
            `SELECT COUNT(*) AS count FROM invoices WHERE status = 'pending'`
          );
          const revenueStats = await db!.query<{ total: number }>(
            `SELECT COALESCE(SUM(amount_cents), 0) AS total FROM invoices WHERE status = 'paid'`
          );
          const relaySummary = buildRelayConnectivitySummary(torManager.getBackends());

          writeJson(res, 200, {
            total_users: Number(userStats[0]?.count ?? 0),
            active_subscriptions: Number(subStats[0]?.count ?? 0),
            pending_invoices: Number(invoiceStats[0]?.count ?? 0),
            total_revenue: Number((revenueStats[0]?.total ?? 0) / 100),
            relay_connectivity: relaySummary
          });
        } catch (error) {
          writeJson(res, 500, { error: "dashboard_load_failed" });
        }
        return;
      }

      if (url.pathname === "/admin/api/users" && method === "GET") {
        if (!isBillingEnabled(db, usersRepo, plansRepo)) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const users = await db!.query<{
            id: string;
            username: string;
            email: string | null;
            status: string;
            created_at: string;
            plan_name: string | null;
            sub_status: string | null;
            profile_complete: boolean;
          }>(
            `SELECT
              u.id,
              u.username,
              u.email,
              u.status,
              u.created_at,
              p.name AS plan_name,
              s.status AS sub_status,
              (u.email IS NOT NULL AND u.bank_name IS NOT NULL AND u.bank_account_name IS NOT NULL AND u.bank_account_number IS NOT NULL) AS profile_complete
            FROM users u
            LEFT JOIN LATERAL (
              SELECT id, plan_id, status
              FROM subscriptions
              WHERE user_id = u.id
              ORDER BY ends_at DESC
              LIMIT 1
            ) s ON TRUE
            LEFT JOIN plans p ON p.id = s.plan_id
            ORDER BY u.created_at DESC`
          );

          writeJson(res, 200, users);
        } catch (error) {
          writeJson(res, 500, { error: "users_load_failed" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/users/") && url.pathname.endsWith("/detail") && method === "GET") {
        if (!isBillingEnabled(db, usersRepo, plansRepo) || !usersRepo || !subscriptionsRepo || !invoicesRepo || !affiliateCommissionsRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const userId = decodeURIComponent(url.pathname.replace("/admin/api/users/", "").replace("/detail", "")).trim();
        if (!userId) {
          writeJson(res, 400, { error: "user_id_required" });
          return;
        }

        const user = await usersRepo.findById(userId);
        if (!user) {
          writeJson(res, 404, { error: "user_not_found" });
          return;
        }

        const latestSubscription = await subscriptionsRepo.findLatestByUserId(userId);
        const recentInvoices = await invoicesRepo.listByUser(userId);
        const affiliateSummary = await affiliateCommissionsRepo.summarizeByReferrerUserId(userId);

        writeJson(res, 200, {
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            bankName: user.bank_name,
            bankAccountName: user.bank_account_name,
            bankAccountNumber: user.bank_account_number,
            profileAddress: user.profile_address,
            status: user.status,
            referralCode: user.referral_code,
            referredByUserId: user.referred_by_user_id,
            createdAt: user.created_at,
            updatedAt: user.updated_at,
            profileComplete: Boolean(user.email && user.bank_name && user.bank_account_name && user.bank_account_number)
          },
          latestSubscription,
          recentInvoices: recentInvoices.slice(0, 5),
          affiliateSummary
        });
        return;
      }

      if (url.pathname.startsWith("/admin/api/users/") && url.pathname.endsWith("/suspend") && method === "POST") {
        if (!usersRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const userId = decodeURIComponent(url.pathname.replace("/admin/api/users/", "").replace("/suspend", "")).trim();
        if (!userId) {
          writeJson(res, 400, { error: "user_id_required" });
          return;
        }

        const existing = await usersRepo.findById(userId);
        if (!existing) {
          writeJson(res, 404, { error: "user_not_found" });
          return;
        }

        await usersRepo.setStatus(userId, "suspended");
        await writeAdminAudit({
          req,
          action: "admin_user_suspend",
          entityType: "user",
          entityId: userId,
          beforeState: { status: existing.status },
          afterState: { status: "suspended" }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname.startsWith("/admin/api/users/") && url.pathname.endsWith("/delete") && method === "POST") {
        if (!usersRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        const userId = decodeURIComponent(url.pathname.replace("/admin/api/users/", "").replace("/delete", "")).trim();
        if (!userId) {
          writeJson(res, 400, { error: "user_id_required" });
          return;
        }

        const existing = await usersRepo.findById(userId);
        if (!existing) {
          writeJson(res, 404, { error: "user_not_found" });
          return;
        }

        await usersRepo.deleteById(userId);
        await writeAdminAudit({
          req,
          action: "admin_user_delete",
          entityType: "user",
          entityId: userId,
          beforeState: { username: existing.username, status: existing.status }
        });

        writeJson(res, 200, { status: "ok" });
        return;
      }

      if (url.pathname.startsWith("/admin/api/plans/") && url.pathname.endsWith("/delete") && method === "POST") {
        if (!isBillingEnabled(db, usersRepo, plansRepo)) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const planId = decodeURIComponent(url.pathname.replace("/admin/api/plans/", "").replace("/delete", "")).trim();
          const existing = await plansRepo!.findById(planId);
          if (!existing) {
            writeJson(res, 404, { error: "plan_not_found" });
            return;
          }

          const references = await plansRepo!.countReferences(planId);
          if (references > 0) {
            writeJson(res, 409, { error: "plan_in_use" });
            return;
          }

          await plansRepo!.deleteById(planId);
          await writeAdminAudit({
            req,
            action: "admin_plan_delete",
            entityType: "plan",
            entityId: planId,
            beforeState: {
              code: existing.code,
              name: existing.name,
              billingPeriod: existing.billing_period,
              isActive: existing.is_active
            }
          });

          writeJson(res, 200, { success: true });
        } catch (error) {
          writeJson(res, 500, { error: "delete_plan_failed" });
        }
        return;
      }

      if (url.pathname.startsWith("/admin/api/invoices/") && url.pathname.endsWith("/mark-paid") && method === "POST") {
        if (!isBillingEnabled(db, usersRepo, plansRepo) || !invoicesRepo) {
          writeJson(res, 503, { error: "billing_not_configured" });
          return;
        }

        try {
          const invoiceId = decodeURIComponent(url.pathname.replace("/admin/api/invoices/", "").replace("/mark-paid", "")).trim();
          if (!invoiceId) {
            writeJson(res, 400, { error: "invoice_id_required" });
            return;
          }

          const invoice = await invoicesRepo.findById(invoiceId);
          if (!invoice) {
            writeJson(res, 404, { error: "invoice_not_found" });
            return;
          }

          await invoicesRepo.setPaid(invoiceId, null);
          if (invoice.subscription_id && subscriptionsRepo) {
            await subscriptionsRepo.activate(invoice.subscription_id);
          }

          await writeAdminAudit({
            req,
            action: "admin_invoice_mark_paid",
            entityType: "invoice",
            entityId: invoiceId,
            beforeState: { status: invoice.status },
            afterState: { status: "paid" }
          });

          writeJson(res, 200, { success: true });
        } catch (error) {
          writeJson(res, 500, { error: "mark_paid_failed" });
        }
        return;
      }

      // --- Worker Registry Admin API (Multi-Server Phase 3) ---
      if (url.pathname === "/admin/api/workers" && method === "GET") {
        if (!workerRegistry) {
          writeJson(res, 503, { error: "worker_registry_not_available" });
          return;
        }

        const workers = await workerRegistry.getAllWorkers();
        writeJson(res, 200, { workers });
        return;
      }

      if (url.pathname === "/admin/api/workers/stats" && method === "GET") {
        if (!workerRegistry) {
          writeJson(res, 503, { error: "worker_registry_not_available" });
          return;
        }

        const stats = await workerRegistry.getClusterStats();
        writeJson(res, 200, { stats });
        return;
      }

      if (url.pathname === "/admin/api/workers/cleanup" && method === "POST") {
        if (!workerRegistry) {
          writeJson(res, 503, { error: "worker_registry_not_available" });
          return;
        }

        const removed = await workerRegistry.cleanupStaleWorkers();
        writeJson(res, 200, { status: "ok", removedCount: removed });
        return;
      }

      // --- Smart Router Admin API (Phase 7) ---
      if (url.pathname === "/admin/api/routing/resolve" && method === "POST") {
        if (!smartRouter) { writeJson(res, 503, { error: "smart_router_not_available" }); return; }
        try {
          const body = await readJsonBody(req);
          const username = typeof body.username === "string" ? body.username.trim() : "";
          const clientRegion = typeof body.clientRegion === "string" ? body.clientRegion.trim() : undefined;
          if (!username) { writeJson(res, 400, { error: "username_required" }); return; }
          const assignment = await smartRouter.resolve(username, { clientRegion });
          writeJson(res, 200, { assignment });
        } catch { writeJson(res, 400, { error: "invalid_request" }); }
        return;
      }

      if (url.pathname === "/admin/api/routing/override" && method === "POST") {
        if (!smartRouter) { writeJson(res, 503, { error: "smart_router_not_available" }); return; }
        try {
          const body = await readJsonBody(req);
          const username = typeof body.username === "string" ? body.username.trim() : "";
          const workerId = typeof body.workerId === "string" ? body.workerId.trim() : "";
          if (!username || !workerId) { writeJson(res, 400, { error: "username_and_workerId_required" }); return; }
          await smartRouter.setOveride(username, workerId);
          writeJson(res, 200, { status: "ok" });
        } catch { writeJson(res, 400, { error: "invalid_request" }); }
        return;
      }

      if (url.pathname === "/admin/api/routing/override" && method === "DELETE") {
        if (!smartRouter) { writeJson(res, 503, { error: "smart_router_not_available" }); return; }
        try {
          const body = await readJsonBody(req);
          const username = typeof body.username === "string" ? body.username.trim() : "";
          if (!username) { writeJson(res, 400, { error: "username_required" }); return; }
          await smartRouter.clearOverride(username);
          writeJson(res, 200, { status: "ok" });
        } catch { writeJson(res, 400, { error: "invalid_request" }); }
        return;
      }

      if (url.pathname.startsWith("/admin/api/routing/assignment/") && method === "GET") {
        if (!smartRouter) { writeJson(res, 503, { error: "smart_router_not_available" }); return; }
        const username = decodeURIComponent(url.pathname.replace("/admin/api/routing/assignment/", "")).trim();
        if (!username) { writeJson(res, 400, { error: "username_required" }); return; }
        const assignment = await smartRouter.getAssignment(username);
        writeJson(res, 200, { assignment });
        return;
      }

      // --- Command Dispatcher Admin API (Phase 7) ---
      if (url.pathname === "/admin/api/commands/dispatch" && method === "POST") {
        if (!commandDispatcher) { writeJson(res, 503, { error: "command_dispatcher_not_available" }); return; }
        try {
          const body = await readJsonBody(req);
          const workerId = typeof body.workerId === "string" ? body.workerId.trim() : "";
          const action = typeof body.action === "string" ? body.action.trim() : "";
          const payload = typeof body.payload === "object" && body.payload ? body.payload as Record<string, unknown> : {};
          const validActions: CommandAction[] = ["rotate_all", "update_config", "shutdown", "ping"];
          if (!workerId || !action || !validActions.includes(action as CommandAction)) {
            writeJson(res, 400, { error: "workerId_and_valid_action_required" }); return;
          }
          const command = await commandDispatcher.dispatch(workerId, action as CommandAction, payload);
          await writeAdminAudit({ req, action: "admin_command_dispatch", entityType: "worker_command", entityId: command.id, afterState: { workerId, action }});
          writeJson(res, 201, { status: "ok", command });
        } catch { writeJson(res, 400, { error: "invalid_request" }); }
        return;
      }

      if (url.pathname === "/admin/api/commands/dispatch-all" && method === "POST") {
        if (!commandDispatcher) { writeJson(res, 503, { error: "command_dispatcher_not_available" }); return; }
        try {
          const body = await readJsonBody(req);
          const action = typeof body.action === "string" ? body.action.trim() : "";
          const payload = typeof body.payload === "object" && body.payload ? body.payload as Record<string, unknown> : {};
          const validActions: CommandAction[] = ["rotate_all", "update_config", "shutdown", "ping"];
          if (!action || !validActions.includes(action as CommandAction)) {
            writeJson(res, 400, { error: "valid_action_required" }); return;
          }
          const commands = await commandDispatcher.dispatchToAll(action as CommandAction, payload);
          await writeAdminAudit({ req, action: "admin_command_dispatch_all", entityType: "worker_command", entityId: "all", afterState: { action, workerCount: commands.length } });
          writeJson(res, 201, { status: "ok", commands });
        } catch { writeJson(res, 400, { error: "invalid_request" }); }
        return;
      }

      if (url.pathname.startsWith("/admin/api/commands/result/") && method === "GET") {
        if (!commandDispatcher) { writeJson(res, 503, { error: "command_dispatcher_not_available" }); return; }
        const commandId = decodeURIComponent(url.pathname.replace("/admin/api/commands/result/", "")).trim();
        if (!commandId) { writeJson(res, 400, { error: "command_id_required" }); return; }
        const result = await commandDispatcher.getResult(commandId);
        writeJson(res, 200, { result });
        return;
      }

      if (url.pathname.startsWith("/admin/api/commands/history/") && method === "GET") {
        if (!commandDispatcher) { writeJson(res, 503, { error: "command_dispatcher_not_available" }); return; }
        const workerId = decodeURIComponent(url.pathname.replace("/admin/api/commands/history/", "")).trim();
        if (!workerId) { writeJson(res, 400, { error: "worker_id_required" }); return; }
        const limit = Number.parseInt(url.searchParams.get("limit") ?? "50", 10);
        const history = await commandDispatcher.getCommandHistory(workerId, limit);
        writeJson(res, 200, { history });
        return;
      }

      if (url.pathname.startsWith("/admin/api/commands/pending/") && method === "GET") {
        if (!commandDispatcher) { writeJson(res, 503, { error: "command_dispatcher_not_available" }); return; }
        const workerId = decodeURIComponent(url.pathname.replace("/admin/api/commands/pending/", "")).trim();
        if (!workerId) { writeJson(res, 400, { error: "worker_id_required" }); return; }
        const pending = await commandDispatcher.getPendingCommands(workerId);
        writeJson(res, 200, { pending });
        return;
      }

      writeJson(res, 404, { error: "not_found" });
      return;
    }

    writeJson(res, 404, { error: "not_found" });
  });

  adminServer.listen(config.adminPort, config.host, () => {
    logger.info("admin endpoint started", {
      host: config.host,
      port: config.adminPort
    });
  });

  const shutdown = async () => {
    logger.info("shutting down");
    healthMonitor.stop();
    await Promise.allSettled([httpGateway.close(), socksGateway.close()]);
    await torManager.stop();
    if (workerAgent) {
      await workerAgent.stop();
    }
    if (outboxWorker) {
      outboxWorker.stop();
    }
    if (db) {
      await db.close();
    }
    if (redis) {
      redis.disconnect();
    }
    adminServer.close();
    process.exit(0);
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

start().catch((error: unknown) => {
  logger.error("startup failed", { error: String(error) });
  process.exit(1);
});
