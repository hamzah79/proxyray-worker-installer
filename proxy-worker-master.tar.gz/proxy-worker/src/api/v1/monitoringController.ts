import { metricsCollector } from "../../observability/metrics";
import type { ApiContext } from "./apiController";

/**
 * GET /api/v1/monitoring/summary - Get comprehensive monitoring summary
 */
export async function getMonitoringSummary(ctx: ApiContext): Promise<any> {
  const globalMetrics = metricsCollector.getGlobalMetrics();
  const backendMetrics = metricsCollector.getBackendMetrics();
  const healthyBackends = ctx.backends.filter(b => b.healthy);
  
  return {
    status: healthyBackends.length > 0 ? 'operational' : 'degraded',
    timestamp: new Date().toISOString(),
    uptime: getUptimeString(globalMetrics.lastResetAt),
    
    performance: {
      totalRequests: globalMetrics.totalRequests,
      successRate: metricsCollector.getSuccessRate().toFixed(2) + '%',
      avgResponseTime: Math.round(globalMetrics.avgResponseTime) + 'ms',
      requestsPerMinute: globalMetrics.requestsPerMinute
    },
    
    backends: {
      total: ctx.backends.length,
      healthy: healthyBackends.length,
      unhealthy: ctx.backends.length - healthyBackends.length,
      healthPercentage: ctx.backends.length > 0 
        ? ((healthyBackends.length / ctx.backends.length) * 100).toFixed(1) + '%'
        : '0%'
    },
    
    topBackends: backendMetrics
      .sort((a, b) => b.requests - a.requests)
      .slice(0, 5)
      .map(m => ({
        backendId: m.backendId,
        requests: m.requests,
        successRate: m.requests > 0 ? ((m.successes / m.requests) * 100).toFixed(1) + '%' : '0%',
        avgResponseTime: Math.round(m.avgResponseTime) + 'ms',
        isHealthy: m.isHealthy
      })),
    
    alerts: ctx.alertManager ? ctx.alertManager.getActiveAlerts() : []
  };
}

/**
 * GET /api/v1/monitoring/backends - Get detailed backend status
 */
export async function getBackendStatus(ctx: ApiContext): Promise<any> {
  const backendMetrics = metricsCollector.getBackendMetrics();
  const metricsMap = new Map(backendMetrics.map(m => [m.backendId, m]));
  
  const backends = ctx.backends.map(backend => {
    const metrics = metricsMap.get(String(backend.id));
    
    return {
      id: backend.id,
      socksPort: backend.socksPort,
      controlPort: backend.controlPort,
      healthy: backend.healthy,
      exitIp: backend.exitIp || null,
      country: backend.countryCode || null,
      countryName: backend.countryName || null,
      lastCheckedAt: backend.lastCheckedAt || null,
      
      metrics: metrics ? {
        requests: metrics.requests,
        successes: metrics.successes,
        failures: metrics.failures,
        successRate: metrics.requests > 0 
          ? ((metrics.successes / metrics.requests) * 100).toFixed(1) + '%'
          : '0%',
        avgResponseTime: Math.round(metrics.avgResponseTime) + 'ms',
        lastUsedAt: metrics.lastUsedAt
      } : null
    };
  });
  
  return {
    total: backends.length,
    backends: backends.sort((a, b) => {
      // Sort by healthy first, then by request count
      if (a.healthy !== b.healthy) return a.healthy ? -1 : 1;
      const aReqs = a.metrics?.requests || 0;
      const bReqs = b.metrics?.requests || 0;
      return bReqs - aReqs;
    }),
    timestamp: new Date().toISOString()
  };
}

/**
 * GET /api/v1/monitoring/alerts - Get active alerts
 */
export async function getActiveAlerts(ctx: ApiContext): Promise<any> {
  if (!ctx.alertManager) {
    return {
      enabled: false,
      message: 'Alert manager not configured'
    };
  }
  
  const alerts = ctx.alertManager.getActiveAlerts();
  
  return {
    enabled: true,
    count: alerts.length,
    alerts: alerts.map(alert => ({
      ...alert,
      triggeredAt: new Date(alert.triggeredAt).toISOString(),
      age: formatDuration(Date.now() - alert.triggeredAt)
    })),
    timestamp: new Date().toISOString()
  };
}

/**
 * POST /api/v1/monitoring/metrics/reset - Reset metrics
 */
export async function resetMetrics(): Promise<any> {
  metricsCollector.reset();
  
  return {
    success: true,
    message: 'Metrics have been reset',
    timestamp: new Date().toISOString()
  };
}

/**
 * Helper: Format uptime duration
 */
function getUptimeString(startDate: Date): string {
  const uptimeMs = Date.now() - startDate.getTime();
  const days = Math.floor(uptimeMs / 86400000);
  const hours = Math.floor((uptimeMs % 86400000) / 3600000);
  const minutes = Math.floor((uptimeMs % 3600000) / 60000);
  
  if (days > 0) {
    return `${days}d ${hours}h ${minutes}m`;
  } else if (hours > 0) {
    return `${hours}h ${minutes}m`;
  } else {
    return `${minutes}m`;
  }
}

/**
 * Helper: Format duration
 */
function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m ago`;
  } else if (minutes > 0) {
    return `${minutes}m ago`;
  } else {
    return `${seconds}s ago`;
  }
}
