import * as http from 'node:http';
import type { TorBackend } from '../../types';
import type { UsageTracker, UsageSummary } from '../../billing/usageTracker';
import type { MetricsCollector } from '../../observability/metricsCollector';
import type { CircuitBreakerManager } from '../../utils/circuitBreakerManager';
import type { ConnectionPool } from '../../utils/connectionPool';
import type { RequestQueue } from '../../utils/requestQueue';
import { metricsCollector } from '../../observability/metrics';
import type { AlertManager } from '../../observability/alerts';

/**
 * API v1 Controllers for developer-friendly endpoints
 */

export interface ApiContext {
  backends: TorBackend[];
  usageTracker: UsageTracker | null;
  metricsCollector: MetricsCollector | null;
  circuitBreaker: CircuitBreakerManager;
  connectionPool: ConnectionPool;
  requestQueue: RequestQueue;
  alertManager?: AlertManager;
  userId: string;
  username: string;
}

/**
 * GET /api/v1/ip/current - Get current exit IP info
 */
export async function getCurrentIp(ctx: ApiContext): Promise<any> {
  const healthyBackends = ctx.backends.filter(b => b.healthy);
  
  if (healthyBackends.length === 0) {
    return {
      error: 'No healthy backends available',
      available: false,
    };
  }

  // Get a random healthy backend to show
  const backend = healthyBackends[Math.floor(Math.random() * healthyBackends.length)];

  return {
    available: true,
    totalBackends: ctx.backends.length,
    healthyBackends: healthyBackends.length,
    sample: {
      ip: backend.exitIp || 'unknown',
      country: backend.countryCode || 'unknown',
      countryName: backend.countryName || 'Unknown',
      backendId: backend.id,
    },
  };
}

/**
 * POST /api/v1/ip/rotate - Force IP rotation (clear session)
 */
export async function rotateIp(sessionId: string | null): Promise<any> {
  if (!sessionId) {
    return {
      success: false,
      message: 'No session ID provided. Use X-Proxy-Session header to enable session tracking.',
    };
  }

  // Session will be cleared by the balancer
  return {
    success: true,
    message: 'Session cleared. Next request will use a new IP.',
    sessionId,
  };
}

/**
 * GET /api/v1/countries - List available exit countries
 */
export async function getAvailableCountries(ctx: ApiContext): Promise<any> {
  const healthyBackends = ctx.backends.filter(b => b.healthy);
  
  const countryMap = new Map<string, { code: string; name: string; count: number }>();
  
  for (const backend of healthyBackends) {
    const code = backend.countryCode?.toUpperCase() || 'UNKNOWN';
    const name = backend.countryName || code;
    
    const existing = countryMap.get(code);
    if (existing) {
      existing.count++;
    } else {
      countryMap.set(code, { code, name, count: 1 });
    }
  }

  const countries = Array.from(countryMap.values()).sort((a, b) => a.name.localeCompare(b.name));

  return {
    total: countries.length,
    countries,
  };
}

/**
 * GET /api/v1/usage - Get usage statistics
 */
export async function getUsageStats(
  ctx: ApiContext,
  startDate?: Date,
  endDate?: Date
): Promise<any> {
  if (!ctx.usageTracker) {
    return {
      error: 'Usage tracking not enabled',
      enabled: false,
    };
  }

  const start = startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // Default: last 30 days
  const end = endDate || new Date();

  const userId = typeof ctx.userId === 'string' ? parseInt(ctx.userId, 10) : ctx.userId;
  const usage = await ctx.usageTracker.getUserUsage(userId, start, end);

  if (!usage) {
    return {
      enabled: true,
      periodStart: start.toISOString(),
      periodEnd: end.toISOString(),
      totalRequests: 0,
      totalBytes: 0,
      message: 'No usage data found for this period',
    };
  }

  return {
    enabled: true,
    periodStart: usage.periodStart.toISOString(),
    periodEnd: usage.periodEnd.toISOString(),
    totalRequests: usage.totalRequests,
    successfulRequests: usage.successfulRequests,
    failedRequests: usage.failedRequests,
    totalBytes: usage.totalBytes,
    totalBytesFormatted: formatBytes(usage.totalBytes),
    uploadBytes: usage.uploadBytes,
    uploadBytesFormatted: formatBytes(usage.uploadBytes),
    downloadBytes: usage.downloadBytes,
    downloadBytesFormatted: formatBytes(usage.downloadBytes),
    avgLatencyMs: Math.round(usage.avgLatencyMs),
    countriesUsed: usage.countriesUsed,
  };
}

/**
 * GET /api/v1/metrics - Get real-time metrics
 */
export async function getMetrics(ctx: ApiContext): Promise<any> {
  if (!ctx.metricsCollector) {
    return {
      error: 'Metrics collection not enabled',
      enabled: false,
    };
  }

  const metrics = ctx.metricsCollector.getMetrics();
  const userMetrics = metrics.userStats[ctx.username];

  return {
    enabled: true,
    user: {
      username: ctx.username,
      requests: userMetrics?.requests || 0,
      bytes: userMetrics?.bytes || 0,
      bytesFormatted: formatBytes(userMetrics?.bytes || 0),
      activeConnections: userMetrics?.activeConnections || 0,
    },
    global: {
      totalRequests: metrics.totalRequests,
      successRate: metrics.totalRequests > 0 
        ? ((metrics.successfulRequests / metrics.totalRequests) * 100).toFixed(2) + '%'
        : '0%',
      latency: {
        p50: Math.round(metrics.latency.p50),
        p95: Math.round(metrics.latency.p95),
        p99: Math.round(metrics.latency.p99),
        avg: Math.round(metrics.latency.avg),
      },
    },
  };
}

/**
 * GET /api/v1/health - Health check
 */
export async function getHealth(ctx: ApiContext): Promise<any> {
  const healthyBackends = ctx.backends.filter(b => b.healthy);
  const totalBackends = ctx.backends.length;
  
  const healthPercentage = totalBackends > 0 
    ? ((healthyBackends.length / totalBackends) * 100).toFixed(1)
    : '0';

  return {
    status: healthyBackends.length > 0 ? 'healthy' : 'unhealthy',
    backends: {
      total: totalBackends,
      healthy: healthyBackends.length,
      unhealthy: totalBackends - healthyBackends.length,
      healthPercentage: healthPercentage + '%',
    },
    timestamp: new Date().toISOString(),
  };
}

/**
 * Format bytes to human-readable string
 */
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * GET /api/v1/circuit-breaker/status - Get circuit breaker status for all backends
 */
export async function getCircuitBreakerStatus(ctx: ApiContext): Promise<any> {
  if (!ctx.circuitBreaker) {
    return {
      error: 'Circuit breaker not available',
      enabled: false
    };
  }

  const summary = ctx.circuitBreaker.getSummary();
  const allStats = ctx.circuitBreaker.getAllStats();
  const openCircuits = ctx.circuitBreaker.getOpenCircuits();
  const halfOpenCircuits = ctx.circuitBreaker.getHalfOpenCircuits();

  const backends: any[] = [];
  for (const [backendId, stats] of Array.from(allStats.entries())) {
    backends.push({
      backendId,
      state: stats.state,
      failures: stats.failures,
      successes: stats.successes,
      consecutiveFailures: stats.consecutiveFailures,
      consecutiveSuccesses: stats.consecutiveSuccesses,
      totalRequests: stats.totalRequests,
      rejectedRequests: stats.rejectedRequests,
      lastFailureTime: stats.lastFailureTime ? new Date(stats.lastFailureTime).toISOString() : null,
      lastSuccessTime: stats.lastSuccessTime ? new Date(stats.lastSuccessTime).toISOString() : null,
      lastStateChange: new Date(stats.lastStateChange).toISOString()
    });
  }

  return {
    enabled: true,
    summary,
    openCircuits,
    halfOpenCircuits,
    backends,
    timestamp: new Date().toISOString()
  };
}

/**
 * POST /api/v1/circuit-breaker/reset - Reset circuit breaker for specific backend or all
 */
export async function resetCircuitBreaker(backendId: string | null, ctx: ApiContext): Promise<any> {
  if (!ctx.circuitBreaker) {
    return {
      error: 'Circuit breaker not available',
      enabled: false
    };
  }

  if (backendId) {
    ctx.circuitBreaker.reset(backendId);
    return {
      success: true,
      message: `Circuit breaker reset for backend ${backendId}`,
      backendId,
      timestamp: new Date().toISOString()
    };
  } else {
    ctx.circuitBreaker.resetAll();
    return {
      success: true,
      message: 'All circuit breakers reset',
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * GET /api/v1/connection-pool/stats - Get connection pool statistics
 */
export async function getConnectionPoolStats(ctx: ApiContext): Promise<any> {
  const stats = ctx.connectionPool.getStats();
  
  const summary = {
    totalPools: stats.length,
    totalConnections: stats.reduce((sum, s) => sum + s.totalConnections, 0),
    activeConnections: stats.reduce((sum, s) => sum + s.activeConnections, 0),
    idleConnections: stats.reduce((sum, s) => sum + s.idleConnections, 0),
    totalRequests: stats.reduce((sum, s) => sum + s.totalRequests, 0),
    totalReuses: stats.reduce((sum, s) => sum + s.reuseCount, 0),
  };

  const reuseRate = summary.totalRequests > 0
    ? ((summary.totalReuses / summary.totalRequests) * 100).toFixed(2)
    : '0.00';

  return {
    pools: stats,
    summary: {
      ...summary,
      reuseRate: `${reuseRate}%`,
    },
    timestamp: new Date().toISOString(),
  };
}

/**
 * GET /api/v1/request-queue/stats - Get request queue statistics
 */
export async function getRequestQueueStats(ctx: ApiContext): Promise<any> {
  const stats = ctx.requestQueue.getStats();
  
  return {
    ...stats,
    averageWaitTime: `${stats.averageWaitTime.toFixed(2)}ms`,
    maxWaitTime: `${stats.maxWaitTime.toFixed(2)}ms`,
    timestamp: new Date().toISOString(),
  };
}
