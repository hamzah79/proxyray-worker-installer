export interface TorBackend {
  id: number;
  socksPort: number;
  controlPort: number;
  dnsPort: number;
  healthy: boolean;
  exitIp?: string | null;
  countryCode?: string | null;
  countryName?: string | null;
  lastCheckedAt?: string | null;
}

export type TorRoutingMode = "random" | "sticky" | "pinned-country";

export interface TorInstanceRoutingConfig {
  mode: TorRoutingMode;
  targetCountryCode: string | null;
  weightPercent: number;
  strict: boolean;
  fallbackCountryCode: string | null;
  updatedAt: string;
}

export interface TorUserRoutingPreference {
  mode: "random" | "sticky";
  countryCode: string | null;
  updatedAt: string;
}

export interface AuthSession {
  username: string;
}
