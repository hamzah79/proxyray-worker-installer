import { randomUUID } from "node:crypto";

import { logger } from "../observability/logger";
import { EmailProvider } from "./emailProvider";
import { OutboxRepository } from "./outboxRepository";
import { renderTemplate } from "./templateRenderer";

export class NotificationService {
  constructor(
    private readonly outboxRepo: OutboxRepository,
    private readonly emailProvider: EmailProvider
  ) {}

  async enqueueEmail(params: {
    userId: string | null;
    email: string | null;
    templateCode: string;
    payload: Record<string, unknown>;
    idempotencyKey?: string;
  }): Promise<void> {
    if (!params.email) {
      return;
    }

    await this.outboxRepo.enqueue({
      userId: params.userId,
      email: params.email,
      templateCode: params.templateCode,
      payload: params.payload,
      idempotencyKey: params.idempotencyKey ?? randomUUID()
    });
  }

  async processOutboxBatch(limit: number): Promise<void> {
    const batch = await this.outboxRepo.getDueBatch(limit);

    for (const item of batch) {
      const attempts = item.attempt_count + 1;
      try {
        const payload = isRecord(item.payload) ? item.payload : {};
        const rendered = renderTemplate(item.template_code, payload);
        const result = await this.emailProvider.send({
          to: item.email,
          subject: rendered.subject,
          text: rendered.text,
          html: rendered.html
        });

        await this.outboxRepo.markSent(item.id, result.messageId);
      } catch (error) {
        const message = String(error);
        if (attempts >= 5) {
          await this.outboxRepo.markFailed(item.id, attempts, message);
          logger.error("notification permanently failed", { id: item.id, error: message });
        } else {
          const backoffMinutes = Math.min(60, Math.pow(2, attempts));
          const nextRetryAt = new Date(Date.now() + backoffMinutes * 60 * 1000).toISOString();
          await this.outboxRepo.markRetry(item.id, attempts, message, nextRetryAt);
          logger.warn("notification retry scheduled", { id: item.id, attempts, backoffMinutes, error: message });
        }
      }
    }
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
