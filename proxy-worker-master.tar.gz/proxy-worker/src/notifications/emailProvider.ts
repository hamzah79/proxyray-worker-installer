export interface OutboundEmail {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

export interface EmailSendResult {
  messageId: string;
}

export interface EmailProvider {
  send(email: OutboundEmail): Promise<EmailSendResult>;
}
