import { randomUUID } from "node:crypto";

import { logger } from "../../observability/logger";
import { EmailProvider, EmailSendResult, OutboundEmail } from "../emailProvider";

export class NoopEmailProvider implements EmailProvider {
  async send(email: OutboundEmail): Promise<EmailSendResult> {
    logger.info("noop email provider", { to: email.to, subject: email.subject });
    return { messageId: `noop-${randomUUID()}` };
  }
}
