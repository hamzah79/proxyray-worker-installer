import nodemailer from "nodemailer";

import { EmailProvider, EmailSendResult, OutboundEmail } from "../emailProvider";

export interface GoogleWorkspaceSmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  fromEmail: string;
  fromName: string;
}

export class GoogleWorkspaceSmtpProvider implements EmailProvider {
  private readonly transporter;

  constructor(private readonly config: GoogleWorkspaceSmtpConfig) {
    this.transporter = nodemailer.createTransport({
      host: this.config.host,
      port: this.config.port,
      secure: this.config.secure,
      auth: {
        user: this.config.user,
        pass: this.config.pass
      }
    });
  }

  async send(email: OutboundEmail): Promise<EmailSendResult> {
    const result = await this.transporter.sendMail({
      from: `${this.config.fromName} <${this.config.fromEmail}>`,
      to: email.to,
      subject: email.subject,
      text: email.text,
      html: email.html
    });

    return { messageId: result.messageId };
  }
}
