export interface RenderedTemplate {
  subject: string;
  text: string;
  html?: string;
}

export function renderTemplate(templateCode: string, payload: Record<string, unknown>): RenderedTemplate {
  switch (templateCode) {
    case "register_welcome":
      return {
        subject: "Welcome to Rotating Proxy",
        text: `Halo ${toString(payload.username, "user")}, akun kamu sudah berhasil dibuat.`
      };
    case "email_verification":
      return {
        subject: "Verifikasi email akun kamu",
        text: [
          `Halo ${toString(payload.username, "user")},`,
          "",
          "Silakan verifikasi email akun kamu melalui link berikut:",
          `${toString(payload.verifyUrl, "")}`,
          "",
          "Link ini akan kedaluwarsa dalam 24 jam."
        ].join("\n")
      };
    case "invoice_pending":
      return {
        subject: `Invoice ${toString(payload.invoiceNumber, "")}`,
        text: [
          `Invoice ${toString(payload.invoiceNumber, "") } telah dibuat.`,
          `Metode: ${toString(payload.provider, "")}`,
          `Nominal: ${toString(payload.amount, "")}`,
          `Jatuh tempo: ${toString(payload.dueAt, "")}`
        ].join("\n")
      };
    case "bank_transfer_instruction":
      return {
        subject: `Instruksi transfer ${toString(payload.invoiceNumber, "")}`,
        text: [
          `Silakan transfer sesuai invoice ${toString(payload.invoiceNumber, "")}.`,
          `Bank: ${toString(payload.bankName, "")}`,
          `Atas nama: ${toString(payload.accountName, "")}`,
          `No rekening: ${toString(payload.accountNumber, "")}`,
          `Nominal: ${toString(payload.amount, "")}`,
          `Batas waktu: ${toString(payload.dueAt, "")}`
        ].join("\n")
      };
    case "invoice_paid":
      return {
        subject: `Pembayaran diterima ${toString(payload.invoiceNumber, "")}`,
        text: `Pembayaran invoice ${toString(payload.invoiceNumber, "")} sudah kami terima dan subscription kamu aktif.`
      };
    case "security_password_changed":
      return {
        subject: "Password berhasil diubah",
        text: "Password akun kamu telah diubah. Jika ini bukan kamu, segera hubungi admin."
      };
    default:
      return {
        subject: "Notification",
        text: JSON.stringify(payload)
      };
  }
}

function toString(value: unknown, fallback: string): string {
  return typeof value === "string" ? value : fallback;
}
