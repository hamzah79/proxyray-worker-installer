import { logger } from "../observability/logger";
import { NotificationService } from "./notificationService";

export class OutboxWorker {
  private timer: NodeJS.Timeout | null = null;
  private running = false;

  constructor(
    private readonly notificationService: NotificationService,
    private readonly intervalMs: number,
    private readonly batchSize: number,
    private readonly canProcess: (() => Promise<boolean>) | null = null
  ) {}

  start(): void {
    if (this.timer) {
      return;
    }

    this.timer = setInterval(() => {
      this.tick().catch((error) => {
        logger.error("notification worker tick failed", { error: String(error) });
      });
    }, this.intervalMs);

    this.tick().catch((error) => {
      logger.error("notification worker initial tick failed", { error: String(error) });
    });
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private async tick(): Promise<void> {
    if (this.running) {
      return;
    }

    if (this.canProcess) {
      const allowed = await this.canProcess();
      if (!allowed) {
        return;
      }
    }

    this.running = true;
    try {
      await this.notificationService.processOutboxBatch(this.batchSize);
    } finally {
      this.running = false;
    }
  }
}
