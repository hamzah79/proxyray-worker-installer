import { randomUUID } from "node:crypto";

import { DatabaseClient } from "../db/client";

export type OutboxStatus = "queued" | "retrying" | "sent" | "failed";

export interface OutboxRecord {
  id: string;
  user_id: string | null;
  email: string;
  template_code: string;
  payload: unknown;
  status: OutboxStatus;
  idempotency_key: string;
  attempt_count: number;
  next_retry_at: string | null;
}

export class OutboxRepository {
  constructor(private readonly db: DatabaseClient) {}

  async enqueue(params: {
    userId: string | null;
    email: string;
    templateCode: string;
    payload: unknown;
    idempotencyKey: string;
  }): Promise<void> {
    await this.db.query(
      `INSERT INTO notification_outbox (
         id, user_id, email, template_code, payload, status, idempotency_key, attempt_count
       ) VALUES (
         $1, $2, $3, $4, $5::jsonb, 'queued', $6, 0
       )
       ON CONFLICT (idempotency_key) DO NOTHING`,
      [randomUUID(), params.userId, params.email, params.templateCode, JSON.stringify(params.payload ?? {}), params.idempotencyKey]
    );
  }

  async getDueBatch(limit: number): Promise<OutboxRecord[]> {
    return this.db.query<OutboxRecord>(
      `SELECT id, user_id, email, template_code, payload, status, idempotency_key, attempt_count, next_retry_at
       FROM notification_outbox
       WHERE status IN ('queued', 'retrying')
         AND (next_retry_at IS NULL OR next_retry_at <= NOW())
       ORDER BY created_at ASC
       LIMIT $1`,
      [limit]
    );
  }

  async markSent(id: string, messageId: string): Promise<void> {
    await this.db.query(
      `UPDATE notification_outbox
       SET status = 'sent', provider_message_id = $2, sent_at = NOW()
       WHERE id = $1`,
      [id, messageId]
    );
  }

  async markRetry(id: string, attemptCount: number, errorMessage: string, nextRetryAtIso: string): Promise<void> {
    await this.db.query(
      `UPDATE notification_outbox
       SET status = 'retrying', attempt_count = $2, last_error = $3, next_retry_at = $4::timestamptz
       WHERE id = $1`,
      [id, attemptCount, errorMessage, nextRetryAtIso]
    );
  }

  async markFailed(id: string, attemptCount: number, errorMessage: string): Promise<void> {
    await this.db.query(
      `UPDATE notification_outbox
       SET status = 'failed', attempt_count = $2, last_error = $3
       WHERE id = $1`,
      [id, attemptCount, errorMessage]
    );
  }
}
