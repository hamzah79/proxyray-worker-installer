-- Migration: Add email verification columns
-- Date: 2026-04-28
-- Description: Add missing email verification columns for email verification feature

BEGIN;

-- Add email_verified column (boolean flag)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS email_verified BOOLEAN DEFAULT true;

-- Add email_verified_at column (timestamp when email was verified)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMP WITH TIME ZONE;

-- Add email_verification_token_hash column (hashed verification token)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS email_verification_token_hash TEXT;

-- Add email_verification_expires_at column (token expiration timestamp)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS email_verification_expires_at TIMESTAMP WITH TIME ZONE;

-- Update existing users: set email_verified_at to created_at for already verified users
UPDATE users 
SET email_verified_at = created_at 
WHERE email_verified = true AND email_verified_at IS NULL;

-- Create index for faster token lookup
CREATE INDEX IF NOT EXISTS idx_users_email_verification_token 
ON users(email_verification_token_hash) 
WHERE email_verification_token_hash IS NOT NULL;

-- Create index for cleanup of expired tokens
CREATE INDEX IF NOT EXISTS idx_users_email_verification_expires 
ON users(email_verification_expires_at) 
WHERE email_verification_expires_at IS NOT NULL;

COMMIT;

-- Rollback script (save this separately if needed):
-- BEGIN;
-- DROP INDEX IF EXISTS idx_users_email_verification_expires;
-- DROP INDEX IF EXISTS idx_users_email_verification_token;
-- ALTER TABLE users DROP COLUMN IF EXISTS email_verification_expires_at;
-- ALTER TABLE users DROP COLUMN IF EXISTS email_verification_token_hash;
-- ALTER TABLE users DROP COLUMN IF EXISTS email_verified_at;
-- ALTER TABLE users DROP COLUMN IF EXISTS email_verified;
-- COMMIT;
