# Database Migration Scripts

Comprehensive migration toolkit untuk rotating-proxy database schema updates.

## 📁 File Structure

```
/mnt/f/proxy/
├── migrations/
│   ├── 001_add_email_verification_columns.sql  # Migration SQL
│   ├── verify_schema.sql                       # Schema verification queries
│   └── migration_history.log                   # Auto-generated migration log
├── backups/                                     # Auto-generated backups
│   └── backup_YYYYMMDD_HHMMSS.sql
├── run-migration.sh                             # Linux/Mac runner (direct DB)
├── run-migration-docker.sh                      # Docker runner (recommended)
├── run-migration.bat                            # Windows runner
├── verify-migration.sh                          # Quick verification (Linux/Mac)
├── verify-migration.bat                         # Quick verification (Windows)
└── docs/
    └── MIGRATION_GUIDE.md                       # Detailed guide
```

## 🚀 Quick Start

### 1. Verify Current State

```bash
# Linux/Mac/WSL
./verify-migration.sh

# Windows
verify-migration.bat
```

### 2. Run Migration

```bash
# Linux/Mac/WSL (recommended)
./run-migration-docker.sh migrations/001_add_email_verification_columns.sql

# Windows
run-migration.bat migrations\001_add_email_verification_columns.sql
```

### 3. Verify Migration Success

```bash
./verify-migration.sh
```

## 📋 What Gets Migrated

### Migration 001: Email Verification Columns

Adds support for email verification feature:

**New Columns:**
- `email_verified` (BOOLEAN) - Verification status flag
- `email_verified_at` (TIMESTAMP) - When email was verified
- `email_verification_token_hash` (TEXT) - Hashed verification token
- `email_verification_expires_at` (TIMESTAMP) - Token expiration

**Indexes:**
- `idx_users_email_verification_token` - Fast token lookup
- `idx_users_email_verification_expires` - Expired token cleanup

**Data Updates:**
- Sets `email_verified_at = created_at` for existing verified users

## ✅ Safety Features

1. **Automatic Backups**
   - Every migration creates timestamped backup
   - Stored in `backups/` directory
   - Can be restored manually if needed

2. **Idempotent Migrations**
   - Uses `IF NOT EXISTS` clauses
   - Safe to run multiple times
   - Won't fail if columns already exist

3. **Transaction Wrapped**
   - All changes in single transaction
   - Automatic rollback on error
   - Database stays consistent

4. **Confirmation Prompts**
   - Asks before running migration
   - Shows what will be changed
   - Prevents accidental runs

## 🔍 Verification

### Manual Schema Check

```bash
docker exec rotating-proxy-postgres psql -U proxy_app -d proxy_db -c "\d users"
```

### Check Migration History

```bash
cat migrations/migration_history.log
```

### Test Application

```bash
# Test login
curl -X POST http://localhost:9090/public/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"jendra","password":"Hamzah79"}'

# Should return: {"status":"ok","token":"...","session":{...}}
```

## 🔄 Rollback

If you need to undo migration:

```sql
-- Save as migrations/001_rollback.sql
BEGIN;
DROP INDEX IF EXISTS idx_users_email_verification_expires;
DROP INDEX IF EXISTS idx_users_email_verification_token;
ALTER TABLE users DROP COLUMN IF EXISTS email_verification_expires_at;
ALTER TABLE users DROP COLUMN IF EXISTS email_verification_token_hash;
ALTER TABLE users DROP COLUMN IF EXISTS email_verified_at;
ALTER TABLE users DROP COLUMN IF EXISTS email_verified;
COMMIT;
```

Run rollback:
```bash
./run-migration-docker.sh migrations/001_rollback.sql
```

Or restore from backup:
```bash
docker exec -i rotating-proxy-postgres psql -U proxy_app -d proxy_db < backups/backup_YYYYMMDD_HHMMSS.sql
```

## 🏭 Production Deployment

### Zero-Downtime Strategy

**Phase 1: Run Migration (No Downtime)**
```bash
# Migration is backward-compatible
# Old code continues to work
./run-migration-docker.sh migrations/001_add_email_verification_columns.sql
```

**Phase 2: Deploy New Code**
```bash
# Rebuild and restart application
docker-compose -f docker-compose.yml -f docker-compose.scale.yml up -d --build
```

**Phase 3: Verify**
```bash
./verify-migration.sh
docker logs rotating-proxy | grep -i error
```

### High-Traffic Production

1. **Schedule during low-traffic period** (optional but recommended)
2. **Run migration first** (backward-compatible, no restart needed)
3. **Deploy code later** (when convenient)
4. **Monitor logs** for any issues

## 🐛 Troubleshooting

### "Column already exists" error

✅ **This is safe!** Migration uses `IF NOT EXISTS`, so it's idempotent.

### Login fails after migration

1. Check all columns added:
   ```bash
   docker exec rotating-proxy-postgres psql -U proxy_app -d proxy_db -c "\d users"
   ```

2. Check application logs:
   ```bash
   docker logs rotating-proxy 2>&1 | grep -i error | tail -20
   ```

3. Verify code rebuilt:
   ```bash
   docker exec rotating-proxy ls -la /app/dist/
   ```

4. Rebuild if needed:
   ```bash
   docker-compose -f docker-compose.yml -f docker-compose.scale.yml up -d --build
   ```

### Need to restore backup

```bash
# Stop application
docker-compose -f docker-compose.yml -f docker-compose.scale.yml stop rotating-proxy

# Restore database
docker exec -i rotating-proxy-postgres psql -U proxy_app -d proxy_db < backups/backup_YYYYMMDD_HHMMSS.sql

# Start application
docker-compose -f docker-compose.yml -f docker-compose.scale.yml start rotating-proxy
```

## 📝 Creating New Migrations

1. **Create SQL file:**
   ```bash
   touch migrations/002_your_migration_name.sql
   ```

2. **Write migration:**
   ```sql
   BEGIN;
   
   -- Your changes here
   ALTER TABLE users ADD COLUMN IF NOT EXISTS new_column TEXT;
   
   -- Create indexes if needed
   CREATE INDEX IF NOT EXISTS idx_users_new_column ON users(new_column);
   
   COMMIT;
   ```

3. **Test locally:**
   ```bash
   ./run-migration-docker.sh migrations/002_your_migration_name.sql
   ```

4. **Verify:**
   ```bash
   ./verify-migration.sh
   ```

5. **Document:**
   - Update this README
   - Add to `docs/MIGRATION_GUIDE.md`

## 📚 Additional Resources

- **Detailed Guide:** `docs/MIGRATION_GUIDE.md`
- **Schema Verification:** `migrations/verify_schema.sql`
- **Migration History:** `migrations/migration_history.log`
- **Backups:** `backups/` directory

## ⚠️ Important Notes

1. **Always backup before migration** (automatic, but verify it exists)
2. **Test on staging first** (if you have staging environment)
3. **Run during low-traffic** (optional, but recommended for large databases)
4. **Monitor logs after deployment** (check for errors)
5. **Keep backups for at least 7 days** (in case issues appear later)

## 🆘 Support

If you encounter issues:

1. Check `migrations/migration_history.log`
2. Check `backups/` for automatic backups
3. Review `docker logs rotating-proxy`
4. Restore from backup if needed
5. Contact support with error logs

## ✨ Success Indicators

After successful migration, you should see:

- ✅ All 4 new columns in `users` table
- ✅ 2 new indexes created
- ✅ Login works for existing users
- ✅ No errors in application logs
- ✅ Backup file created in `backups/`
- ✅ Entry in `migrations/migration_history.log`

Run `./verify-migration.sh` to check all indicators automatically.
