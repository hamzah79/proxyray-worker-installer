-- Schema Verification Script
-- Run this to check if all required columns exist

SELECT 
    'users' as table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE table_name = 'users'
ORDER BY ordinal_position;

-- Check for missing columns
SELECT 
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'email_verified') 
        THEN '✓' ELSE '✗' 
    END as email_verified,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'email_verified_at') 
        THEN '✓' ELSE '✗' 
    END as email_verified_at,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'email_verification_token_hash') 
        THEN '✓' ELSE '✗' 
    END as email_verification_token_hash,
    CASE 
        WHEN EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'users' AND column_name = 'email_verification_expires_at') 
        THEN '✓' ELSE '✗' 
    END as email_verification_expires_at;

-- Check indexes
SELECT 
    indexname,
    indexdef
FROM pg_indexes
WHERE tablename = 'users'
AND (indexname LIKE '%email_verification%' OR indexname LIKE '%email_verified%')
ORDER BY indexname;

-- Check data statistics
SELECT 
    COUNT(*) as total_users,
    COUNT(email_verified) as has_email_verified_flag,
    COUNT(email_verified_at) as has_verified_timestamp,
    COUNT(email_verification_token_hash) as has_pending_token,
    SUM(CASE WHEN email_verified = true THEN 1 ELSE 0 END) as verified_users,
    SUM(CASE WHEN email_verified = false THEN 1 ELSE 0 END) as unverified_users
FROM users;
