-- Cleanup Script: Remove expired email verification tokens
-- Run this periodically (e.g., daily via cron) to clean up expired tokens
-- Safe to run anytime, uses transaction

BEGIN;

-- Clear expired verification tokens
UPDATE users
SET 
    email_verification_token_hash = NULL,
    email_verification_expires_at = NULL
WHERE 
    email_verification_expires_at IS NOT NULL 
    AND email_verification_expires_at < NOW()
    AND email_verified = false;

-- Get count of cleaned records
SELECT 
    COUNT(*) as expired_tokens_cleaned,
    NOW() as cleanup_timestamp
FROM users
WHERE 
    email_verification_token_hash IS NULL 
    AND email_verification_expires_at IS NULL
    AND email_verified = false;

COMMIT;

-- Optional: Delete unverified users older than 30 days
-- Uncomment if you want to auto-delete old unverified accounts
-- BEGIN;
-- DELETE FROM users
-- WHERE 
--     email_verified = false 
--     AND created_at < NOW() - INTERVAL '30 days'
--     AND email_verification_expires_at IS NULL;
-- COMMIT;
